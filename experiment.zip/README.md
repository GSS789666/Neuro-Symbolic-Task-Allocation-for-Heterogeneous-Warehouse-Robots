# Versioned Neuro-Symbolic MRTA Experiment Package

This is the executable core for the Shengshuo Gong and Oleg O. Varlamov study. Version 0.2.2 implements the LR-TR-UR generator, transactional Mivar-inspired inference engine, strict DeepSeek cache adapter, two-stage allocator, time-expanded conflict-aware routing, resumable simulation, and exact episode/audit-result integrity gates.

Pilot v1 (`runs/pilot_development_validation`) is preserved as a superseded engineering run. Its files must not be deleted, merged with Pilot v2, or used for paper claims.

Pilot v2 (`runs/pilot_v2_development_validation`) is also preserved unchanged. Joint audit found that it was reproducible but exposed capacity-after-top-8 batch starvation and an unenforced Stage-B wall deadline. It is a defect-discovery run, not confirmatory evidence. The corrective protocol is frozen in `pilot_v2_1_engineering_plan.md`.

Pilot v2.1 (`runs/pilot_v2_1_development_validation`) is preserved unchanged as a failed audit-integrity artifact. Its operational fields passed the engineering gates, but all audit summaries retained placeholder load, disturbance, and split metadata. The v2.2 replay contract is frozen in `pilot_v2_2_audit_integrity_plan.md`.

## What is already validated

- deterministic scenario regeneration and split grouping;
- all three transport modes and same-platform batch invariant;
- atomic batch release and whole-batch capacity feasibility;
- fact insertion, retraction, supersession, rollback, optimistic concurrency, forward inference, proof traces, and unsafe-rule quarantine;
- A* obstacle routing, vertex conflicts, and head-on edge conflicts;
- Stage B cannot select a UR before transport begins and commits route, future UR slot, service queue, and unit-capacity destination dock atomically;
- UR readiness uses `max(now, available_at) + travel`, and positive TR-to-UR waits are exercised in pressure tests;
- fixed Mivar, dynamic-fact, and dynamic-rule effects are separated by controlled counterfactual tests;
- every nonempty/empty Stage-A attempt and every successful/failed Stage-B attempt stores raw latency, candidate count, status, timeout, and fallback fields;
- per-mode outcomes and cumulative constraint-source/proof traces are emitted;
- CP-SAT matches exhaustive enumeration on tiny candidate sets;
- a full development replay completes without hard violations;
- generated checksums, semantic labels, and leakage groups are checked.

The generated development corpus and smoke outputs are simulated validation artifacts, not article results.

## Directory map

- `configs/`: frozen development, Pilot, Main, and secondary-scalability configurations.
- `data/generated_v2/`: version-0.2 deterministic scenarios, semantic event JSONL, checksums, and structural-feasibility report.
- `data/deepseek_cache/`: ignored local API cache; API keys are never stored.
- `mrta/`: source package.
- `runs/`: resumable episode results and compressed audit logs; ignored by Git.
- `scripts/`: CMD entry points intended for Windows Command Prompt.
- `tests/`: unit, invariant, exact-enumeration, and integration tests.

## Setup and short validation

From Windows CMD in this `experiment` directory:

```cmd
scripts\00_setup.cmd
scripts\01_generate_data_v2.cmd
scripts\02_validate_core.cmd
```

## DeepSeek collection (blocked until Pilot v2.2 and S2 preflight pass)

Do not run any DeepSeek prefetch command yet. The v2 generator changes grounding contexts and therefore invalidates v1 cache identities. After Pilot v2 passes joint author/agent/reviewer review, set the key only in the current CMD process and freeze the exact model identifier.

```cmd
set DEEPSEEK_API_KEY=your_key_here
set DEEPSEEK_MODEL=deepseek-chat
scripts\03_prefetch_deepseek.cmd --split validation
```

The command is resumable: completed cache keys are reused. When the cache is complete, disconnect the network and evaluate it:

```cmd
scripts\03b_evaluate_deepseek_offline.cmd
```

The matched end-to-end study has an exact 30-scenario event export (1,050 cached calls). Freeze one model identifier and use the same value for collection and replay:

```cmd
set DEEPSEEK_MODEL=deepseek-chat
scripts\03c_export_e2e_events.cmd
scripts\03d_prefetch_e2e_deepseek.cmd
scripts\03e_check_e2e_cache.cmd
scripts\04b_run_e2e_offline.cmd
scripts\06_check_results.cmd runs\end_to_end_cached_deepseek
```

Do not paste the API key into source or configuration files. `03d` can be re-run after a network interruption; `04b` fails on any missing cache entry.

## Pilot v2.2 offline audit-integrity closure run

Pilot v2.2 makes no live network calls. It can be interrupted with `Ctrl+C`; run the same command again to resume from atomic episode/audit pairs. The script first runs all regression tests, then executes 1,200 tasks under a new run name, and finally applies audit equality, terminal-pending, mechanism-attribution, and one-second Stage-B gates.

```cmd
scripts\04_run_pilot_v2_2_offline.cmd
```

If you want to rerun only the final validation:

```cmd
scripts\06c_check_pilot_v2_2_results.cmd
```

Do not run Main or DeepSeek prefetch yet. `scripts\05_run_main_offline.cmd` remains only as a future entry point; the confirmatory configuration must be re-frozen after Pilot v2.2 and the S2 preflight pass joint review.

<!-- Future command, intentionally blocked:
```cmd
scripts\05_run_main_offline.cmd
```
-->

The same block applies to scalability.

## Pilot v2.2 automatic gates

The run is rejected for any aggregate/episode/audit-summary mismatch, terminal payload/source/schema mismatch, structural infeasibility, hard violation, terminal pending cargo, missing episode/audit pair, incomplete raw decision record, missing per-mode or direct-mechanism metric, incomplete derived-constraint proof, degenerate UR waiting, insufficient Stage-A or Stage-B tail samples, or all-cell identity in any adjacent attribution contrast (`static CP -> static Mivar -> dynamic facts -> dynamic rules`). Stage B must also satisfy p95 <= 800 ms, p99 <= 1,000 ms, maximum <= 1,050 ms, and time-limited/timeout mass <= 1%; Stage-A fallback mass must remain <= 1%.

## S2 preflight

After Pilot v2.2 passes joint review, run the isolated 120-task S2 engineering preflight. It uses development/validation layouts only and leaves every Main test seed unopened.

```cmd
scripts\04c_run_s2_preflight_offline.cmd
```

Its preflight-only tail minimum is 1,000 Stage-A/Stage-B decisions per applicable method; all other Pilot v2.2 gates remain unchanged. Main retains the stronger minimum of 2,000 and remains blocked until the confirmatory statistical protocol is frozen.

## Claim boundary

Until a published mapping to the author's representative original rule corpus passes, use “Mivar-inspired transactional inference engine.” Do not call this a full Mivar/Razumator implementation. Coalition routing is an MRTA abstraction and does not model rigid formations, common velocity, turning envelope, or convoy width.
