# Confirmatory Statistical Analysis Plan

## Status, scope, and evidence boundary

This document freezes the Main analysis before any held-out Main task is executed. The study is a controlled simulator experiment, so all Main findings must be labelled simulated confirmatory evidence rather than measured industrial deployment evidence. Pilot v1, Pilot v2, Pilot v2.1, Pilot v2.2, and the S2 preflight are engineering artifacts and are not pooled with Main or used for confirmatory p values.

## Experimental design and independent unit

Main uses 15 held-out S2 layout seeds, two event traces per layout, four loads, three disturbance levels, and five matched methods. The layout seeds are the first 15 mechanically eligible held-out S2 test seeds from the prespecified increasing integer sequence beginning at 3101; they were selected without observing Main outcomes. This yields 1,800 tasks while retaining the same compute budget as the former five-layout/six-trace design. The independent paired unit is the layout seed (`n = 15`). The two traces and 24 trace-by-load-by-disturbance cells within a method/layout are repeated technical conditions and are aggregated before inference. They are never counted as 360 independent replicates.

All methods receive the same layout, event trace, load, disturbance, horizon, mandatory collision constraints, and terminal validation. No task, seed, trace, load, disturbance, or method cell will be removed after results are opened. Missing, unreadable, non-finite, hash-inconsistent, or audit-inconsistent data block the confirmatory analysis; no imputation is permitted.

## Seed-level estimands

For every layout seed and method, counts and distances are summed over its 24 repeated condition cells before division. Deadline-miss rate is the reconstructed number of late completed cargos divided by completed cargos. Low-reserve assignments, moving-congestion exposure ticks, and low-friction exposure ticks are divided by completed cargos. Travel distance is cargo-weighted. Throughput is total completed cargos per total simulated ticks, scaled to 100 ticks. This aggregation gives each layout seed one value per method and endpoint.

## Prespecified primary hypotheses

All differences are intervention minus baseline; lower values are favourable.

1. H1: `dynamic_rules_cp_sat` has a lower deadline-miss rate than `greedy`.
2. H2: `static_mivar_cp_sat` has fewer low-reserve TR assignments per completed cargo than `static_cp_sat`.
3. H3: `dynamic_facts_cp_sat` has fewer moving-congestion exposure ticks per completed cargo than `static_mivar_cp_sat`.
4. H4: `dynamic_rules_cp_sat` has fewer low-friction exposure ticks per completed cargo than `dynamic_facts_cp_sat`.

The primary estimand for each hypothesis is the unconditional probability that a randomly generated held-out layout has a favourable seed-aggregated intervention-minus-baseline difference. Each hypothesis uses an exact one-sided binomial test of whether this probability exceeds 0.5. All 15 layouts remain in the denominator, and a zero difference is conservatively counted as no improvement. This inference relies on independent pseudo-random layout seeds from the fixed held-out generator family, not on random assignment or exchangeability of method labels. The family-wise error rate is 0.05, controlled across H1-H4 by Holm adjustment. Each result reports the raw and adjusted p value, unconditional probability-of-improvement estimate with Wilson 95% interval, mean and median paired difference, descriptive 95% layout-cluster bootstrap interval, win/tie/loss counts, and matched-pairs rank-biserial effect size. A hypothesis is supported only when the Holm-adjusted p value is below 0.05 and the estimated unconditional probability of improvement exceeds 0.5.

The sample-size choice is a prespecified sensitivity design. Under the conservative per-test threshold 0.0125, at least 13 of all 15 layouts must favour the intervention; ties count as non-improvements. This rule has 81.6% power if the true unconditional layout-level probability of improvement is 0.90, 60.4% at 0.85, and 39.8% at 0.80. The study therefore targets broad and repeatable mechanism effects; weaker, tied, or heterogeneous effects will not be promoted to confirmatory claims.

## Non-inferiority guardrail for the full system

The full dynamic-rule method is compared with `static_cp_sat`. Three harm measures are calculated per layout: absolute deadline-miss increase, relative travel-distance increase, and relative movement-energy-proxy increase. The prespecified margins are 0.02 absolute deadline-miss probability, 3% distance, and 3% energy proxy per completed cargo. The one-sided 95% layout-cluster bootstrap upper bound must be strictly below the corresponding margin for every component. This is an intersection-union decision: all three components must pass, so failure of one component blocks the non-inferiority statement. Non-significance in an ordinary superiority test is never interpreted as non-inferiority.

The margins are simulator-level engineering tolerances fixed before Main, not estimates selected to maximize significance. Because an S2 episode contains 100 cargos, the 0.02 deadline margin permits at most two additional late deliveries per full episode; it is not presented as an industrial service-level agreement. The S2 grid is fixed at 28 by 20 cells, and 3% distance is approximately one extra grid edge on a typical cross-warehouse platform-to-destination movement. The energy proxy is linear in coalition size and travelled distance, so the same 3% limit prevents a mechanism benefit from being purchased through materially greater movement-energy cost. These rationales use the frozen simulator structure rather than Main outcomes.

## Safety, real-time, and integrity gates

Main must pass `mrta-audit-2.2` equality and hash checks, have zero hard violations, zero structural infeasibility, zero terminal pending cargo, complete derived-constraint proof coverage, and retain matched method cells. Stage B must satisfy p95 no greater than 800 ms, p99 no greater than 1,000 ms, maximum no greater than 1,050 ms, and timeout mass no greater than 1%; Stage-A fallback mass must be no greater than 1%. At least 2,000 nonempty Stage-A calls are required for every non-greedy scale/method cell, and at least 2,000 raw Stage-B attempts for every method. These gates are prerequisites, not statistical endpoints.

Timeouts, fallbacks, safe waits, cancellations, and terminal outcomes remain assigned to the method that produced them. No per-protocol deletion is allowed. If an integrity or engineering prerequisite fails, Main is labelled failed and primary inferential output is not generated.

## Descriptive and exploratory analyses

For every method, layout-seed mean, standard deviation, median, interquartile range, and 95% cluster bootstrap interval are reported for the primary and operational metrics. Load-, disturbance-, transport-mode-, and interaction-specific analyses are exploratory. Benjamini-Hochberg false-discovery-rate adjustment is applied within each explicitly declared exploratory family. Exploratory findings cannot replace or rescue a failed primary hypothesis and must be labelled exploratory in text and figures.

## Reproducibility and reporting

Before Main, the configuration, protocol JSON, analysis code, source inventory, source digest, task identities, package versions, and host metadata are written to an immutable freeze manifest. The analysis refuses to run if those hashes differ. Exact p values are reported unless smaller than the exact enumeration resolution. Figures show all 15 layout-seed paired observations or paired differences; error bars and intervals are explicitly defined. Claims are limited to the simulator and do not imply industrial deployment, physical-robot validation, or superiority of unrestricted LLM reasoning.
