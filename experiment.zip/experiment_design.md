# Pilot v2 Pre-registered Experiment Design

## Scope

This version implements and validates the repaired computational system. Pilot v1 is retained only as a defect-discovery artifact and is not evidence. This document freezes Pilot v2 before its results are opened; it contains no Pilot v2 or confirmatory conclusions, publication figures, or manuscript claims. The primary journal is *AI* and the backup is *Frontiers in Robotics and AI*.

## System under test

The warehouse contains three non-substitutable robot roles:

- Loading Robot (LR): moves only within its assigned loading platform.
- Transport Robot (TR): moves throughout the warehouse between loading platforms and shelf destinations.
- Unloading Robot (UR): moves only inside its shelf zone.

The three supported cargo modes are one-TR individual transport, abstract 2-4-TR coalition transport for one oversized cargo, and one-TR batching of 2-5 cargoes from one loading platform to potentially different destinations. Coalition formation kinematics are deliberately outside the first article.

Stage A binds cargoes, one LR, and one TR or TR coalition. Every generated batch is atomically released and its total weight fits at least one TR. Stage B is prohibited until loading completes and a selected TR enters `in_transit`; it then re-reads current state and atomically binds an executable time-expanded TR path, cargo order, future UR service slots, and unit-capacity destination docks. UR readiness is computed from the current decision time, its existing queue tail, movement time within its shelf zone, and service duration. Temporary obstacles, moving-agent congestion, robot unavailability, and TR-TR vertex/head-on conflicts enter the routing state. A one-second deterministic-solver limit is frozen for online calls.

## Knowledge and language layers

The code-generated Mivar-inspired engine supports typed facts, finite production rules, least-fixed-point forward inference, proof DAGs, atomic insert/retract/supersede transactions, optimistic version checks, immutable logs, rollback, and quarantine of unsafe or non-terminating rules. It does not claim Razumator API compatibility or complete Mivar equivalence.

DeepSeek is accessed through the documented chat-completions REST interface. The model, endpoint, prompt schema, exact context, response, usage, and timestamp are cache-bound. Live collection is resumable. Evaluation is cache-only and never substitutes a gold answer on a miss.

## Evaluation tracks

| Track | Input held equal | Question |
|---|---|---|
| G: semantic grounding | Event text, typed payload/context, ontology, schema | Can DeepSeek produce correct fact/rule candidates, and what does the deterministic shield reject? |
| A: allocation | Gold structured dynamic state | What allocation/routing effect follows from greedy, CP-SAT, static inference, dynamic facts, and restricted dynamic rules? |
| E: end to end | Same raw text and structured context | What is the combined behavior when cached DeepSeek candidates drive validated transactions? |

Track A is the long-running Pilot/Main simulation implemented in the frozen configs. Track G has separate prefetch/evaluation commands so an unstable network cannot contaminate timing or interrupt the allocator. Track E is opened only after Track G and Pilot pass their gates; it must use the same strict cache and will not be inferred from Track A.

## Methods

1. `greedy`: deterministic nearest feasible dispatch with the same hard routing safeguards.
2. `static_cp_sat`: candidate-set CP-SAT allocation without a production-rule layer.
3. `static_mivar_cp_sat`: a fixed reserve/eligibility production policy plus CP-SAT; it performs no runtime event writes.
4. `dynamic_facts_cp_sat`: the same fixed policy plus versioned runtime fact insert/retract/supersede operations; asserted congestion facts enter route costs.
5. `dynamic_rules_cp_sat`: dynamic facts plus quarantined temporary rules; low-friction facts derive route penalties that are actually consumed by the router.

Mandatory physical collision constraints are shared by every method. Soft-event costs and symbolic eligibility constraints are not shared implicitly. Controlled counterfactual unit tests must show that each adjacent method contract changes a decision in its intended pathway before Pilot v2 may start.

The implementation generates a finite feasible candidate set before CP-SAT. Mode-2 coalition candidates use the nearest eight available TRs, and singleton/batch candidates use the nearest eight capacity-feasible TRs. This pruning boundary must be reported; it is not a proof of global optimality over every possible warehouse coalition at S2-S4. Tiny instances are checked against exhaustive enumeration.

## Conditions and sample sizes

- Pilot: S0 and S1, five layout seeds, six event traces per seed, loads 0.35/0.60/0.80/0.95, and low/medium/high disturbances. Only development/validation groups are used.
- Confirmatory main: S2, five layout seeds and six traces per seed (30 matched episodes per primary cell), the same four loads and three disturbance levels. Only held-out test groups are used.
- Secondary scalability: S3 and S4 with fewer explicitly exploratory episodes.
- Semantic corpus: 14,640 generated events, including 3,000 schema- and type-valid harmful candidates; the held-out test split contains 780 harmful candidates.
- Latency: at least 2,000 deterministic solver invocations per reported scale before p95/p99 claims.

## Primary endpoints

Grounding endpoints are first-pass syntactic validity, logical consistency, exact fact-delta match, predicate precision/recall/F1, harmful false-accept rate, and valid false-reject rate. Operational endpoints are throughput, deadline-miss rate, TR waiting for UR, travel distance per delivered cargo, low-friction exposure, bounded Stage-A and Stage-B latency, timeout/fallback/safe-wait mass, event-level recovery and response time, hard violations, rollback accuracy, and proof-trace coverage. Operational outcomes are also emitted separately for individual, coalition, and batch transport.

## Statistical freeze after Pilot

Pilot data are used only to select engineering-relevant effect thresholds and power the matched episode count. Confirmatory comparisons use paired scenario blocks, 95% confidence intervals, effect sizes, assumption checks, hierarchical/bootstrap or paired non-parametric procedures where appropriate, exact binomial safety intervals, and Holm correction across the four confirmatory hypotheses. No main-test result is opened before this analysis configuration is frozen.

## Execution and provenance

Every task has a hash-derived identifier and an atomic episode file. Re-running a command skips completed task identifiers. Each run records timestamps, command, config SHA-256, generator SHA-256, Python/dependency versions, host fingerprint, repository commit/dirty state, audit logs, and final result checksum. The validation command rejects incomplete runs, non-finite metrics, checksum mismatches, unequal matched cells, hard violations, and insufficient tail-latency samples when the confirmatory flag is used.
