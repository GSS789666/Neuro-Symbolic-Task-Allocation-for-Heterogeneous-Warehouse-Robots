"""Versioned neuro-symbolic LR-TR-UR warehouse research code."""

__version__ = "0.2.2"
