from __future__ import annotations

import argparse
import json
from pathlib import Path

from .grounding import CacheMiss, DeepSeekGrounder, GroundingError
from .knowledge import VersionedKnowledgeBase


def audit_cache(events_path: Path, cache_dir: Path, model: str) -> dict:
    records = [json.loads(line) for line in events_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    grounder = DeepSeekGrounder(cache_dir, model=model)
    missing: list[str] = []
    invalid: list[dict[str, str]] = []
    for record in records:
        context = record.get("grounding_context") or {
            "scenario_id": record["scenario_id"], "authenticated_payload": record["payload"],
            "ontology": {key: list(value) for key, value in sorted(VersionedKnowledgeBase().signatures.items())},
        }
        try:
            grounder.ground(record["text"], context, offline=True)
        except CacheMiss:
            missing.append(record["case_id"])
        except GroundingError as exc:
            invalid.append({"case_id": record["case_id"], "error": str(exc)})
    return {
        "status": "pass" if not missing and not invalid else "fail",
        "model": model, "events": len(records),
        "valid_cache_entries": len(records) - len(missing) - len(invalid),
        "missing_count": len(missing), "invalid_count": len(invalid),
        "missing_examples": missing[:20], "invalid_examples": invalid[:20],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify that an offline DeepSeek cache is complete and valid")
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--model", required=True)
    args = parser.parse_args()
    result = audit_cache(args.events, args.cache, args.model)
    print(json.dumps(result, indent=2, sort_keys=True))
    raise SystemExit(0 if result["status"] == "pass" else 1)


if __name__ == "__main__":
    main()
