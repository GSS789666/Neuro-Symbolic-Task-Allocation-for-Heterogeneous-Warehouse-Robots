from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import statistics
from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .experiment import (
    _git_metadata,
    _host_metadata,
    _source_digest,
    _source_inventory,
    build_tasks,
)
from .validation import validate_run


def freeze_main(config_path: Path, protocol_path: Path, output_path: Path) -> dict[str, Any]:
    config = _read_json(config_path)
    protocol = _read_json(protocol_path)
    project_root = config_path.resolve().parent.parent
    run_dir = project_root / "runs" / config["run_name"]
    if not output_path.exists() and run_dir.exists():
        raise RuntimeError(
            f"Refusing a post-hoc Main freeze because the run directory already exists: {run_dir}"
        )
    tasks = build_tasks(config)
    expected_count = int(protocol["expected_task_count"])
    expected_layouts = int(protocol["expected_layout_seeds"])
    expected_cells = int(protocol["expected_cells_per_seed_method"])
    if len(tasks) != expected_count:
        raise ValueError(f"Main task count is {len(tasks)}, expected {expected_count}")
    if len({task.task_id for task in tasks}) != len(tasks):
        raise ValueError("Main task identities are not unique")
    if {task.split for task in tasks} != {"test"}:
        raise ValueError("Main may contain held-out test tasks only")
    if {task.audit_schema for task in tasks} != {"mrta-audit-2.2"}:
        raise ValueError("Main must use mrta-audit-2.2")
    seeds = sorted({task.seed for task in tasks})
    if len(seeds) != expected_layouts:
        raise ValueError(f"Main has {len(seeds)} layout seeds, expected {expected_layouts}")
    cell_counts = Counter((task.seed, task.method) for task in tasks)
    if set(cell_counts.values()) != {expected_cells}:
        raise ValueError("Every layout seed and method must contain exactly 24 repeated condition cells")
    task_payload = [asdict(task) for task in sorted(tasks, key=lambda item: item.task_id)]
    freeze = {
        "status": "frozen_before_main",
        "run_name": config["run_name"],
        "run_dir": str(run_dir),
        "protocol_id": protocol["protocol_id"],
        "evidence_mode": protocol["evidence_mode"],
        "independent_unit": protocol["independent_unit"],
        "layout_seeds": seeds,
        "task_count": len(tasks),
        "task_ids_sha256": _digest_json(task_payload),
        "config_path": str(config_path.resolve()),
        "config_sha256": _digest_file(config_path),
        "protocol_path": str(protocol_path.resolve()),
        "protocol_sha256": _digest_file(protocol_path),
        "source_sha256": _source_digest(),
        "source_inventory": _source_inventory(),
        "host": _host_metadata(),
        "repository": _git_metadata(config_path.parent),
        "minimum_tail_sample": int(protocol["minimum_tail_sample"]),
        "audit_schema": "mrta-audit-2.2",
        "main_results_opened": False,
    }
    _write_immutable_json(output_path, freeze)
    return freeze


def analyze_main(
    run_dir: Path,
    freeze_path: Path,
    protocol_path: Path,
    output_path: Path,
) -> dict[str, Any]:
    freeze = _read_json(freeze_path)
    protocol = _read_json(protocol_path)
    _verify_freeze(freeze, protocol_path)
    report = validate_run(
        run_dir,
        strict_engineering=True,
        minimum_tail_sample=int(protocol["minimum_tail_sample"]),
    )
    if report["status"] != "pass":
        raise RuntimeError(
            f"Main integrity/engineering validation failed with {report['failure_count']} failures"
        )
    manifest = _read_json(run_dir / "run_manifest.json")
    if manifest.get("run_name") != freeze["run_name"]:
        raise RuntimeError("Main run name differs from the frozen run name")
    for key in ("config_sha256", "source_sha256", "audit_schema"):
        if manifest.get(key) != freeze.get(key):
            raise RuntimeError(f"Main manifest {key} differs from the freeze manifest")
    rows = [
        json.loads(line)
        for line in (run_dir / "episode_results.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if len(rows) != int(protocol["expected_task_count"]):
        raise RuntimeError("Main result count differs from the frozen protocol")
    row_tasks = [row["task"] for row in sorted(rows, key=lambda item: item["task"]["task_id"])]
    if _digest_json(row_tasks) != freeze["task_ids_sha256"]:
        raise RuntimeError("Main result task identities differ from the freeze manifest")
    aggregate = aggregate_by_layout_method(
        rows,
        expected_cells=int(protocol["expected_cells_per_seed_method"]),
    )
    seeds = sorted({seed for seed, _ in aggregate})
    if seeds != freeze["layout_seeds"]:
        raise RuntimeError("Main layout seeds differ from the freeze manifest")

    primary: list[dict[str, Any]] = []
    for index, hypothesis in enumerate(protocol["primary_hypotheses"]):
        differences = _paired_differences(aggregate, seeds, hypothesis)
        direction = hypothesis["direction"]
        raw_p = exact_binomial_sign_p(differences, direction)
        lower, upper = bootstrap_mean_interval(
            differences,
            resamples=int(protocol["bootstrap_resamples"]),
            seed=int(protocol["bootstrap_seed"]) + index,
        )
        primary.append({
            **hypothesis,
            "n_layout_seeds": len(seeds),
            "mean_difference": statistics.fmean(differences),
            "median_difference": statistics.median(differences),
            "bootstrap_95_ci": [lower, upper],
            "raw_p": raw_p,
            "rank_biserial": matched_rank_biserial(differences),
            "wins": sum(value < 0 for value in differences),
            "ties": sum(value == 0 for value in differences),
            "losses": sum(value > 0 for value in differences),
        })
    adjusted = holm_adjust([item["raw_p"] for item in primary])
    for item, adjusted_p in zip(primary, adjusted):
        item["holm_adjusted_p"] = adjusted_p
        favourable_count = item["wins"] if item["direction"] == "lower" else item["losses"]
        probability = favourable_count / len(seeds)
        item["n_layout_seeds_in_probability"] = len(seeds)
        item["probability_of_improvement"] = probability
        item["probability_of_improvement_wilson_95_ci"] = list(
            wilson_interval(favourable_count, len(seeds))
        )
        item["supported"] = bool(probability > 0.5 and adjusted_p < float(protocol["alpha"]))

    noninferiority = _noninferiority(aggregate, seeds, protocol)
    methods = sorted({method for _, method in aggregate})
    metric_names = sorted(next(iter(aggregate.values())))
    descriptive = {
        method: {
            metric: summarize([aggregate[(seed, method)][metric] for seed in seeds])
            for metric in metric_names
        }
        for method in methods
    }
    result = {
        "status": "complete",
        "evidence_mode": protocol["evidence_mode"],
        "protocol_id": protocol["protocol_id"],
        "run_dir": str(run_dir.resolve()),
        "run_results_sha256": manifest["results_sha256"],
        "freeze_manifest_sha256": _digest_file(freeze_path),
        "protocol_sha256": _digest_file(protocol_path),
        "independent_unit": protocol["independent_unit"],
        "n_layout_seeds": len(seeds),
        "layout_seeds": seeds,
        "primary_hypotheses": primary,
        "noninferiority": noninferiority,
        "descriptive_by_method": descriptive,
        "engineering_validation": {
            "status": report["status"],
            "failure_count": report["failure_count"],
            "warnings": report["warnings"],
        },
        "overall_confirmatory_claim_supported": bool(
            all(item["supported"] for item in primary) and noninferiority["passed"]
        ),
    }
    _write_json(output_path, result)
    return result


def aggregate_by_layout_method(
    rows: list[dict[str, Any]],
    expected_cells: int,
) -> dict[tuple[int, str], dict[str, float]]:
    grouped: dict[tuple[int, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[(int(row["task"]["seed"]), row["task"]["method"])].append(row)
    output: dict[tuple[int, str], dict[str, float]] = {}
    for key, group in grouped.items():
        if len(group) != expected_cells:
            raise RuntimeError(f"Layout/method {key} has {len(group)} cells, expected {expected_cells}")
        completed = sum(int(row["result"]["cargo_completed"]) for row in group)
        if completed <= 0:
            raise RuntimeError(f"Layout/method {key} completed no cargo")
        late = 0
        distance = 0.0
        for row in group:
            result = row["result"]
            count = int(result["cargo_completed"])
            rate = result["deadline_miss_rate"]
            per_cargo_distance = result["travel_distance_per_cargo"]
            if rate is None or per_cargo_distance is None:
                raise RuntimeError(f"Layout/method {key} contains a missing primary value")
            reconstructed = float(rate) * count
            rounded = round(reconstructed)
            if not math.isclose(reconstructed, rounded, abs_tol=1e-7):
                raise RuntimeError(f"Cannot reconstruct deadline-miss count for {key}")
            late += int(rounded)
            distance += float(per_cargo_distance) * count
        total_ticks = sum(int(row["result"]["horizon"]) for row in group)
        output[key] = {
            "deadline_miss_rate": late / completed,
            "low_reserve_assignments_per_completed_cargo": sum(
                int(row["result"]["low_reserve_tr_assignments"]) for row in group
            ) / completed,
            "moving_congestion_ticks_per_completed_cargo": sum(
                int(row["result"]["moving_congestion_exposure_ticks"]) for row in group
            ) / completed,
            "low_friction_ticks_per_completed_cargo": sum(
                int(row["result"]["low_friction_exposure_ticks"]) for row in group
            ) / completed,
            "travel_distance_per_cargo": distance / completed,
            "throughput_per_100_ticks": 100.0 * completed / total_ticks,
            "energy_proxy_per_completed_cargo": sum(
                float(row["result"]["energy_proxy"]) for row in group
            ) / completed,
        }
    return output


def exact_binomial_sign_p(differences: list[float], direction: str) -> float:
    if not differences:
        raise ValueError("At least one paired difference is required")
    if direction not in {"lower", "higher"}:
        raise ValueError(f"Unsupported direction: {direction}")
    favourable = sum(value < 0 for value in differences) if direction == "lower" else sum(value > 0 for value in differences)
    total = len(differences)
    return sum(math.comb(total, count) for count in range(favourable, total + 1)) / (2 ** total)


def wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if total == 0:
        return 0.0, 1.0
    probability = successes / total
    denominator = 1.0 + z * z / total
    center = (probability + z * z / (2.0 * total)) / denominator
    radius = z * math.sqrt(probability * (1.0 - probability) / total + z * z / (4.0 * total * total)) / denominator
    return max(0.0, center - radius), min(1.0, center + radius)


def holm_adjust(p_values: list[float]) -> list[float]:
    order = sorted(range(len(p_values)), key=p_values.__getitem__)
    adjusted = [0.0] * len(p_values)
    running = 0.0
    total = len(p_values)
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (total - rank) * p_values[index]))
        adjusted[index] = running
    return adjusted


def bootstrap_mean_interval(
    values: list[float],
    resamples: int,
    seed: int,
) -> tuple[float, float]:
    rng = random.Random(seed)
    size = len(values)
    samples = sorted(
        statistics.fmean(values[rng.randrange(size)] for _ in range(size))
        for _ in range(resamples)
    )
    return _percentile(samples, 0.025), _percentile(samples, 0.975)


def matched_rank_biserial(differences: list[float]) -> float | None:
    nonzero = [(abs(value), value) for value in differences if value != 0]
    if not nonzero:
        return None
    ordered = sorted(nonzero)
    ranks: list[tuple[float, float]] = []
    index = 0
    while index < len(ordered):
        end = index + 1
        while end < len(ordered) and ordered[end][0] == ordered[index][0]:
            end += 1
        average_rank = (index + 1 + end) / 2.0
        ranks.extend((average_rank, value) for _, value in ordered[index:end])
        index = end
    positive = sum(rank for rank, value in ranks if value > 0)
    negative = sum(rank for rank, value in ranks if value < 0)
    return (positive - negative) / (positive + negative)


def summarize(values: list[float]) -> dict[str, float | int]:
    ordered = sorted(values)
    return {
        "n_layout_seeds": len(values),
        "mean": statistics.fmean(values),
        "sd": statistics.stdev(values) if len(values) > 1 else 0.0,
        "median": statistics.median(values),
        "q1": _percentile(ordered, 0.25),
        "q3": _percentile(ordered, 0.75),
    }


def _paired_differences(
    aggregate: dict[tuple[int, str], dict[str, float]],
    seeds: list[int],
    hypothesis: dict[str, Any],
) -> list[float]:
    return [
        aggregate[(seed, hypothesis["intervention"])][hypothesis["metric"]]
        - aggregate[(seed, hypothesis["baseline"])][hypothesis["metric"]]
        for seed in seeds
    ]


def _noninferiority(
    aggregate: dict[tuple[int, str], dict[str, float]],
    seeds: list[int],
    protocol: dict[str, Any],
) -> dict[str, Any]:
    definition = protocol["noninferiority"]
    intervention = definition["intervention"]
    baseline = definition["baseline"]
    results = []
    for index, guardrail in enumerate(definition["guardrails"]):
        metric = guardrail["metric"]
        harms = []
        for seed in seeds:
            new = aggregate[(seed, intervention)][metric]
            old = aggregate[(seed, baseline)][metric]
            if guardrail["harm"] == "absolute_intervention_minus_baseline":
                harm = new - old
            elif guardrail["harm"] == "intervention_divided_by_baseline_minus_one":
                if old == 0:
                    raise RuntimeError(f"Zero baseline prevents ratio guardrail {guardrail['id']}")
                harm = new / old - 1.0
            elif guardrail["harm"] == "one_minus_intervention_divided_by_baseline":
                if old == 0:
                    raise RuntimeError(f"Zero baseline prevents ratio guardrail {guardrail['id']}")
                harm = 1.0 - new / old
            else:
                raise ValueError(f"Unknown harm definition: {guardrail['harm']}")
            harms.append(harm)
        rng = random.Random(int(protocol["bootstrap_seed"]) + 100 + index)
        size = len(harms)
        boot = sorted(
            statistics.fmean(harms[rng.randrange(size)] for _ in range(size))
            for _ in range(int(protocol["bootstrap_resamples"]))
        )
        upper = _percentile(boot, 0.95)
        margin = float(guardrail["margin"])
        results.append({
            **guardrail,
            "n_layout_seeds": len(seeds),
            "mean_harm": statistics.fmean(harms),
            "one_sided_95_upper_bound": upper,
            "passed": upper < margin,
        })
    return {
        "intervention": intervention,
        "baseline": baseline,
        "all_required": True,
        "guardrails": results,
        "passed": all(item["passed"] for item in results),
    }


def _verify_freeze(freeze: dict[str, Any], protocol_path: Path) -> None:
    if freeze.get("status") != "frozen_before_main" or freeze.get("main_results_opened") is not False:
        raise RuntimeError("Freeze manifest is not a pre-Main immutable freeze")
    config_path = Path(freeze["config_path"])
    if _digest_file(config_path) != freeze["config_sha256"]:
        raise RuntimeError("Main configuration changed after freeze")
    if _digest_file(protocol_path) != freeze["protocol_sha256"]:
        raise RuntimeError("Confirmatory protocol changed after freeze")
    if _source_digest() != freeze["source_sha256"]:
        raise RuntimeError("MRTA source changed after freeze")
    if _source_inventory() != freeze["source_inventory"]:
        raise RuntimeError("MRTA source inventory changed after freeze")


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _digest_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _digest_json(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def _percentile(values: list[float], probability: float) -> float:
    position = (len(values) - 1) * probability
    lower = int(position)
    upper = min(lower + 1, len(values) - 1)
    fraction = position - lower
    return values[lower] * (1.0 - fraction) + values[upper] * fraction


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def _write_immutable_json(path: Path, payload: dict[str, Any]) -> None:
    serialized = json.dumps(payload, sort_keys=True, indent=2) + "\n"
    if path.exists():
        if path.read_text(encoding="utf-8") != serialized:
            raise RuntimeError(f"Refusing to overwrite non-matching freeze manifest: {path}")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(serialized, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Freeze and analyze the held-out MRTA Main experiment")
    subparsers = parser.add_subparsers(dest="command", required=True)
    freeze_parser = subparsers.add_parser("freeze")
    freeze_parser.add_argument("--config", type=Path, required=True)
    freeze_parser.add_argument("--protocol", type=Path, required=True)
    freeze_parser.add_argument("--output", type=Path, required=True)
    analyze_parser = subparsers.add_parser("analyze")
    analyze_parser.add_argument("--run", type=Path, required=True)
    analyze_parser.add_argument("--freeze", type=Path, required=True)
    analyze_parser.add_argument("--protocol", type=Path, required=True)
    analyze_parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "freeze":
        result = freeze_main(args.config, args.protocol, args.output)
    else:
        result = analyze_main(args.run, args.freeze, args.protocol, args.output)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
