from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Iterable


Point = tuple[int, int]


class RobotRole(str, Enum):
    LR = "LR"
    TR = "TR"
    UR = "UR"


class RobotStatus(str, Enum):
    IDLE = "idle"
    TO_ORIGIN = "to_origin"
    LOADING = "loading"
    IN_TRANSIT = "in_transit"
    UNLOADING = "unloading"
    CHARGING = "charging"
    UNAVAILABLE = "unavailable"


class TransportMode(str, Enum):
    INDIVIDUAL = "individual"
    COALITION = "coalition"
    BATCH = "batch"


@dataclass(slots=True)
class Robot:
    robot_id: str
    role: RobotRole
    position: Point
    capacity: float
    battery: float = 1.0
    status: RobotStatus = RobotStatus.IDLE
    platform_id: str | None = None
    zone_id: str | None = None
    available_at: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Robot":
        return cls(
            robot_id=data["robot_id"],
            role=RobotRole(data["role"]),
            position=tuple(data["position"]),
            capacity=float(data["capacity"]),
            battery=float(data.get("battery", 1.0)),
            status=RobotStatus(data.get("status", "idle")),
            platform_id=data.get("platform_id"),
            zone_id=data.get("zone_id"),
            available_at=int(data.get("available_at", 0)),
        )


@dataclass(slots=True)
class Cargo:
    cargo_id: str
    origin_id: str
    origin: Point
    destination_id: str
    destination: Point
    weight: float
    release_time: int
    deadline: int
    mode: TransportMode
    batch_id: str | None = None
    coalition_size: int = 1
    service_time: int = 2
    cancelled: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Cargo":
        return cls(
            cargo_id=data["cargo_id"],
            origin_id=data["origin_id"],
            origin=tuple(data["origin"]),
            destination_id=data["destination_id"],
            destination=tuple(data["destination"]),
            weight=float(data["weight"]),
            release_time=int(data["release_time"]),
            deadline=int(data["deadline"]),
            mode=TransportMode(data["mode"]),
            batch_id=data.get("batch_id"),
            coalition_size=int(data.get("coalition_size", 1)),
            service_time=int(data.get("service_time", 2)),
            cancelled=bool(data.get("cancelled", False)),
        )


@dataclass(slots=True)
class DynamicEvent:
    event_id: str
    time: int
    event_type: str
    text: str
    payload: dict[str, Any]
    gold_operations: list[dict[str, Any]]
    candidate_operations: list[dict[str, Any]]
    valid: bool = True
    harmful_reason: str | None = None
    template_family: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DynamicEvent":
        return cls(**data)


@dataclass(slots=True)
class WarehouseState:
    scenario_id: str
    width: int
    height: int
    platforms: dict[str, Point]
    destinations: dict[str, Point]
    destination_zones: dict[str, str]
    robots: dict[str, Robot]
    cargos: dict[str, Cargo]
    events: list[DynamicEvent]
    static_blocked_cells: set[Point] = field(default_factory=set)
    dynamic_blocked_cells: set[Point] = field(default_factory=set)
    blocked_edges: set[tuple[Point, Point]] = field(default_factory=set)
    congestion: dict[Point, int] = field(default_factory=dict)
    time: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WarehouseState":
        return cls(
            scenario_id=data["scenario_id"],
            width=int(data["width"]),
            height=int(data["height"]),
            platforms={k: tuple(v) for k, v in data["platforms"].items()},
            destinations={k: tuple(v) for k, v in data["destinations"].items()},
            destination_zones=dict(data["destination_zones"]),
            robots={r["robot_id"]: Robot.from_dict(r) for r in data["robots"]},
            cargos={c["cargo_id"]: Cargo.from_dict(c) for c in data["cargos"]},
            events=[DynamicEvent.from_dict(e) for e in data.get("events", [])],
            static_blocked_cells={tuple(p) for p in data.get("static_blocked_cells", [])},
            dynamic_blocked_cells={tuple(p) for p in data.get("dynamic_blocked_cells", [])},
            blocked_edges={(tuple(a), tuple(b)) for a, b in data.get("blocked_edges", [])},
            congestion={tuple(item["point"]): int(item["penalty"]) for item in data.get("congestion", [])},
            time=int(data.get("time", 0)),
        )

    def to_dict(self) -> dict[str, Any]:
        result = {
            "scenario_id": self.scenario_id,
            "width": self.width,
            "height": self.height,
            "platforms": self.platforms,
            "destinations": self.destinations,
            "destination_zones": self.destination_zones,
            "robots": [asdict(r) for r in self.robots.values()],
            "cargos": [asdict(c) for c in self.cargos.values()],
            "events": [asdict(e) for e in self.events],
            "static_blocked_cells": sorted(self.static_blocked_cells),
            "dynamic_blocked_cells": sorted(self.dynamic_blocked_cells),
            "blocked_edges": sorted(self.blocked_edges),
            "congestion": [
                {"point": point, "penalty": penalty}
                for point, penalty in sorted(self.congestion.items())
            ],
            "time": self.time,
        }
        return _enum_values(result)

    def idle_robots(self, role: RobotRole, at_time: int | None = None) -> list[Robot]:
        now = self.time if at_time is None else at_time
        return sorted(
            (
                r
                for r in self.robots.values()
                if r.role is role
                and r.status is RobotStatus.IDLE
                and r.available_at <= now
                and r.battery > 0.08
            ),
            key=lambda r: r.robot_id,
        )

    def assert_role_invariants(self) -> None:
        for robot in self.robots.values():
            if robot.role is RobotRole.LR:
                if not robot.platform_id or robot.position != self.platforms[robot.platform_id]:
                    raise AssertionError(f"LR {robot.robot_id} left its platform")
            elif robot.role is RobotRole.UR:
                if not robot.zone_id:
                    raise AssertionError(f"UR {robot.robot_id} lacks a shelf zone")


def manhattan(a: Point, b: Point) -> int:
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def canonical_jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): canonical_jsonable(v) for k, v in sorted(value.items(), key=lambda x: str(x[0]))}
    if isinstance(value, (list, tuple, set)):
        return [canonical_jsonable(v) for v in value]
    if isinstance(value, Enum):
        return value.value
    return value


def _enum_values(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, dict):
        return {k: _enum_values(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_enum_values(v) for v in value]
    return value


def cargo_ids(cargos: Iterable[Cargo]) -> tuple[str, ...]:
    return tuple(sorted(c.cargo_id for c in cargos))
