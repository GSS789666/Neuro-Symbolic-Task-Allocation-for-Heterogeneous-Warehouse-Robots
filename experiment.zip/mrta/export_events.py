from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import asdict
from pathlib import Path

from .domain import canonical_jsonable
from .experiment import build_tasks
from .grounding import build_grounding_context
from .scenario import GeneratorConfig, generate_scenario


def export_config_events(config_path: Path, output_path: Path) -> dict:
    config = json.loads(config_path.read_text(encoding="utf-8"))
    tasks = build_tasks(config)
    unique_configs: dict[str, tuple[GeneratorConfig, str]] = {}
    for task in tasks:
        generator = GeneratorConfig(
            scale=task.scale, seed=task.seed, trace_seed=task.trace_seed,
            load_level=task.load_level, disturbance_level=task.disturbance_level,
            horizon=task.horizon,
        )
        unique_configs.setdefault(generator.digest(), (generator, task.split))
    records = []
    for digest, (generator, split) in sorted(unique_configs.items()):
        state = generate_scenario(generator)
        for event in state.events:
            records.append({
                "case_id": f"{state.scenario_id}:{event.event_id}",
                "scenario_id": state.scenario_id, "split": split,
                "generator_config_sha256": digest,
                "grounding_context": build_grounding_context(state, event),
                **asdict(event),
            })
    records.sort(key=lambda record: record["case_id"])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="\n") as stream:
        for record in records:
            stream.write(json.dumps(canonical_jsonable(record), sort_keys=True) + "\n")
    digest = hashlib.sha256(output_path.read_bytes()).hexdigest()
    manifest = {
        "config": str(config_path.resolve()),
        "config_sha256": hashlib.sha256(config_path.read_bytes()).hexdigest(),
        "scenario_count": len(unique_configs), "event_count": len(records),
        "events_sha256": digest, "events_path": str(output_path.resolve()),
    }
    manifest_path = output_path.with_suffix(".manifest.json")
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Export the exact event stream required by an experiment config")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = export_config_events(args.config, args.output)
    print(json.dumps({"status": "ok", **manifest}, indent=2))


if __name__ == "__main__":
    main()
