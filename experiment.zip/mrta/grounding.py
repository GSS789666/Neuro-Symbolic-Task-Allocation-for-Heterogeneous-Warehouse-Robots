from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import tempfile
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .domain import DynamicEvent, RobotRole, WarehouseState, canonical_jsonable
from .knowledge import Atom, KnowledgeError, Rule, VersionedKnowledgeBase


PROMPT_SCHEMA_VERSION = "deepseek-grounding-1.2"
ALLOWED_OPERATIONS = {"insert_fact", "retract_fact", "supersede_fact", "insert_rule"}


class CacheMiss(RuntimeError):
    pass


class GroundingError(RuntimeError):
    pass


@dataclass(frozen=True)
class GroundingResult:
    cache_key: str
    model: str
    candidate: dict[str, Any]
    cache_hit: bool
    latency_ms: float
    request_utc: str | None


class DeepSeekGrounder:
    def __init__(
        self,
        cache_dir: Path,
        model: str = "deepseek-chat",
        base_url: str = "https://api.deepseek.com",
        timeout_s: float = 90.0,
        max_retries: int = 5,
    ) -> None:
        self.cache_dir = cache_dir
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.timeout_s = timeout_s
        self.max_retries = max_retries
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def cache_key(self, text: str, context: dict[str, Any]) -> str:
        payload = {
            "model": self.model,
            "prompt_schema_version": PROMPT_SCHEMA_VERSION,
            "text": text,
            "context": canonical_jsonable(context),
        }
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def ground(
        self,
        text: str,
        context: dict[str, Any],
        offline: bool,
        api_key: str | None = None,
    ) -> GroundingResult:
        key = self.cache_key(text, context)
        path = self.cache_dir / f"{key}.json"
        started = time.perf_counter()
        if path.exists():
            record = json.loads(path.read_text(encoding="utf-8"))
            candidate = validate_candidate(record["candidate"])
            return GroundingResult(key, record["model"], candidate, True, (time.perf_counter() - started) * 1000, record.get("request_utc"))
        if offline:
            raise CacheMiss(f"Missing DeepSeek cache entry {key}; run the resumable prefetch command while online")
        token = api_key or os.environ.get("DEEPSEEK_API_KEY")
        if not token:
            raise GroundingError("DEEPSEEK_API_KEY is not set")
        request_body = self._request_body(text, context)
        last_error: Exception | None = None
        for attempt in range(self.max_retries):
            try:
                response, request_utc = self._post(request_body, token)
                content = response["choices"][0]["message"]["content"]
                candidate = validate_candidate(json.loads(content))
                record = {
                    "cache_key": key, "model": self.model,
                    "prompt_schema_version": PROMPT_SCHEMA_VERSION,
                    "request_utc": request_utc, "candidate": candidate,
                    "usage": response.get("usage"),
                }
                _atomic_json(path, record)
                return GroundingResult(key, self.model, candidate, False, (time.perf_counter() - started) * 1000, request_utc)
            except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, KeyError, json.JSONDecodeError, KnowledgeError, GroundingError) as exc:
                last_error = exc
                if attempt + 1 >= self.max_retries:
                    break
                time.sleep(min(20.0, (2**attempt) + random.random()))
        raise GroundingError(f"DeepSeek request failed after {self.max_retries} attempts: {last_error}")

    def _request_body(self, text: str, context: dict[str, Any]) -> dict[str, Any]:
        schema = {
            "top_level_exact_keys": ["schema_version", "operations", "confidence", "rationale_code"],
            "schema_version_exact_value": PROMPT_SCHEMA_VERSION,
            "operation_contracts": {
                "insert_fact_or_retract_fact": {"exact_keys": ["op", "atom"], "atom": {"predicate": "string", "args": ["typed strings"]}},
                "supersede_fact": {"exact_keys": ["op", "key", "atom"], "key": ["atom argument prefix"], "atom": {"predicate": "string", "args": ["typed strings"]}},
                "insert_rule": {"exact_keys": ["op", "rule"], "rule": {"rule_id": "string", "body": ["atoms"], "head": ["atoms"], "temporary": True, "ttl": 10}},
            },
            "confidence": "number in [0,1]",
            "rationale_code": "short code, at most 80 characters",
        }
        system = (
            "You translate a warehouse event into a JSON symbolic candidate. Output JSON only. "
            "Never issue motor commands, declare an unobserved path clear, remove a safety constraint, "
            "or invent an entity. Use only the supplied ontology and entities. A temporary rule must be "
            "range restricted and may change only eligibility, priority, route penalty, or required checks."
        )
        user = json.dumps({
            "instruction": "Return exactly one JSON object matching output_schema. Use only the exact keys for the selected operation type; omit keys belonging to other operation types.",
            "event_text": text,
            "context": canonical_jsonable(context),
            "output_schema": schema,
        }, ensure_ascii=False, sort_keys=True)
        return {
            "model": self.model,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "response_format": {"type": "json_object"},
            "temperature": 0.0,
            "stream": False,
        }

    def _post(self, body: dict[str, Any], token: str) -> tuple[dict[str, Any], str]:
        from datetime import datetime, timezone

        request_utc = datetime.now(timezone.utc).isoformat()
        request = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_s) as response:
                return json.loads(response.read().decode("utf-8")), request_utc
        except urllib.error.HTTPError as exc:
            safe_body = exc.read(1000).decode("utf-8", errors="replace")
            raise GroundingError(f"HTTP {exc.code}: {safe_body}") from exc


def build_grounding_context(state: WarehouseState, event: DynamicEvent) -> dict[str, Any]:
    robot_id = event.payload.get("robot_id")
    cargo_id = event.payload.get("cargo_id")
    relevant_robot = None
    if robot_id in state.robots:
        robot = state.robots[robot_id]
        relevant_robot = {
            "robot_id": robot.robot_id, "role": robot.role.value,
            "capacity": robot.capacity, "platform_id": robot.platform_id, "zone_id": robot.zone_id,
        }
    relevant_cargo = None
    if cargo_id in state.cargos:
        cargo = state.cargos[cargo_id]
        relevant_cargo = {
            "cargo_id": cargo.cargo_id, "origin_id": cargo.origin_id,
            "destination_id": cargo.destination_id, "weight": cargo.weight,
            "mode": cargo.mode.value, "batch_id": cargo.batch_id,
            "coalition_size": cargo.coalition_size,
        }
    return {
        "scenario_id": state.scenario_id,
        "warehouse": {
            "width": state.width, "height": state.height,
            "platform_ids": sorted(state.platforms),
            "destination_ids": sorted(state.destinations),
        },
        "entity_registry": {
            role.value: sorted(robot.robot_id for robot in state.robots.values() if robot.role is role)
            for role in RobotRole
        } | {"cargo": sorted(state.cargos)},
        "relevant_robot": relevant_robot,
        "relevant_cargo": relevant_cargo,
        "authenticated_payload": canonical_jsonable(event.payload),
        "ontology": {key: list(value) for key, value in sorted(VersionedKnowledgeBase().signatures.items())},
    }


def validate_candidate(candidate: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(candidate, dict):
        raise GroundingError("Candidate must be a JSON object")
    required = {"schema_version", "operations", "confidence", "rationale_code"}
    if set(candidate) != required:
        raise GroundingError(f"Candidate keys must be exactly {sorted(required)}")
    if candidate["schema_version"] != PROMPT_SCHEMA_VERSION:
        raise GroundingError("Prompt schema version mismatch")
    if not isinstance(candidate["operations"], list) or not candidate["operations"]:
        raise GroundingError("operations must be a non-empty list")
    if not isinstance(candidate["confidence"], (int, float)) or not 0 <= candidate["confidence"] <= 1:
        raise GroundingError("confidence must be numeric and in [0,1]")
    if not isinstance(candidate["rationale_code"], str) or len(candidate["rationale_code"]) > 80:
        raise GroundingError("rationale_code must be a short string")
    kb = VersionedKnowledgeBase()
    normalized: list[dict[str, Any]] = []
    for operation in candidate["operations"]:
        if not isinstance(operation, dict) or operation.get("op") not in ALLOWED_OPERATIONS:
            raise GroundingError("Unsupported or malformed operation")
        op = operation["op"]
        if op == "insert_rule":
            if set(operation) != {"op", "rule"}:
                raise GroundingError("insert_rule accepts only op and rule")
            rule = Rule.from_dict(operation["rule"])
            kb.validate_rule(rule)
            normalized.append({"op": op, "rule": rule.to_dict()})
        else:
            allowed = {"op", "atom"} if op != "supersede_fact" else {"op", "atom", "key"}
            if set(operation) != allowed:
                raise GroundingError(f"{op} keys must be exactly {sorted(allowed)}")
            atom = Atom.from_dict(operation["atom"])
            kb.validate_atom(atom)
            item: dict[str, Any] = {"op": op, "atom": atom.to_dict()}
            if op == "supersede_fact":
                item["key"] = [str(value) for value in operation["key"]]
            normalized.append(item)
    return {
        "schema_version": PROMPT_SCHEMA_VERSION,
        "operations": normalized,
        "confidence": float(candidate["confidence"]),
        "rationale_code": candidate["rationale_code"],
    }


def gold_candidate(operations: list[dict[str, Any]]) -> dict[str, Any]:
    """Testing oracle; never used as a substitute for a missing DeepSeek response."""
    return validate_candidate({
        "schema_version": PROMPT_SCHEMA_VERSION,
        "operations": operations,
        "confidence": 1.0,
        "rationale_code": "gold_annotation",
    })


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=path.name, suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(payload, stream, ensure_ascii=False, sort_keys=True, indent=2)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def prefetch_main() -> None:
    parser = argparse.ArgumentParser(description="Resumably prefetch DeepSeek grounding responses")
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/deepseek_cache"))
    parser.add_argument("--model", default=os.environ.get("DEEPSEEK_MODEL", "deepseek-chat"))
    parser.add_argument("--base-url", default=os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com"))
    parser.add_argument("--split", choices=["development", "validation", "test"])
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    grounder = DeepSeekGrounder(args.cache, args.model, args.base_url)
    records = [json.loads(line) for line in args.events.read_text(encoding="utf-8").splitlines() if line.strip()]
    if args.split:
        records = [record for record in records if record["split"] == args.split]
    if args.limit is not None:
        records = records[: args.limit]
    completed = 0
    for index, record in enumerate(records, 1):
        context = record.get("grounding_context") or {
            "scenario_id": record["scenario_id"], "authenticated_payload": record["payload"],
            "ontology": {key: list(value) for key, value in sorted(VersionedKnowledgeBase().signatures.items())},
        }
        try:
            result = grounder.ground(record["text"], context, offline=False)
            completed += 1
            print(json.dumps({"index": index, "total": len(records), "case_id": record["case_id"], "cache_hit": result.cache_hit}))
        except GroundingError as exc:
            print(json.dumps({"index": index, "case_id": record["case_id"], "error": str(exc)}))
    print(json.dumps({"status": "complete" if completed == len(records) else "partial", "completed": completed, "total": len(records)}))


if __name__ == "__main__":
    prefetch_main()
