from __future__ import annotations

import heapq
import copy
import time
from dataclasses import dataclass, field
from typing import Iterable

from .domain import Point, manhattan


class RouteNotFound(RuntimeError):
    pass


class RouteDeadlineExceeded(RouteNotFound):
    """Raised when a route search reaches its caller-supplied wall deadline."""


@dataclass
class ReservationTable:
    vertices: dict[tuple[int, Point], str] = field(default_factory=dict)
    edges: dict[tuple[int, Point, Point], str] = field(default_factory=dict)

    def clone(self) -> "ReservationTable":
        return copy.deepcopy(self)

    def replace_with(self, other: "ReservationTable") -> None:
        self.vertices = dict(other.vertices)
        self.edges = dict(other.edges)

    def conflicts(self, owner: str, source: Point, target: Point, arrival_time: int) -> bool:
        vertex_owner = self.vertices.get((arrival_time, target))
        if vertex_owner is not None and vertex_owner != owner:
            return True
        same_edge_owner = self.edges.get((arrival_time, source, target))
        reverse_edge_owner = self.edges.get((arrival_time, target, source))
        return any(value is not None and value != owner for value in (same_edge_owner, reverse_edge_owner))

    def reserve(self, owner: str, path: list[Point], start_time: int) -> None:
        if not path:
            return
        conflict = self.first_conflict(owner, path, start_time)
        if conflict is not None:
            raise ValueError(conflict)
        for offset, point in enumerate(path):
            time = start_time + offset
            self.vertices[(time, point)] = owner
            if offset:
                source = path[offset - 1]
                self.edges[(time, source, point)] = owner

    def first_conflict(self, owner: str, path: Iterable[Point], start_time: int) -> str | None:
        """Return the first route-reservation conflict without mutating the table."""
        points = list(path)
        for offset, point in enumerate(points):
            time = start_time + offset
            existing = self.vertices.get((time, point))
            if existing is not None and existing != owner:
                return f"Vertex reservation conflict at {point}, t={time}"
            if offset:
                source = points[offset - 1]
                same = self.edges.get((time, source, point))
                reverse = self.edges.get((time, point, source))
                if any(value is not None and value != owner for value in (same, reverse)):
                    return f"Edge reservation conflict at {source}->{point}, t={time}"
        return None

    def can_reserve(self, owner: str, path: Iterable[Point], start_time: int) -> bool:
        return self.first_conflict(owner, path, start_time) is None

    def release(self, owner: str, from_time: int = 0) -> None:
        self.vertices = {key: value for key, value in self.vertices.items() if value != owner or key[0] < from_time}
        self.edges = {key: value for key, value in self.edges.items() if value != owner or key[0] < from_time}

    def assert_conflict_free(self) -> None:
        for (time, source, target), owner in self.edges.items():
            reverse = self.edges.get((time, target, source))
            if reverse is not None and reverse != owner:
                raise AssertionError(f"Head-on conflict between {owner} and {reverse} at t={time}")


@dataclass(frozen=True)
class RoutePlan:
    path: tuple[Point, ...]
    start_time: int
    goals: tuple[Point, ...]
    distance: int
    arrival_time: int
    goal_arrival_times: tuple[int, ...] = ()


class GridRouter:
    def __init__(self, width: int, height: int, static_blocked: Iterable[Point] = ()) -> None:
        self.width = width
        self.height = height
        self.static_blocked = set(static_blocked)

    def route(
        self,
        owner: str,
        start: Point,
        goal: Point,
        start_time: int,
        reservations: ReservationTable,
        dynamic_blocked: set[Point] | None = None,
        blocked_edges: set[tuple[Point, Point]] | None = None,
        congestion: dict[Point, int] | None = None,
        max_extra_time: int = 250,
        wall_deadline: float | None = None,
    ) -> list[Point]:
        if wall_deadline is not None and time.perf_counter() >= wall_deadline:
            raise RouteDeadlineExceeded(f"Route search deadline exceeded before start for {start}->{goal}")
        blocked = self.static_blocked | (dynamic_blocked or set())
        edge_blocks = blocked_edges or set()
        penalties = congestion or {}
        if start in blocked or goal in blocked:
            raise RouteNotFound(f"Start or goal is blocked: {start}->{goal}")
        queue: list[tuple[int, int, int, Point, int]] = []
        sequence = 0
        heapq.heappush(queue, (manhattan(start, goal), 0, sequence, start, start_time))
        came_from: dict[tuple[Point, int], tuple[Point, int] | None] = {(start, start_time): None}
        best_cost: dict[tuple[Point, int], int] = {(start, start_time): 0}
        deadline = start_time + manhattan(start, goal) + max_extra_time

        while queue:
            if wall_deadline is not None and time.perf_counter() >= wall_deadline:
                raise RouteDeadlineExceeded(f"Route search deadline exceeded for {start}->{goal}")
            _, cost, _, current, current_time = heapq.heappop(queue)
            current_state = (current, current_time)
            if best_cost.get(current_state) != cost:
                continue
            if current == goal:
                if wall_deadline is not None and time.perf_counter() >= wall_deadline:
                    raise RouteDeadlineExceeded(f"Route search deadline exceeded before returning {start}->{goal}")
                return _reconstruct(came_from, current_state)
            if current_time >= deadline:
                continue
            for target in self._neighbors(current):
                if target in blocked or (current, target) in edge_blocks or (target, current) in edge_blocks:
                    continue
                arrival = current_time + 1
                if reservations.conflicts(owner, current, target, arrival):
                    continue
                next_state = (target, arrival)
                next_cost = cost + 1 + max(0, penalties.get(target, 0))
                if next_cost >= best_cost.get(next_state, 10**18):
                    continue
                best_cost[next_state] = next_cost
                came_from[next_state] = current_state
                sequence += 1
                priority = next_cost + manhattan(target, goal)
                heapq.heappush(queue, (priority, next_cost, sequence, target, arrival))
        raise RouteNotFound(f"No conflict-free route from {start} to {goal} at t={start_time}")

    def route_through(
        self,
        owner: str,
        start: Point,
        goals: Iterable[Point],
        start_time: int,
        reservations: ReservationTable,
        dynamic_blocked: set[Point] | None = None,
        blocked_edges: set[tuple[Point, Point]] | None = None,
        congestion: dict[Point, int] | None = None,
    ) -> RoutePlan:
        ordered_goals = tuple(goals)
        path = [start]
        goal_arrivals: list[int] = []
        current = start
        time = start_time
        for goal in ordered_goals:
            segment = self.route(
                owner, current, goal, time, reservations,
                dynamic_blocked, blocked_edges, congestion,
            )
            path.extend(segment[1:])
            time += len(segment) - 1
            current = goal
            goal_arrivals.append(time)
        distance = sum(a != b for a, b in zip(path, path[1:]))
        return RoutePlan(tuple(path), start_time, ordered_goals, distance, time, tuple(goal_arrivals))

    def replan_suffix(
        self,
        owner: str,
        current: Point,
        remaining_goals: Iterable[Point],
        now: int,
        reservations: ReservationTable,
        dynamic_blocked: set[Point],
        blocked_edges: set[tuple[Point, Point]],
        congestion: dict[Point, int],
    ) -> RoutePlan:
        reservations.release(owner, from_time=now)
        plan = self.route_through(
            owner, current, remaining_goals, now, reservations,
            dynamic_blocked, blocked_edges, congestion,
        )
        reservations.reserve(owner, list(plan.path), now)
        return plan

    def _neighbors(self, point: Point) -> list[Point]:
        x, y = point
        candidates = [(x + 1, y), (x, y + 1), (x - 1, y), (x, y - 1), (x, y)]
        return [p for p in candidates if 0 <= p[0] < self.width and 0 <= p[1] < self.height]


def _reconstruct(
    came_from: dict[tuple[Point, int], tuple[Point, int] | None],
    state: tuple[Point, int],
) -> list[Point]:
    states = [state]
    while came_from[states[-1]] is not None:
        states.append(came_from[states[-1]])  # type: ignore[arg-type]
    states.reverse()
    return [point for point, _ in states]
