from __future__ import annotations

import argparse
import hashlib
import json
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from . import __version__
from .domain import Cargo, DynamicEvent, Robot, RobotRole, TransportMode, WarehouseState, canonical_jsonable


SCALES: dict[str, dict[str, int]] = {
    "S0": {"platforms": 2, "zones": 4, "lr": 4, "tr": 12, "ur": 8, "cargo": 25},
    "S1": {"platforms": 4, "zones": 8, "lr": 8, "tr": 16, "ur": 16, "cargo": 50},
    "S2": {"platforms": 4, "zones": 8, "lr": 8, "tr": 32, "ur": 16, "cargo": 100},
    "S3": {"platforms": 4, "zones": 8, "lr": 8, "tr": 64, "ur": 24, "cargo": 250},
    "S4": {"platforms": 8, "zones": 16, "lr": 16, "tr": 96, "ur": 32, "cargo": 500},
}


@dataclass(frozen=True)
class GeneratorConfig:
    scale: str
    seed: int
    trace_seed: int | None = None
    load_level: float = 0.60
    disturbance_level: str = "medium"
    horizon: int = 1200
    schema_version: str = "event-schema-1.0"

    def digest(self) -> str:
        raw = json.dumps(asdict(self), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def stable_split(group_key: str) -> str:
    bucket = int(hashlib.sha256(group_key.encode("utf-8")).hexdigest()[:8], 16) % 10
    return "development" if bucket < 6 else "validation" if bucket < 8 else "test"


def generate_scenario(config: GeneratorConfig) -> WarehouseState:
    if config.scale not in SCALES:
        raise ValueError(f"Unknown scale {config.scale}; choose from {sorted(SCALES)}")
    if config.disturbance_level not in {"low", "medium", "high"}:
        raise ValueError("disturbance_level must be low, medium, or high")
    layout_rng = random.Random(config.seed)
    rng = random.Random(config.seed if config.trace_seed is None else config.trace_seed)
    counts = SCALES[config.scale]
    width = 28 if counts["platforms"] <= 4 else 40
    height = max(18, counts["zones"] * 2 + 4)

    platforms = {
        f"P{i:02d}": (1, 2 + i * max(1, (height - 4) // max(1, counts["platforms"] - 1)))
        for i in range(counts["platforms"])
    }
    destination_rows = layout_rng.sample(range(1, height - 1), counts["zones"])
    destinations = {
        f"D{i:02d}": (width - 2 - 2 * (i % 2), destination_rows[i])
        for i in range(counts["zones"])
    }
    destination_zones = {destination: f"Z{i:02d}" for i, destination in enumerate(destinations)}

    robots: dict[str, Robot] = {}
    platform_ids = list(platforms)
    for i in range(counts["lr"]):
        platform_id = platform_ids[i % len(platform_ids)]
        robot = Robot(
            robot_id=f"LR{i:03d}", role=RobotRole.LR, position=platforms[platform_id],
            capacity=3.0, platform_id=platform_id,
        )
        robots[robot.robot_id] = robot
    capacity_mix = ([1.0, 1.0, 2.0, 2.0, 3.0] * ((counts["tr"] + 4) // 5))[: counts["tr"]]
    layout_rng.shuffle(capacity_mix)
    for i in range(counts["tr"]):
        robot = Robot(
            robot_id=f"TR{i:03d}", role=RobotRole.TR,
            position=(3 + i % max(2, width // 3), 1 + (i * 3) % (height - 2)),
            capacity=capacity_mix[i], battery=layout_rng.uniform(0.55, 1.0),
        )
        robots[robot.robot_id] = robot
    destination_ids = list(destinations)
    for i in range(counts["ur"]):
        destination_id = destination_ids[i % len(destination_ids)]
        destination = destinations[destination_id]
        offset_x = 1 + (i // len(destination_ids)) % 2
        offset_y = -1 if (i // len(destination_ids)) % 2 == 0 else 1
        ur_position = (
            max(0, destination[0] - offset_x),
            max(0, min(height - 1, destination[1] + offset_y)),
        )
        robot = Robot(
            robot_id=f"UR{i:03d}", role=RobotRole.UR, position=ur_position,
            capacity=8.0, zone_id=destination_zones[destination_id],
            available_at=layout_rng.randint(0, 60),
        )
        robots[robot.robot_id] = robot

    cargos: dict[str, Cargo] = {}
    count_target = counts["cargo"]
    cargo_index = 0
    batch_index = 0
    while cargo_index < count_target:
        draw = rng.random()
        if draw < 0.18 and cargo_index + 1 < count_target:
            mode = TransportMode.BATCH
            group_size = min(rng.randint(2, 5), count_target - cargo_index)
            batch_id = f"B{batch_index:04d}"
            batch_index += 1
        else:
            mode = TransportMode.COALITION if draw < 0.30 else TransportMode.INDIVIDUAL
            group_size = 1
            batch_id = None
        origin_id = rng.choice(platform_ids)
        base_release = int(rng.expovariate(max(0.02, 0.12 * config.load_level)))
        base_release += int(cargo_index / max(0.05, config.load_level))
        if mode is TransportMode.BATCH:
            batch_weights = _feasible_batch_weights(rng, group_size, max_capacity=max(capacity_mix))
        else:
            batch_weights = []
        atomic_release = min(config.horizon - 20, base_release)
        for group_offset in range(group_size):
            destination_id = rng.choice(destination_ids)
            if mode is TransportMode.COALITION:
                coalition_size = rng.randint(2, 4)
                weight = float(coalition_size * 1.5)
            elif mode is TransportMode.BATCH:
                coalition_size = 1
                weight = batch_weights[group_offset]
            else:
                coalition_size = 1
                weight = rng.choice([0.5, 0.8, 1.0])
            cargo_id = f"C{cargo_index:05d}"
            cargos[cargo_id] = Cargo(
                cargo_id=cargo_id,
                origin_id=origin_id,
                origin=platforms[origin_id],
                destination_id=destination_id,
                destination=destinations[destination_id],
                weight=weight,
                release_time=atomic_release if mode is TransportMode.BATCH else min(config.horizon - 20, base_release + rng.randint(0, 3)),
                deadline=min(config.horizon + 200, base_release + rng.randint(70, 180)),
                mode=mode,
                batch_id=batch_id,
                coalition_size=coalition_size,
                service_time=rng.randint(1, 3),
            )
            cargo_index += 1

    events = _generate_events(rng, config, width, height, robots, cargos)
    trace_seed = config.seed if config.trace_seed is None else config.trace_seed
    scenario_id = f"{config.scale}-{config.seed}-{trace_seed}-{config.digest()[:10]}"
    state = WarehouseState(
        scenario_id=scenario_id,
        width=width,
        height=height,
        platforms=platforms,
        destinations=destinations,
        destination_zones=destination_zones,
        robots=robots,
        cargos=cargos,
        events=events,
    )
    state.assert_role_invariants()
    return state


def _feasible_batch_weights(rng: random.Random, group_size: int, max_capacity: float) -> list[float]:
    """Generate 2--5 cargo weights that fit one TR as an indivisible batch."""
    choices = [0.5, 0.8, 1.0]
    for _ in range(100):
        weights = [float(rng.choice(choices)) for _ in range(group_size)]
        if sum(weights) <= max_capacity:
            return weights
    # The deterministic fallback is feasible even for a five-cargo batch.
    return [0.5] * group_size


def _generate_events(
    rng: random.Random,
    config: GeneratorConfig,
    width: int,
    height: int,
    robots: dict[str, Robot],
    cargos: dict[str, Cargo],
) -> list[DynamicEvent]:
    multiplier = {"low": 0.35, "medium": 0.70, "high": 1.15}[config.disturbance_level]
    event_count = max(4, int(len(cargos) * multiplier))
    templates = ("blocked_cell", "moving_congestion", "robot_unavailable", "low_friction", "access_restriction", "service_time", "cargo_cancelled")
    tr_ids = [rid for rid, robot in robots.items() if robot.role is RobotRole.TR]
    cargo_ids = list(cargos)
    cancellable_ids = [cargo_id for cargo_id, cargo in cargos.items() if cargo.mode is not TransportMode.BATCH]
    events: list[DynamicEvent] = []
    active_end = min(config.horizon - 10, max(cargo.release_time for cargo in cargos.values()) + 100)
    for i in range(event_count):
        event_type = templates[i % len(templates)]
        time = rng.randint(5, max(6, active_end))
        valid = (i % 5) != 0
        family = f"{event_type}-family-{i % 4}"
        if event_type == "blocked_cell":
            point = _corridor_point(rng, cargos, width, height)
            payload = {"point": point, "ttl": rng.randint(8, 25)}
            text = f"A temporary obstacle blocks grid cell ({point[0]}, {point[1]}) for {payload['ttl']} time units."
            operation = {"op": "insert_fact", "atom": {"predicate": "blocked_cell", "args": [str(point[0]), str(point[1]), "true"]}}
        elif event_type == "moving_congestion":
            point = _corridor_point(rng, cargos, width, height)
            penalty = rng.randint(2, 7)
            payload = {"point": point, "penalty": penalty, "ttl": rng.randint(5, 15)}
            text = f"A moving worker creates congestion level {penalty} near cell ({point[0]}, {point[1]})."
            operation = {"op": "supersede_fact", "key": [str(point[0]), str(point[1])], "atom": {"predicate": "congestion", "args": [str(point[0]), str(point[1]), str(penalty)]}}
        elif event_type == "robot_unavailable":
            robot_id = rng.choice(tr_ids)
            payload = {"robot_id": robot_id, "ttl": rng.randint(8, 30)}
            text = f"Transport robot {robot_id} is unavailable for {payload['ttl']} time units."
            operation = {"op": "supersede_fact", "key": [robot_id], "atom": {"predicate": "robot_status", "args": [robot_id, "unavailable"]}}
        elif event_type == "low_friction":
            point = _corridor_point(rng, cargos, width, height)
            payload = {"point": point, "coefficient": 0.18, "ttl": rng.randint(12, 35)}
            text = f"Sensors report a low-friction surface with coefficient 0.18 at cell ({point[0]}, {point[1]})."
            operation = {"op": "insert_fact", "atom": {"predicate": "surface_condition", "args": [str(point[0]), str(point[1]), "low_friction"]}}
        elif event_type == "access_restriction":
            point = _corridor_point(rng, cargos, width, height)
            payload = {"point": point, "role": "TR", "ttl": rng.randint(10, 30)}
            text = f"Cell ({point[0]}, {point[1]}) is temporarily restricted for transport robots."
            operation = {"op": "insert_fact", "atom": {"predicate": "access_restricted", "args": [str(point[0]), str(point[1]), "TR"]}}
        elif event_type == "service_time":
            cargo_id = rng.choice(cargo_ids)
            value = rng.randint(3, 7)
            payload = {"cargo_id": cargo_id, "service_time": value}
            text = f"The unloading service time for cargo {cargo_id} is updated to {value} time units."
            operation = {"op": "supersede_fact", "key": [cargo_id], "atom": {"predicate": "service_time", "args": [cargo_id, str(value)]}}
        else:
            cargo_id = rng.choice(cancellable_ids or cargo_ids)
            payload = {"cargo_id": cargo_id}
            text = f"Cargo request {cargo_id} has been cancelled by the warehouse management system."
            operation = {"op": "insert_fact", "atom": {"predicate": "cargo_cancelled", "args": [cargo_id, "true"]}}

        harmful_reason = None
        candidate_operation = operation
        if not valid:
            harmful_reason = "semantically_false_but_schema_valid"
            candidate_operation = _invert_operation(operation)
        events.append(DynamicEvent(
            event_id=f"E{config.seed}-{config.trace_seed if config.trace_seed is not None else config.seed}-{i:05d}", time=time, event_type=event_type,
            text=text, payload=payload, gold_operations=[operation], candidate_operations=[candidate_operation], valid=valid,
            harmful_reason=harmful_reason, template_family=family,
        ))
    return sorted(events, key=lambda event: (event.time, event.event_id))


def _corridor_point(
    rng: random.Random,
    cargos: dict[str, Cargo],
    width: int,
    height: int,
) -> list[int]:
    """Sample a non-terminal cell from a likely origin-to-shelf traffic corridor."""
    cargo = rng.choice(list(cargos.values()))
    low_x = max(3, min(cargo.origin[0], cargo.destination[0]) + 2)
    high_x = min(width - 4, max(cargo.origin[0], cargo.destination[0]) - 1)
    x = rng.randint(low_x, max(low_x, high_x))
    y = max(1, min(height - 2, cargo.origin[1]))
    return [x, y]


def _invert_operation(operation: dict[str, Any]) -> dict[str, Any]:
    altered = json.loads(json.dumps(operation))
    atom = altered.get("atom", {})
    args = atom.get("args", [])
    if args:
        value = args[-1]
        if value in {"true", "false"}:
            args[-1] = "false" if value == "true" else "true"
        elif value.lstrip("-").isdigit():
            args[-1] = str(int(value) + 1)
        elif value == "unavailable":
            args[-1] = "idle"
        elif value == "low_friction":
            args[-1] = "normal"
        elif value == "TR":
            args[-1] = "UR"
        else:
            raise ValueError(f"No type-preserving adversarial mutation for {value!r}")
    return altered


def write_dataset(output_dir: Path, configs: list[GeneratorConfig]) -> dict[str, Any]:
    from .grounding import build_grounding_context

    output_dir.mkdir(parents=True, exist_ok=True)
    scenario_dir = output_dir / "scenarios"
    scenario_dir.mkdir(exist_ok=True)
    event_records: list[dict[str, Any]] = []
    manifest: dict[str, Any] = {"generator_version": __version__, "files": [], "configurations": []}
    for config in configs:
        state = generate_scenario(config)
        scenario_path = scenario_dir / f"{state.scenario_id}.json"
        scenario_path.write_text(json.dumps(canonical_jsonable(state.to_dict()), indent=2, sort_keys=True), encoding="utf-8")
        digest = hashlib.sha256(scenario_path.read_bytes()).hexdigest()
        manifest["files"].append({"path": scenario_path.relative_to(output_dir).as_posix(), "sha256": digest})
        manifest["configurations"].append({**asdict(config), "config_sha256": config.digest(), "scenario_id": state.scenario_id})
        map_family = f"{config.scale}-map-{config.seed % 20}"
        split = stable_split(map_family)
        for event in state.events:
            event_records.append({
                "case_id": f"{state.scenario_id}:{event.event_id}",
                "generator_version": __version__, "schema_version": config.schema_version,
                "scenario_id": state.scenario_id, "map_seed": config.seed,
                "event_seed": config.seed if config.trace_seed is None else config.trace_seed, "map_family": map_family,
                "split": split, "grounding_context": build_grounding_context(state, event), **asdict(event),
            })
    event_path = output_dir / "events.jsonl"
    with event_path.open("w", encoding="utf-8", newline="\n") as stream:
        for record in sorted(event_records, key=lambda x: x["case_id"]):
            stream.write(json.dumps(canonical_jsonable(record), sort_keys=True) + "\n")
    manifest["files"].append({"path": event_path.name, "sha256": hashlib.sha256(event_path.read_bytes()).hexdigest()})
    manifest["event_count"] = len(event_records)
    manifest_path = output_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate deterministic LR-TR-UR benchmark data")
    parser.add_argument("--output", type=Path, default=Path("data/generated"))
    parser.add_argument("--scales", nargs="+", default=["S0", "S1", "S2"])
    parser.add_argument("--seeds", nargs="+", type=int)
    parser.add_argument("--seed-start", type=int, default=1001)
    parser.add_argument("--seed-count", type=int, default=120)
    parser.add_argument("--horizon", type=int, default=1200)
    args = parser.parse_args()
    seeds = args.seeds if args.seeds else range(args.seed_start, args.seed_start + args.seed_count)
    configs = [GeneratorConfig(scale=scale, seed=seed, horizon=args.horizon) for scale in args.scales for seed in seeds]
    manifest = write_dataset(args.output, configs)
    print(json.dumps({"status": "ok", "output": str(args.output), "events": manifest["event_count"], "files": len(manifest["files"])}, indent=2))


if __name__ == "__main__":
    main()
