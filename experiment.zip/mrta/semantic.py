from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any

from .grounding import CacheMiss, DeepSeekGrounder, GroundingError, PROMPT_SCHEMA_VERSION, validate_candidate
from .knowledge import KnowledgeError, VersionedKnowledgeBase


def compile_authenticated_payload(event_type: str, payload: dict[str, Any]) -> list[dict[str, Any]]:
    if event_type == "blocked_cell":
        x, y = payload["point"]
        return [{"op": "insert_fact", "atom": {"predicate": "blocked_cell", "args": [str(x), str(y), "true"]}}]
    if event_type == "moving_congestion":
        x, y = payload["point"]
        return [{"op": "supersede_fact", "key": [str(x), str(y)], "atom": {"predicate": "congestion", "args": [str(x), str(y), str(payload["penalty"])]}}]
    if event_type == "robot_unavailable":
        robot_id = payload["robot_id"]
        return [{"op": "supersede_fact", "key": [robot_id], "atom": {"predicate": "robot_status", "args": [robot_id, "unavailable"]}}]
    if event_type == "low_friction":
        x, y = payload["point"]
        return [{"op": "insert_fact", "atom": {"predicate": "surface_condition", "args": [str(x), str(y), "low_friction"]}}]
    if event_type == "access_restriction":
        x, y = payload["point"]
        return [{"op": "insert_fact", "atom": {"predicate": "access_restricted", "args": [str(x), str(y), str(payload["role"])]}}]
    if event_type == "service_time":
        cargo_id = payload["cargo_id"]
        return [{"op": "supersede_fact", "key": [cargo_id], "atom": {"predicate": "service_time", "args": [cargo_id, str(payload["service_time"])]}}]
    if event_type == "cargo_cancelled":
        cargo_id = payload["cargo_id"]
        return [{"op": "insert_fact", "atom": {"predicate": "cargo_cancelled", "args": [cargo_id, "true"]}}]
    raise ValueError(f"Unknown event type {event_type}")


def evaluate_events(
    events_path: Path,
    source: str,
    cache_dir: Path | None = None,
    model: str = "deepseek-chat",
    split: str | None = None,
    limit: int | None = None,
) -> dict[str, Any]:
    records = [json.loads(line) for line in events_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if split:
        records = [record for record in records if record["split"] == split]
    if limit is not None:
        records = records[:limit]
    grounder = DeepSeekGrounder(cache_dir or Path("data/deepseek_cache"), model=model) if source == "deepseek_cache" else None
    counts: Counter[str] = Counter()
    predicted_predicates: Counter[str] = Counter()
    gold_predicates: Counter[str] = Counter()
    true_predicates: Counter[str] = Counter()
    errors: list[dict[str, str]] = []
    for record in records:
        counts["total"] += 1
        expected_from_payload = compile_authenticated_payload(record["event_type"], record["payload"])
        if _canonical_ops(expected_from_payload) != _canonical_ops(record["gold_operations"]):
            raise AssertionError(f"Gold annotation disagrees with authenticated payload in {record['case_id']}")
        if source == "dataset_candidates":
            raw_candidate = {
                "schema_version": PROMPT_SCHEMA_VERSION,
                "operations": record["candidate_operations"],
                "confidence": 1.0,
                "rationale_code": "generated_adversarial_candidate",
            }
        elif source == "deepseek_cache":
            context = record.get("grounding_context") or {
                "scenario_id": record["scenario_id"], "authenticated_payload": record["payload"],
                "ontology": {key: list(value) for key, value in sorted(VersionedKnowledgeBase().signatures.items())},
            }
            try:
                raw_candidate = grounder.ground(record["text"], context, offline=True).candidate  # type: ignore[union-attr]
                counts["cache_hits"] += 1
            except (GroundingError, CacheMiss) as exc:
                counts["cache_or_grounding_error"] += 1
                errors.append({"case_id": record["case_id"], "error": str(exc)})
                continue
        else:
            raise ValueError("source must be dataset_candidates or deepseek_cache")
        try:
            candidate = validate_candidate(raw_candidate)
            counts["schema_valid"] += 1
        except (GroundingError, KnowledgeError) as exc:
            errors.append({"case_id": record["case_id"], "error": str(exc)})
            continue
        try:
            kb = VersionedKnowledgeBase()
            tx = kb.commit("evaluation", 0, candidate["operations"], "candidate", candidate["confidence"])
            if tx.committed and not tx.quarantined_rules:
                counts["logic_valid"] += 1
        except Exception as exc:
            errors.append({"case_id": record["case_id"], "error": str(exc)})
            continue
        predicted = _canonical_ops(candidate["operations"])
        gold = _canonical_ops(record["gold_operations"])
        semantic_correct = predicted == gold
        if semantic_correct:
            counts["exact_match"] += 1
        harmful = not semantic_correct
        shield_accept = predicted == _canonical_ops(expected_from_payload)
        if harmful:
            counts["harmful_proposed"] += 1
            if shield_accept:
                counts["harmful_committed"] += 1
        else:
            counts["valid_proposed"] += 1
            if not shield_accept:
                counts["valid_rejected"] += 1
        for operation in candidate["operations"]:
            predicate = operation.get("atom", {}).get("predicate", "rule")
            predicted_predicates[predicate] += 1
        for operation in record["gold_operations"]:
            predicate = operation.get("atom", {}).get("predicate", "rule")
            gold_predicates[predicate] += 1
        for predicate in predicted_predicates.keys() & gold_predicates.keys():
            true_predicates[predicate] = min(predicted_predicates[predicate], gold_predicates[predicate])

    true_positive = sum(true_predicates.values())
    precision = true_positive / sum(predicted_predicates.values()) if predicted_predicates else None
    recall = true_positive / sum(gold_predicates.values()) if gold_predicates else None
    f1 = 2 * precision * recall / (precision + recall) if precision is not None and recall is not None and precision + recall else None
    evaluated = counts["schema_valid"]
    return {
        "provenance": "measured_deepseek_cache" if source == "deepseek_cache" else "simulated_generated_candidates",
        "source": source, "split": split, "event_file": str(events_path),
        "counts": dict(counts),
        "syntactic_validity": counts["schema_valid"] / counts["total"] if counts["total"] else None,
        "logical_consistency": counts["logic_valid"] / evaluated if evaluated else None,
        "semantic_exact_match": counts["exact_match"] / evaluated if evaluated else None,
        "predicate_micro_precision": precision, "predicate_micro_recall": recall,
        "predicate_micro_f1": f1,
        "harmful_false_accept_rate": counts["harmful_committed"] / counts["harmful_proposed"] if counts["harmful_proposed"] else None,
        "valid_false_reject_rate": counts["valid_rejected"] / counts["valid_proposed"] if counts["valid_proposed"] else None,
        "errors": errors[:100],
    }


def _canonical_ops(operations: list[dict[str, Any]]) -> str:
    return json.dumps(operations, sort_keys=True, separators=(",", ":"))


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate semantic grounding and the deterministic shield")
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--source", choices=["dataset_candidates", "deepseek_cache"], required=True)
    parser.add_argument("--cache", type=Path, default=Path("data/deepseek_cache"))
    parser.add_argument("--model", default="deepseek-chat")
    parser.add_argument("--split", choices=["development", "validation", "test"])
    parser.add_argument("--limit", type=int)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = evaluate_events(args.events, args.source, args.cache, args.model, args.split, args.limit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({"status": "ok", "output": str(args.output), "events": result["counts"].get("total", 0)}, indent=2))


if __name__ == "__main__":
    main()
