from __future__ import annotations

import copy
import hashlib
import json
import math
import statistics
import time
from collections import Counter
from dataclasses import asdict, dataclass, field
from typing import Any

from .domain import DynamicEvent, Point, RobotRole, RobotStatus, TransportMode, WarehouseState
from .grounding import DeepSeekGrounder, build_grounding_context
from .knowledge import Atom, VersionedKnowledgeBase
from .routing import GridRouter, ReservationTable
from .semantic import compile_authenticated_payload
from .solver import (
    DispatchCandidate,
    StageBFailure,
    StageBResult,
    URReservationTable,
    bind_stage_b,
    solve_stage_a,
)


METHOD_CONTRACTS = {
    "greedy": "greedy allocation; mandatory physical safety updates; no symbolic constraints or soft-event costs",
    "static_cp_sat": "CP-SAT allocation; mandatory physical safety updates; no symbolic constraints or soft-event costs",
    "static_mivar_cp_sat": "CP-SAT plus fixed Mivar-inspired reserve/eligibility policy; no runtime KB event writes",
    "dynamic_facts_cp_sat": "fixed symbolic policy plus versioned runtime fact writes used by allocation and routing",
    "dynamic_rules_cp_sat": "dynamic facts plus quarantined temporary rules whose derived penalties enter routing",
}
SYMBOLIC_METHODS = {"static_mivar_cp_sat", "dynamic_facts_cp_sat", "dynamic_rules_cp_sat"}
DYNAMIC_FACT_METHODS = {"dynamic_facts_cp_sat", "dynamic_rules_cp_sat"}
SOFT_REPLAN_METHODS = {"dynamic_facts_cp_sat", "dynamic_rules_cp_sat"}


@dataclass
class Mission:
    dispatch: DispatchCandidate
    state: str
    loading_finish: int
    transport_start: int | None = None
    stage_b: StageBResult | None = None
    completion_time: int | None = None
    next_stop_index: int = 0
    distance_before_replan: int = 0
    next_stage_b_retry: int = 0
    paused_index: int | None = None
    pending_disturbances: dict[str, dict[str, Any]] = field(default_factory=dict)
    attempted_recovery_events: set[str] = field(default_factory=set)
    successful_recovery_events: set[str] = field(default_factory=set)


@dataclass(frozen=True)
class EpisodeResult:
    scenario_id: str
    method: str
    method_contract: str
    seed: int
    scale: str
    load_level: float
    disturbance_level: str
    dataset_split: str
    horizon: int
    cargo_total: int
    cargo_completed: int
    cargo_cancelled: int
    cargo_pending: int
    structurally_infeasible_cargo_count: int
    mode_metrics: dict[str, dict[str, Any]]
    throughput_per_100_ticks: float
    makespan: int | None
    deadline_miss_rate: float | None
    travel_distance_per_cargo: float | None
    energy_proxy: float
    low_friction_exposure_ticks: int
    moving_congestion_exposure_ticks: int
    low_reserve_tr_assignments: int
    tr_wait_for_ur_mean: float | None
    tr_wait_for_ur_positive_count: int
    stage_a_latency_p50_ms: float | None
    stage_a_latency_p95_ms: float | None
    stage_a_latency_p99_ms: float | None
    stage_a_empty_latency_p95_ms: float | None
    stage_b_latency_p95_ms: float | None
    stage_b_failure_latency_p95_ms: float | None
    stage_a_attempts: int
    stage_a_nonempty_calls: int
    stage_a_no_candidate_calls: int
    stage_a_status_counts: dict[str, int]
    stage_b_attempts: int
    stage_b_successes: int
    stage_b_failures: int
    stage_b_status_counts: dict[str, int]
    solver_invocations: int
    timeout_count: int
    fallback_count: int
    safe_wait_ticks: int
    hard_violations: int
    recovery_attempts: int
    recovery_successes: int
    recovery_rate: float | None
    event_response_mean_ticks: float | None
    event_response_p95_ticks: float | None
    kb_versions: int
    quarantined_rules: int
    constraint_source_count: int
    derived_constraint_source_count: int
    proof_trace_coverage: float | None
    wall_time_s: float


class WarehouseSimulator:
    def __init__(
        self,
        state: WarehouseState,
        method: str,
        timeout_s: float = 1.0,
        grounder: DeepSeekGrounder | None = None,
        offline_llm: bool = True,
        audit_schema: str = "mrta-audit-2.0",
        load_level: float = 0.0,
        disturbance_level: str = "unknown",
        dataset_split: str = "unknown",
    ) -> None:
        if method not in METHOD_CONTRACTS and not method.startswith("deepseek_"):
            raise ValueError(f"Unknown experiment method: {method}")
        self.state = copy.deepcopy(state)
        self.method = method
        self.timeout_s = timeout_s
        self.grounder = grounder
        self.offline_llm = offline_llm
        self.audit_schema = audit_schema
        self.load_level = load_level
        self.disturbance_level = disturbance_level
        self.dataset_split = dataset_split
        if method.startswith("deepseek_") and grounder is None:
            raise ValueError("A DeepSeekGrounder is required for a deepseek_* method")
        self.router = GridRouter(state.width, state.height, state.static_blocked_cells)
        self.reservations = ReservationTable()
        self.ur_reservations = URReservationTable()
        self.kb = VersionedKnowledgeBase()
        self.missions: dict[str, Mission] = {}
        self.assigned: set[str] = set()
        self.completed: dict[str, int] = {}
        self.audit: list[dict[str, Any]] = []
        self.stage_a_latencies: list[float] = []
        self.stage_a_empty_latencies: list[float] = []
        self.stage_b_latencies: list[float] = []
        self.stage_b_failure_latencies: list[float] = []
        self.wait_for_ur: list[int] = []
        self.event_response_ticks: list[int] = []
        self.distance_total = 0
        self.mode_distance: Counter[str] = Counter()
        self.energy_proxy = 0.0
        self.low_friction_exposure_ticks = 0
        self.moving_congestion_exposure_ticks = 0
        self.low_reserve_tr_assignments = 0
        self.timeout_count = 0
        self.fallback_count = 0
        self.safe_wait_ticks = 0
        self.hard_violations = 0
        self.recovery_attempts = 0
        self.recovery_successes = 0
        self.stage_a_attempts = 0
        self.stage_a_nonempty_calls = 0
        self.stage_a_no_candidate_calls = 0
        self.stage_b_attempts = 0
        self.stage_b_successes = 0
        self.stage_b_failures = 0
        self.stage_a_status_counts: Counter[str] = Counter()
        self.stage_b_status_counts: Counter[str] = Counter()
        self.blocked_expiry: dict[Point, int] = {}
        self.congestion_expiry: dict[Point, int] = {}
        self.low_friction_expiry: dict[Point, int] = {}
        self.low_friction_cells: set[Point] = set()
        self.moving_congestion_expiry: dict[Point, int] = {}
        self.moving_congestion_cells: set[Point] = set()
        self.unavailable_expiry: dict[str, int] = {}
        self.kb_expiry: dict[int, list[dict[str, Any]]] = {}
        self.constraint_sources: dict[str, dict[str, Any]] = {}
        self.used_derived_atoms: set[Atom] = set()
        self.traced_derived_atoms: set[Atom] = set()
        self.next_allocation_time = 0
        self._event_cursor = 0
        self._initialize_knowledge()

    def run(self, horizon: int) -> tuple[EpisodeResult, list[dict[str, Any]]]:
        wall_started = time.perf_counter()
        for now in range(horizon + 1):
            self.state.time = now
            self._expire_temporary_state(now)
            self._apply_due_events(now)
            self._advance_missions(now)
            self._allocate(now)
            self._assert_invariants(now)
        completed_cargos = list(self.completed)
        misses = sum(self.completed[cargo_id] > self.state.cargos[cargo_id].deadline for cargo_id in completed_cargos)
        cancelled = sum(cargo.cancelled for cargo in self.state.cargos.values())
        pending = len(self.state.cargos) - len(completed_cargos) - cancelled
        structurally_infeasible = self._structurally_infeasible_cargo_count()
        mode_metrics = self._mode_metrics()
        proof_coverage = (
            len(self.traced_derived_atoms) / len(self.used_derived_atoms)
            if self.used_derived_atoms else None
        )
        result = EpisodeResult(
            scenario_id=self.state.scenario_id,
            method=self.method,
            method_contract=METHOD_CONTRACTS.get(self.method, "cached DeepSeek grounding plus validated dynamic fact/rule transactions"),
            seed=int(self.state.scenario_id.split("-")[1]),
            scale=self.state.scenario_id.split("-")[0],
            load_level=self.load_level,
            disturbance_level=self.disturbance_level,
            dataset_split=self.dataset_split,
            horizon=horizon,
            cargo_total=len(self.state.cargos),
            cargo_completed=len(completed_cargos),
            cargo_cancelled=cancelled,
            cargo_pending=pending,
            structurally_infeasible_cargo_count=structurally_infeasible,
            mode_metrics=mode_metrics,
            throughput_per_100_ticks=100.0 * len(completed_cargos) / max(1, horizon),
            makespan=max(self.completed.values()) if self.completed else None,
            deadline_miss_rate=misses / len(completed_cargos) if completed_cargos else None,
            travel_distance_per_cargo=self.distance_total / len(completed_cargos) if completed_cargos else None,
            energy_proxy=self.energy_proxy,
            low_friction_exposure_ticks=self.low_friction_exposure_ticks,
            moving_congestion_exposure_ticks=self.moving_congestion_exposure_ticks,
            low_reserve_tr_assignments=self.low_reserve_tr_assignments,
            tr_wait_for_ur_mean=statistics.fmean(self.wait_for_ur) if self.wait_for_ur else None,
            tr_wait_for_ur_positive_count=sum(value > 0 for value in self.wait_for_ur),
            stage_a_latency_p50_ms=_percentile(self.stage_a_latencies, 0.50),
            stage_a_latency_p95_ms=_percentile(self.stage_a_latencies, 0.95),
            stage_a_latency_p99_ms=_percentile(self.stage_a_latencies, 0.99),
            stage_a_empty_latency_p95_ms=_percentile(self.stage_a_empty_latencies, 0.95),
            stage_b_latency_p95_ms=_percentile(self.stage_b_latencies, 0.95),
            stage_b_failure_latency_p95_ms=_percentile(self.stage_b_failure_latencies, 0.95),
            stage_a_attempts=self.stage_a_attempts,
            stage_a_nonempty_calls=self.stage_a_nonempty_calls,
            stage_a_no_candidate_calls=self.stage_a_no_candidate_calls,
            stage_a_status_counts=dict(self.stage_a_status_counts),
            stage_b_attempts=self.stage_b_attempts,
            stage_b_successes=self.stage_b_successes,
            stage_b_failures=self.stage_b_failures,
            stage_b_status_counts=dict(self.stage_b_status_counts),
            solver_invocations=self.stage_a_nonempty_calls if self.method != "greedy" else 0,
            timeout_count=self.timeout_count,
            fallback_count=self.fallback_count,
            safe_wait_ticks=self.safe_wait_ticks,
            hard_violations=self.hard_violations,
            recovery_attempts=self.recovery_attempts,
            recovery_successes=self.recovery_successes,
            recovery_rate=self.recovery_successes / self.recovery_attempts if self.recovery_attempts else None,
            event_response_mean_ticks=statistics.fmean(self.event_response_ticks) if self.event_response_ticks else None,
            event_response_p95_ticks=_percentile([float(value) for value in self.event_response_ticks], 0.95),
            kb_versions=self.kb.version,
            quarantined_rules=len(self.kb.quarantine),
            constraint_source_count=len(self.constraint_sources),
            derived_constraint_source_count=len(self.used_derived_atoms),
            proof_trace_coverage=proof_coverage,
            wall_time_s=time.perf_counter() - wall_started,
        )
        self.audit.append({
            "time": horizon,
            "kind": "episode_summary",
            "method": self.method,
            "result": asdict(result),
            "audit_schema": self.audit_schema,
        })
        return result, self.audit

    def _initialize_knowledge(self) -> None:
        if self.method not in SYMBOLIC_METHODS and not self.method.startswith("deepseek_"):
            return
        operations: list[dict[str, Any]] = [
            {
                "op": "insert_rule",
                "rule": {
                    "rule_id": "core_low_friction_safety_check",
                    "body": [{"predicate": "surface_condition", "args": ["?x", "?y", "low_friction"]}],
                    "head": [{"predicate": "requires_safety_check", "args": ["?x", "?y", "true"]}],
                    "temporary": False,
                },
            },
            {
                "op": "insert_rule",
                "rule": {
                    "rule_id": "core_low_reserve_exclusion",
                    "body": [
                        {"predicate": "battery_reserve_low", "args": ["?r", "true"]},
                        {"predicate": "cargo_known", "args": ["?c", "true"]},
                    ],
                    "head": [{"predicate": "robot_eligible", "args": ["?r", "?c", "false"]}],
                    "temporary": False,
                },
            },
        ]
        for robot in sorted(self.state.robots.values(), key=lambda item: item.robot_id):
            if robot.role is RobotRole.TR and robot.battery < 0.60:
                operations.append({
                    "op": "insert_fact",
                    "atom": {"predicate": "battery_reserve_low", "args": [robot.robot_id, "true"]},
                })
        for cargo in sorted(self.state.cargos.values(), key=lambda item: item.cargo_id):
            operations.append({
                "op": "insert_fact",
                "atom": {"predicate": "cargo_known", "args": [cargo.cargo_id, "true"]},
            })
        result = self.kb.commit("init-core", 0, operations, "core_policy")
        self.audit.append({
            "time": 0, "kind": "kb_initialization", "kb_version": result.version,
            "method": self.method, "operation_count": result.applied_operations,
        })

    def _apply_due_events(self, now: int) -> None:
        events = self.state.events
        while self._event_cursor < len(events) and events[self._event_cursor].time <= now:
            event = events[self._event_cursor]
            self._event_cursor += 1
            self._apply_event(event, now)

    def _apply_event(self, event: DynamicEvent, now: int) -> None:
        payload = event.payload
        ttl = int(payload.get("ttl", 0))
        point = tuple(payload["point"]) if "point" in payload else None
        semantic_accept = True
        candidate_audit: dict[str, Any] | None = None
        operations: list[dict[str, Any]] = []
        transaction_source: str | None = None
        transaction_confidence = 1.0
        if self.method.startswith("deepseek_"):
            context = build_grounding_context(self.state, event)
            grounding = self.grounder.ground(event.text, context, offline=self.offline_llm)  # type: ignore[union-attr]
            candidate = grounding.candidate
            expected = compile_authenticated_payload(event.event_type, payload)
            fact_operations = [operation for operation in candidate["operations"] if operation["op"] != "insert_rule"]
            semantic_accept = _canonical(fact_operations) == _canonical(expected)
            candidate_audit = {
                "cache_key": grounding.cache_key,
                "cache_hit": grounding.cache_hit,
                "model": grounding.model,
                "semantic_shield_accept": semantic_accept,
                "operations": candidate["operations"],
            }
            if semantic_accept:
                operations = copy.deepcopy(candidate["operations"])
                transaction_source = "deepseek_validated"
                transaction_confidence = float(candidate["confidence"])
        elif self.method in DYNAMIC_FACT_METHODS:
            operations = copy.deepcopy(event.gold_operations)
            transaction_source = "authenticated_event"
            if self.method == "dynamic_rules_cp_sat" and event.event_type == "low_friction":
                operations.append({
                    "op": "insert_rule",
                    "rule": {
                        "rule_id": f"temporary_route_penalty_{event.event_id}",
                        "body": [{"predicate": "surface_condition", "args": ["?x", "?y", "low_friction"]}],
                        "head": [{"predicate": "route_penalty", "args": ["?x", "?y", "9"]}],
                        "temporary": True,
                        "ttl": ttl,
                    },
                })

        kb_version = self.kb.version
        if operations:
            inverse = self._inverse_operations(operations)
            result = self.kb.commit(
                f"event-{event.event_id}", self.kb.version, operations,
                transaction_source or "authenticated_event",
                transaction_confidence,
            )
            kb_version = result.version
            if ttl > 0:
                self.kb_expiry.setdefault(now + ttl, []).extend(inverse)

        physical_accept = semantic_accept if self.method.startswith("deepseek_") else True
        if event.event_type in {"blocked_cell", "access_restriction"} and point is not None:
            self.state.dynamic_blocked_cells.add(point)
            self.blocked_expiry[point] = max(self.blocked_expiry.get(point, 0), now + ttl)
        elif event.event_type in {"moving_congestion", "low_friction"} and point is not None:
            penalty = int(payload.get("penalty", 8 if event.event_type == "low_friction" else 1))
            self.state.congestion[point] = max(self.state.congestion.get(point, 0), penalty)
            self.congestion_expiry[point] = max(self.congestion_expiry.get(point, 0), now + ttl)
            if event.event_type == "low_friction":
                self.low_friction_cells.add(point)
                self.low_friction_expiry[point] = max(self.low_friction_expiry.get(point, 0), now + ttl)
            else:
                self.moving_congestion_cells.add(point)
                self.moving_congestion_expiry[point] = max(
                    self.moving_congestion_expiry.get(point, 0), now + ttl,
                )
        elif event.event_type == "robot_unavailable":
            robot_id = payload["robot_id"]
            robot = self.state.robots[robot_id]
            if robot.status is RobotStatus.IDLE:
                robot.status = RobotStatus.UNAVAILABLE
                self.unavailable_expiry[robot_id] = now + ttl
        elif event.event_type == "service_time" and physical_accept:
            cargo_id = payload["cargo_id"]
            if cargo_id not in self.assigned:
                self.state.cargos[cargo_id].service_time = int(payload["service_time"])
        elif event.event_type == "cargo_cancelled" and physical_accept:
            cargo_id = payload["cargo_id"]
            if cargo_id not in self.assigned:
                self.state.cargos[cargo_id].cancelled = True

        affected = self._find_affected_missions(point, event)
        for mission in affected:
            mission.pending_disturbances[event.event_id] = {
                "event_id": event.event_id, "time": now,
                "event_type": event.event_type, "point": point,
            }
        self.next_allocation_time = min(self.next_allocation_time, now)
        self.audit.append({
            "time": now,
            "kind": "event_commit",
            "event_id": event.event_id,
            "event_type": event.event_type,
            "kb_version": kb_version,
            "kb_write_applied": bool(operations),
            "affected_missions": [mission.dispatch.candidate_id for mission in affected],
            "grounding": candidate_audit,
        })

    def _find_affected_missions(self, point: Point | None, event: DynamicEvent) -> list[Mission]:
        affected: list[Mission] = []
        for mission in self.missions.values():
            if mission.state not in {"in_transit", "awaiting_replan"} or mission.stage_b is None:
                continue
            if point is not None and point in mission.stage_b.route.path:
                affected.append(mission)
            elif event.event_type == "robot_unavailable" and event.payload["robot_id"] in mission.dispatch.tr_ids:
                affected.append(mission)
        return affected

    def _expire_temporary_state(self, now: int) -> None:
        inverse = self.kb_expiry.pop(now, [])
        if inverse:
            self.kb.commit(f"expire-{now}", self.kb.version, inverse, "ttl_expiry", 1.0)
        for point, expiry in list(self.blocked_expiry.items()):
            if expiry <= now:
                self.state.dynamic_blocked_cells.discard(point)
                del self.blocked_expiry[point]
        for point, expiry in list(self.congestion_expiry.items()):
            if expiry <= now:
                self.state.congestion.pop(point, None)
                del self.congestion_expiry[point]
        for point, expiry in list(self.low_friction_expiry.items()):
            if expiry <= now:
                self.low_friction_cells.discard(point)
                del self.low_friction_expiry[point]
        for point, expiry in list(self.moving_congestion_expiry.items()):
            if expiry <= now:
                self.moving_congestion_cells.discard(point)
                del self.moving_congestion_expiry[point]
        for robot_id, expiry in list(self.unavailable_expiry.items()):
            if expiry <= now:
                robot = self.state.robots[robot_id]
                if robot.status is RobotStatus.UNAVAILABLE:
                    robot.status = RobotStatus.IDLE
                del self.unavailable_expiry[robot_id]
                self.next_allocation_time = min(self.next_allocation_time, now)

    def _inverse_operations(self, operations: list[dict[str, Any]]) -> list[dict[str, Any]]:
        inverse: list[dict[str, Any]] = []
        for operation in reversed(operations):
            op = operation["op"]
            if op == "insert_fact":
                inverse.append({"op": "retract_fact", "atom": copy.deepcopy(operation["atom"])})
            elif op == "supersede_fact":
                atom = operation["atom"]
                key = tuple(str(value) for value in operation.get("key", []))
                previous = [
                    fact for fact in self.kb.snapshot.asserted
                    if fact.predicate == atom["predicate"] and fact.args[: len(key)] == key
                ]
                inverse.append({"op": "retract_fact", "atom": copy.deepcopy(atom)})
                inverse.extend({"op": "insert_fact", "atom": fact.to_dict()} for fact in previous)
            elif op == "insert_rule":
                inverse.append({"op": "retract_rule", "rule_id": operation["rule"]["rule_id"]})
            elif op == "retract_fact":
                inverse.append({"op": "insert_fact", "atom": copy.deepcopy(operation["atom"])})
        return inverse

    def _advance_missions(self, now: int) -> None:
        for mission_id in list(self.missions):
            mission = self.missions.get(mission_id)
            if mission is None:
                continue
            if mission.state in {"loading", "awaiting_stage_b"} and now >= max(mission.loading_finish, mission.next_stage_b_retry):
                self._start_transport(mission, now)
            elif mission.state == "awaiting_replan":
                self._replan_if_needed(mission, now)
            elif mission.state == "in_transit":
                self._update_positions(mission, now)
                self._replan_if_needed(mission, now)
                if mission.state == "in_transit" and mission.completion_time is not None and now >= mission.completion_time:
                    self._complete_mission(mission, now)

    def _start_transport(self, mission: Mission, now: int) -> None:
        if mission.transport_start is None:
            mission.transport_start = now
            for tr_id in mission.dispatch.tr_ids:
                tr = self.state.robots[tr_id]
                tr.position = self.state.cargos[mission.dispatch.cargo_ids[0]].origin
                tr.status = RobotStatus.IN_TRANSIT
            lr = self.state.robots[mission.dispatch.lr_id]
            lr.status = RobotStatus.IDLE
        source_ids, route_congestion = self._route_decision_context()
        try:
            stage_b = bind_stage_b(
                self.state, mission.dispatch, now, self.router, self.reservations,
                transport_started=True, ur_reservations=self.ur_reservations,
                route_congestion=route_congestion,
                time_budget_s=self.timeout_s,
            )
        except StageBFailure as exc:
            self._record_stage_b_attempt(now, mission.dispatch.candidate_id, exc.status, exc.latency_ms, exc.candidate_count, False, source_ids)
            mission.state = "awaiting_stage_b"
            mission.next_stage_b_retry = self._next_retry_time(now)
            self.safe_wait_ticks += max(1, mission.next_stage_b_retry - now)
            self.audit.append({
                "time": now, "kind": "safe_stop", "mission": mission.dispatch.candidate_id,
                "reason": str(exc), "retry_at": mission.next_stage_b_retry,
            })
            return
        self._record_stage_b_attempt(now, mission.dispatch.candidate_id, stage_b.status, stage_b.latency_ms, stage_b.candidate_count, True, source_ids)
        mission.stage_b = stage_b
        mission.state = "in_transit"
        mission.completion_time = stage_b.route.arrival_time
        self._record_ur_waits(stage_b)
        for service in stage_b.service_reservations:
            robot = self.state.robots[service.ur_id]
            robot.available_at = max(robot.available_at, service.service_end)
        self.audit.append({
            "time": now,
            "kind": "stage_b",
            "mission": mission.dispatch.candidate_id,
            "cargo_order": stage_b.cargo_order,
            "ur_by_cargo": stage_b.ur_by_cargo,
            "service_reservations": [asdict(item) for item in stage_b.service_reservations],
            "route_distance": stage_b.route.distance,
            "route_path": stage_b.route.path,
            "route_start": stage_b.route.start_time,
            "route_arrival": stage_b.route.arrival_time,
            "wait_for_ur": stage_b.wait_for_ur,
            "kb_version": self.kb.version,
            **self._source_summary(source_ids),
        })

    def _record_stage_b_attempt(
        self,
        now: int,
        mission_id: str,
        status: str,
        latency_ms: float,
        candidate_count: int,
        success: bool,
        source_ids: list[str],
        attempt_kind: str = "initial_binding",
    ) -> None:
        self.stage_b_attempts += 1
        self.stage_b_status_counts[status] += 1
        if success:
            self.stage_b_successes += 1
            self.stage_b_latencies.append(latency_ms)
        else:
            self.stage_b_failures += 1
            self.stage_b_failure_latencies.append(latency_ms)
        timed_out = "timeout" in status or "unknown" in status
        fallback = "fallback" in status
        self.timeout_count += int(timed_out)
        self.fallback_count += int(fallback)
        self.audit.append({
            "time": now,
            "kind": "stage_b_attempt",
            "attempt_kind": attempt_kind,
            "mission": mission_id,
            "status": status,
            "success": success,
            "latency_ms": latency_ms,
            "candidate_count": candidate_count,
            "timeout": timed_out,
            "fallback": fallback,
            **self._source_summary(source_ids),
        })

    def _record_ur_waits(self, stage_b: StageBResult) -> None:
        self.wait_for_ur.extend(
            max(0, service.service_start - service.tr_arrival_time)
            for service in stage_b.service_reservations
        )

    def _update_positions(self, mission: Mission, now: int) -> None:
        if mission.stage_b is None:
            return
        route = mission.stage_b.route
        index = min(max(0, now - route.start_time), len(route.path) - 1)
        position = route.path[index]
        for tr_id in mission.dispatch.tr_ids:
            self.state.robots[tr_id].position = position
        if position in self.low_friction_cells:
            self.low_friction_exposure_ticks += len(mission.dispatch.tr_ids)
        if position in self.moving_congestion_cells:
            self.moving_congestion_exposure_ticks += len(mission.dispatch.tr_ids)
        completed_stops = sum(service.service_end <= now for service in mission.stage_b.service_reservations)
        mission.next_stop_index = max(mission.next_stop_index, completed_stops)

    def _replan_if_needed(self, mission: Mission, now: int) -> None:
        if mission.stage_b is None or not mission.pending_disturbances:
            if mission.state == "awaiting_replan":
                mission.state = "in_transit"
            return
        route = mission.stage_b.route
        index = mission.paused_index
        if index is None:
            index = min(max(0, now - route.start_time), len(route.path) - 1)
        future = set(route.path[index + 1 :])
        triggers: list[dict[str, Any]] = []
        for event in mission.pending_disturbances.values():
            event_type = event["event_type"]
            point = event.get("point")
            hard = event_type in {"blocked_cell", "access_restriction", "robot_unavailable"}
            soft = event_type in {"moving_congestion", "low_friction"} and (
                self.method in SOFT_REPLAN_METHODS or self.method.startswith("deepseek_")
            )
            if event_type == "robot_unavailable" or ((hard or soft) and point in future):
                triggers.append(event)
        if not triggers:
            return
        new_events = [event for event in triggers if event["event_id"] not in mission.attempted_recovery_events]
        self.recovery_attempts += len(new_events)
        mission.attempted_recovery_events.update(event["event_id"] for event in new_events)
        remaining_cargos = mission.stage_b.cargo_order[mission.next_stop_index :]
        if not remaining_cargos:
            for event in triggers:
                mission.pending_disturbances.pop(event["event_id"], None)
            return
        current = route.path[index]
        trial_routes = self.reservations.clone()
        trial_routes.release(mission.dispatch.candidate_id, from_time=now)
        trial_urs = self.ur_reservations.clone()
        trial_urs.release(mission.dispatch.candidate_id)
        source_ids, route_congestion = self._route_decision_context()
        try:
            replanned = bind_stage_b(
                self.state, mission.dispatch, now, self.router, trial_routes,
                transport_started=True, ur_reservations=trial_urs,
                route_congestion=route_congestion,
                cargo_ids_override=remaining_cargos, start_override=current,
                time_budget_s=self.timeout_s,
            )
        except StageBFailure as exc:
            self._record_stage_b_attempt(
                now, mission.dispatch.candidate_id, exc.status, exc.latency_ms,
                exc.candidate_count, False, source_ids, "dynamic_replan",
            )
            mission.state = "awaiting_replan"
            mission.paused_index = index
            self.safe_wait_ticks += 1
            self.audit.append({
                "time": now,
                "kind": "replan_failed_safe_wait",
                "mission": mission.dispatch.candidate_id,
                "trigger_event_ids": [event["event_id"] for event in triggers],
                "status": exc.status,
            })
            return
        self._record_stage_b_attempt(
            now, mission.dispatch.candidate_id, replanned.status, replanned.latency_ms,
            replanned.candidate_count, True, source_ids, "dynamic_replan",
        )
        traveled = sum(a != b for a, b in zip(route.path[: index + 1], route.path[1 : index + 1]))
        mission.distance_before_replan += traveled
        self.reservations.replace_with(trial_routes)
        self.ur_reservations.replace_with(trial_urs)
        mission.stage_b = replanned
        mission.next_stop_index = 0
        mission.paused_index = None
        mission.state = "in_transit"
        mission.completion_time = replanned.route.arrival_time
        self._record_ur_waits(replanned)
        for event in triggers:
            event_id = event["event_id"]
            if event_id not in mission.successful_recovery_events:
                self.recovery_successes += 1
                mission.successful_recovery_events.add(event_id)
                response = max(0, now - int(event["time"]))
                self.event_response_ticks.append(response)
                self.audit.append({
                    "time": now,
                    "kind": "event_response",
                    "event_id": event_id,
                    "mission": mission.dispatch.candidate_id,
                    "response_ticks": response,
                    "action": "atomic_replan_and_rebind",
                })
            mission.pending_disturbances.pop(event_id, None)
        self.audit.append({
            "time": now,
            "kind": "replan_success",
            "mission": mission.dispatch.candidate_id,
            "trigger_event_ids": [event["event_id"] for event in triggers],
            "distance": replanned.route.distance,
            **self._source_summary(source_ids),
        })

    def _complete_mission(self, mission: Mission, now: int) -> None:
        if mission.stage_b is None:
            return
        for cargo_id in mission.dispatch.cargo_ids:
            self.completed[cargo_id] = now
        final_position = mission.stage_b.route.path[-1]
        mission_distance = mission.distance_before_replan + mission.stage_b.route.distance
        for tr_id in mission.dispatch.tr_ids:
            tr = self.state.robots[tr_id]
            tr.position = final_position
            tr.status = RobotStatus.IDLE
            tr.available_at = now
            tr.battery = max(0.05, tr.battery - 0.002 * mission_distance)
        last_service_by_ur: dict[str, Any] = {}
        for service in mission.stage_b.service_reservations:
            previous = last_service_by_ur.get(service.ur_id)
            if previous is None or service.service_end > previous.service_end:
                last_service_by_ur[service.ur_id] = service
        for ur_id, service in last_service_by_ur.items():
            ur = self.state.robots[ur_id]
            ur.position = service.destination
            ur.status = RobotStatus.IDLE
        self.distance_total += mission.dispatch.approach_distance + mission_distance
        self.mode_distance[mission.dispatch.mode.value] += mission.dispatch.approach_distance + mission_distance
        self.energy_proxy += 0.01 * len(mission.dispatch.tr_ids) * (mission.dispatch.approach_distance + mission_distance)
        self.reservations.release(mission.dispatch.candidate_id, from_time=0)
        self.ur_reservations.release(mission.dispatch.candidate_id)
        self.audit.append({
            "time": now,
            "kind": "completed",
            "mission": mission.dispatch.candidate_id,
            "cargos": mission.dispatch.cargo_ids,
            "mode": mission.dispatch.mode.value,
            "distance": mission.dispatch.approach_distance + mission_distance,
        })
        del self.missions[mission.dispatch.candidate_id]
        self.next_allocation_time = min(self.next_allocation_time, now)

    def _allocate(self, now: int) -> None:
        if now < self.next_allocation_time:
            return
        pending = [
            cargo for cargo in self.state.cargos.values()
            if cargo.cargo_id not in self.assigned and cargo.cargo_id not in self.completed
            and not cargo.cancelled and cargo.release_time <= now
        ]
        if not pending:
            self.next_allocation_time = self._next_release_time(now)
            return
        allocation_method = "greedy" if self.method == "greedy" else "cp_sat"
        forbidden, source_ids = self._allocation_decision_context()
        result = solve_stage_a(
            self.state, pending, now, self.timeout_s, allocation_method,
            forbidden_assignments=forbidden,
        )
        self.stage_a_attempts += 1
        self.stage_a_status_counts[result.status] += 1
        if result.candidate_count:
            self.stage_a_nonempty_calls += 1
            self.stage_a_latencies.append(result.latency_ms)
        else:
            self.stage_a_no_candidate_calls += 1
            self.stage_a_empty_latencies.append(result.latency_ms)
        self.fallback_count += int(result.fallback_used)
        timed_out = "unknown" in result.status or "timeout" in result.status
        self.timeout_count += int(timed_out)
        self.audit.append({
            "time": now,
            "kind": "stage_a_attempt",
            "status": result.status,
            "success": bool(result.selected),
            "latency_ms": result.latency_ms,
            "candidate_count": result.candidate_count,
            "selected_count": len(result.selected),
            "timeout": timed_out,
            "fallback": result.fallback_used,
            **self._source_summary(source_ids),
        })
        for dispatch in result.selected:
            if any(cargo_id in self.assigned for cargo_id in dispatch.cargo_ids):
                self.hard_violations += 1
                continue
            self.assigned.update(dispatch.cargo_ids)
            self.low_reserve_tr_assignments += sum(
                self.state.robots[tr_id].battery < 0.60 for tr_id in dispatch.tr_ids
            )
            loading_finish = now + dispatch.approach_distance + sum(self.state.cargos[cargo_id].service_time for cargo_id in dispatch.cargo_ids)
            mission = Mission(dispatch=dispatch, state="loading", loading_finish=loading_finish)
            self.missions[dispatch.candidate_id] = mission
            self.state.robots[dispatch.lr_id].status = RobotStatus.LOADING
            self.state.robots[dispatch.lr_id].available_at = loading_finish
            for tr_id in dispatch.tr_ids:
                self.state.robots[tr_id].status = RobotStatus.TO_ORIGIN
                self.state.robots[tr_id].available_at = loading_finish
            self.audit.append({
                "time": now,
                "kind": "stage_a",
                "mission": dispatch.candidate_id,
                "cargos": dispatch.cargo_ids,
                "mode": dispatch.mode.value,
                "lr": dispatch.lr_id,
                "trs": dispatch.tr_ids,
                "ur_selected": False,
                "status": result.status,
                "kb_version": self.kb.version,
                **self._source_summary(source_ids),
            })
        self.next_allocation_time = self._next_decision_time(now)

    def _allocation_decision_context(self) -> tuple[set[tuple[str, str]], list[str]]:
        if self.method not in SYMBOLIC_METHODS and not self.method.startswith("deepseek_"):
            return set(), []
        forbidden: set[tuple[str, str]] = set()
        source_ids: list[str] = []
        for atom in sorted(self.kb.snapshot.closure):
            if atom.predicate == "robot_eligible" and atom.args[-1] == "false":
                forbidden.add((atom.args[0], atom.args[1]))
                source_ids.append(self._register_constraint_atom(atom, "stage_a_eligibility"))
        return forbidden, sorted(set(source_ids))

    def _route_decision_context(self) -> tuple[list[str], dict[Point, int]]:
        source_ids: list[str] = []
        penalties: dict[Point, int] = {}
        if self.method in DYNAMIC_FACT_METHODS or self.method.startswith("deepseek_"):
            for atom in sorted(self.kb.snapshot.closure):
                point: Point | None = None
                penalty: int | None = None
                if atom.predicate == "congestion":
                    point = (int(atom.args[0]), int(atom.args[1]))
                    penalty = int(atom.args[2])
                elif atom.predicate == "surface_condition" and atom.args[2] == "low_friction":
                    point = (int(atom.args[0]), int(atom.args[1]))
                    # The fact-only method records the condition but has no rule
                    # that converts it into a route-cost constraint.
                    penalty = 0
                elif atom.predicate == "route_penalty":
                    point = (int(atom.args[0]), int(atom.args[1]))
                    penalty = int(atom.args[2])
                if point is not None and penalty is not None:
                    penalties[point] = max(penalties.get(point, 0), penalty)
                    source_ids.append(self._register_constraint_atom(atom, "stage_b_route_cost"))
        for point in sorted(self.state.dynamic_blocked_cells):
            source_ids.append(self._register_physical_source(point))
        return sorted(set(source_ids)), penalties

    def _register_constraint_atom(self, atom: Atom, use: str) -> str:
        derived = atom not in self.kb.snapshot.asserted
        proof = None
        rule_id = None
        if derived and atom in self.kb.snapshot.proofs:
            proof = self.kb.proof_dag(atom)
            rule_id = self.kb.snapshot.proofs[atom].rule_id
            self.used_derived_atoms.add(atom)
            self.traced_derived_atoms.add(atom)
        identity = _canonical({"atom": atom.to_dict(), "rule_id": rule_id, "use": use})
        source_id = "KS-" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:16]
        if source_id not in self.constraint_sources:
            record = {
                "source_id": source_id,
                "source_type": "kb_derived" if derived else "kb_asserted",
                "use": use,
                "atom": atom.to_dict(),
                "first_used_kb_version": self.kb.version,
                "proof_dag": proof,
            }
            self.constraint_sources[source_id] = record
            self.audit.append({"time": self.state.time, "kind": "constraint_source", **record})
        return source_id

    def _register_physical_source(self, point: Point) -> str:
        identity = f"physical_blocked:{point[0]}:{point[1]}"
        source_id = "PS-" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:16]
        if source_id not in self.constraint_sources:
            record = {
                "source_id": source_id,
                "source_type": "mandatory_physical_safety",
                "use": "stage_b_hard_obstacle",
                "cell": point,
                "first_used_time": self.state.time,
                "proof_dag": None,
            }
            self.constraint_sources[source_id] = record
            self.audit.append({"time": self.state.time, "kind": "constraint_source", **record})
        return source_id

    def _source_summary(self, source_ids: list[str]) -> dict[str, Any]:
        ordered = sorted(set(source_ids))
        digest = hashlib.sha256("|".join(ordered).encode("utf-8")).hexdigest() if ordered else None
        return {
            "constraint_source_count": len(ordered),
            "constraint_source_digest": digest,
            "constraint_source_sample": ordered[:10],
        }

    def _next_release_time(self, now: int) -> int:
        future = [
            cargo.release_time for cargo in self.state.cargos.values()
            if cargo.cargo_id not in self.assigned and not cargo.cancelled and cargo.release_time > now
        ]
        return min(future) if future else now + 5

    def _next_decision_time(self, now: int) -> int:
        future = [
            robot.available_at for robot in self.state.robots.values()
            if robot.role in {RobotRole.LR, RobotRole.TR} and robot.available_at > now
        ]
        release = self._next_release_time(now)
        future.append(release)
        return min(future) if future else now + 5

    def _next_retry_time(self, now: int) -> int:
        expiries = [value for value in self.blocked_expiry.values() if value > now]
        return min(expiries) if expiries else now + 1

    def _mode_metrics(self) -> dict[str, dict[str, Any]]:
        result: dict[str, dict[str, Any]] = {}
        for mode in TransportMode:
            cargo_ids = [cargo.cargo_id for cargo in self.state.cargos.values() if cargo.mode is mode]
            completed = [cargo_id for cargo_id in cargo_ids if cargo_id in self.completed]
            cancelled = [cargo_id for cargo_id in cargo_ids if self.state.cargos[cargo_id].cancelled]
            misses = sum(self.completed[cargo_id] > self.state.cargos[cargo_id].deadline for cargo_id in completed)
            result[mode.value] = {
                "cargo_total": len(cargo_ids),
                "cargo_completed": len(completed),
                "cargo_cancelled": len(cancelled),
                "cargo_pending": len(cargo_ids) - len(completed) - len(cancelled),
                "completion_rate": len(completed) / max(1, len(cargo_ids) - len(cancelled)),
                "deadline_miss_rate": misses / len(completed) if completed else None,
                "travel_distance_total": float(self.mode_distance[mode.value]),
                "travel_distance_per_completed_cargo": self.mode_distance[mode.value] / len(completed) if completed else None,
            }
        return result

    def _structurally_infeasible_cargo_count(self) -> int:
        trs = [robot for robot in self.state.robots.values() if robot.role is RobotRole.TR]
        lrs_by_platform = {
            robot.platform_id for robot in self.state.robots.values()
            if robot.role is RobotRole.LR and robot.platform_id
        }
        ur_zones = {
            robot.zone_id for robot in self.state.robots.values()
            if robot.role is RobotRole.UR and robot.zone_id
        }
        infeasible: set[str] = set()
        batches: dict[str, list[Any]] = {}
        for cargo in self.state.cargos.values():
            if cargo.cancelled:
                continue
            if cargo.origin_id not in lrs_by_platform or self.state.destination_zones[cargo.destination_id] not in ur_zones:
                infeasible.add(cargo.cargo_id)
                continue
            if cargo.mode is TransportMode.BATCH and cargo.batch_id:
                batches.setdefault(cargo.batch_id, []).append(cargo)
            elif cargo.mode is TransportMode.COALITION:
                capacities = sorted((robot.capacity for robot in trs), reverse=True)
                if len(capacities) < cargo.coalition_size or sum(capacities[: cargo.coalition_size]) < cargo.weight:
                    infeasible.add(cargo.cargo_id)
            elif not any(robot.capacity >= cargo.weight for robot in trs):
                infeasible.add(cargo.cargo_id)
        max_capacity = max((robot.capacity for robot in trs), default=0.0)
        for cargos in batches.values():
            if (
                not 2 <= len(cargos) <= 5
                or len({cargo.origin_id for cargo in cargos}) != 1
                or len({cargo.release_time for cargo in cargos}) != 1
                or sum(cargo.weight for cargo in cargos) > max_capacity
            ):
                infeasible.update(cargo.cargo_id for cargo in cargos)
        return len(infeasible)

    def _assert_invariants(self, now: int) -> None:
        try:
            self.state.assert_role_invariants()
            self.reservations.assert_conflict_free()
            self.ur_reservations.assert_conflict_free()
            active_cargos = [cargo_id for mission in self.missions.values() for cargo_id in mission.dispatch.cargo_ids]
            if len(active_cargos) != len(set(active_cargos)):
                raise AssertionError("Cargo assigned to multiple active missions")
            for mission in self.missions.values():
                if mission.stage_b is not None and mission.transport_start is None:
                    raise AssertionError("UR/route bound before transport start")
                if mission.stage_b is not None:
                    expected = set(mission.stage_b.cargo_order)
                    actual = {item.cargo_id for item in mission.stage_b.service_reservations}
                    if expected != actual:
                        raise AssertionError("Stage B route and UR service transaction are not atomic")
        except AssertionError as exc:
            self.hard_violations += 1
            self.audit.append({"time": now, "kind": "hard_violation", "reason": str(exc)})
            raise


def _percentile(values: list[float], probability: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, math.ceil(probability * len(ordered)) - 1))
    return ordered[index]


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))
