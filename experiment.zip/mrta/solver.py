from __future__ import annotations

import copy
import hashlib
import itertools
import time
from dataclasses import dataclass, field
from typing import Iterable

from .domain import Cargo, Point, Robot, RobotRole, TransportMode, WarehouseState, cargo_ids, manhattan
from .routing import GridRouter, ReservationTable, RouteDeadlineExceeded, RouteNotFound, RoutePlan

try:
    from ortools.sat.python import cp_model
except ImportError:  # pragma: no cover - exercised by setup diagnostics
    cp_model = None


@dataclass(frozen=True)
class DispatchCandidate:
    candidate_id: str
    cargo_ids: tuple[str, ...]
    lr_id: str
    tr_ids: tuple[str, ...]
    mode: TransportMode
    provisional_order: tuple[str, ...]
    approach_distance: int
    provisional_distance: int
    estimated_finish: int
    cost: int


@dataclass(frozen=True)
class StageAResult:
    selected: tuple[DispatchCandidate, ...]
    feasible: bool
    status: str
    latency_ms: float
    fallback_used: bool
    candidate_count: int


@dataclass(frozen=True)
class URServiceReservation:
    owner: str
    cargo_id: str
    ur_id: str
    destination: Point
    tr_arrival_time: int
    ur_ready_time: int
    service_start: int
    service_end: int


@dataclass
class URReservationTable:
    """Conservative append-only UR and single-dock future reservations."""

    by_robot: dict[str, list[URServiceReservation]] = field(default_factory=dict)
    by_destination: dict[Point, list[URServiceReservation]] = field(default_factory=dict)

    def clone(self) -> "URReservationTable":
        return copy.deepcopy(self)

    def replace_with(self, other: "URReservationTable") -> None:
        self.by_robot = copy.deepcopy(other.by_robot)
        self.by_destination = copy.deepcopy(other.by_destination)

    def tail(self, robot: Robot, now: int) -> tuple[int, Point]:
        reservations = self.by_robot.get(robot.robot_id, [])
        if not reservations:
            return max(now, robot.available_at), robot.position
        latest = max(reservations, key=lambda item: (item.service_end, item.cargo_id))
        return max(now, latest.service_end), latest.destination

    def next_dock_start(self, destination: Point, earliest: int, duration: int) -> int:
        start = earliest
        for item in sorted(self.by_destination.get(destination, []), key=lambda value: value.service_start):
            if start > item.service_end or start + duration < item.service_start:
                continue
            start = item.service_end + 1
        return start

    def reserve(self, reservation: URServiceReservation) -> None:
        robot_items = self.by_robot.setdefault(reservation.ur_id, [])
        if robot_items and reservation.service_start <= max(item.service_end for item in robot_items):
            raise ValueError(f"UR reservation overlap for {reservation.ur_id}")
        dock_items = self.by_destination.setdefault(reservation.destination, [])
        for item in dock_items:
            if not (reservation.service_start > item.service_end or reservation.service_end < item.service_start):
                raise ValueError(f"Dock reservation overlap at {reservation.destination}")
        robot_items.append(reservation)
        dock_items.append(reservation)
        robot_items.sort(key=lambda item: (item.service_start, item.cargo_id))
        dock_items.sort(key=lambda item: (item.service_start, item.cargo_id))

    def release(self, owner: str) -> None:
        self.by_robot = {
            robot_id: [item for item in items if item.owner != owner]
            for robot_id, items in self.by_robot.items()
            if any(item.owner != owner for item in items)
        }
        self.by_destination = {
            destination: [item for item in items if item.owner != owner]
            for destination, items in self.by_destination.items()
            if any(item.owner != owner for item in items)
        }

    def assert_conflict_free(self) -> None:
        for robot_id, items in self.by_robot.items():
            ordered = sorted(items, key=lambda item: item.service_start)
            for first, second in zip(ordered, ordered[1:]):
                if second.service_start <= first.service_end:
                    raise AssertionError(f"Overlapping service reservations for {robot_id}")
        for destination, items in self.by_destination.items():
            ordered = sorted(items, key=lambda item: item.service_start)
            for first, second in zip(ordered, ordered[1:]):
                if second.service_start <= first.service_end:
                    raise AssertionError(f"Dock capacity exceeded at {destination}")


@dataclass(frozen=True)
class StageBResult:
    cargo_order: tuple[str, ...]
    ur_by_cargo: tuple[tuple[str, str], ...]
    service_reservations: tuple[URServiceReservation, ...]
    route: RoutePlan
    wait_for_ur: int
    latency_ms: float
    candidate_count: int
    status: str = "feasible"


class StageBFailure(RouteNotFound):
    def __init__(self, message: str, status: str, latency_ms: float, candidate_count: int) -> None:
        super().__init__(message)
        self.status = status
        self.latency_ms = latency_ms
        self.candidate_count = candidate_count


def build_dispatch_candidates(
    state: WarehouseState,
    pending: Iterable[Cargo],
    now: int,
    coalition_pool: int = 8,
    singleton_pool: int = 8,
    forbidden_assignments: set[tuple[str, str]] | None = None,
) -> list[DispatchCandidate]:
    forbidden = forbidden_assignments or set()
    pending_list = sorted((c for c in pending if not c.cancelled and c.release_time <= now), key=lambda c: c.cargo_id)
    lr_by_platform: dict[str, list[Robot]] = {}
    for lr in state.idle_robots(RobotRole.LR, now):
        if lr.platform_id:
            lr_by_platform.setdefault(lr.platform_id, []).append(lr)
    trs = state.idle_robots(RobotRole.TR, now)
    groups: list[list[Cargo]] = []
    batch_groups: dict[str, list[Cargo]] = {}
    for cargo in pending_list:
        if cargo.mode is TransportMode.BATCH and cargo.batch_id:
            batch_groups.setdefault(cargo.batch_id, []).append(cargo)
        else:
            groups.append([cargo])
    for batch_id, group in batch_groups.items():
        expected = {
            cargo.cargo_id for cargo in state.cargos.values()
            if cargo.batch_id == batch_id and not cargo.cancelled
        }
        if 2 <= len(group) <= 5 and {cargo.cargo_id for cargo in group} == expected:
            groups.append(group)

    candidates: list[DispatchCandidate] = []
    for group in groups:
        origin_id = group[0].origin_id
        if any(c.origin_id != origin_id for c in group):
            continue
        lrs = lr_by_platform.get(origin_id, [])
        if not lrs:
            continue
        mode = group[0].mode
        total_weight = sum(c.weight for c in group)
        ranked_trs = sorted(trs, key=lambda tr: (manhattan(tr.position, group[0].origin), tr.robot_id))
        if mode is TransportMode.COALITION:
            required = group[0].coalition_size
            tr_sets = _capacity_complete_coalition_sets(
                ranked_trs, required, total_weight, group[0].origin, coalition_pool,
            )
        else:
            # Capacity filtering must precede distance pruning.  Pilot v2 did
            # the reverse and could permanently hide a feasible ninth TR.
            feasible_trs = [tr for tr in ranked_trs if tr.capacity >= total_weight]
            tr_sets = [(tr,) for tr in feasible_trs[:singleton_pool]]
        if not tr_sets:
            continue
        order, route_distance = best_manhattan_order(group[0].origin, group)
        for lr in lrs:
            if lr.capacity < max(c.weight / max(1, c.coalition_size) for c in group):
                continue
            for selected_trs in tr_sets:
                approach = max(manhattan(tr.position, group[0].origin) for tr in selected_trs)
                loading = sum(c.service_time for c in group)
                estimated_finish = now + approach + loading + route_distance + sum(c.service_time for c in group)
                tardiness = sum(max(0, estimated_finish - c.deadline) for c in group)
                cost = 10 * (approach + route_distance) + 50 * tardiness + 3 * len(selected_trs)
                signature = "|".join([lr.robot_id, *(tr.robot_id for tr in selected_trs), *cargo_ids(group)])
                candidate_id = "A-" + hashlib.sha256(signature.encode("utf-8")).hexdigest()[:14]
                candidates.append(DispatchCandidate(
                    candidate_id=candidate_id,
                    cargo_ids=cargo_ids(group), lr_id=lr.robot_id,
                    tr_ids=tuple(tr.robot_id for tr in selected_trs), mode=mode,
                    provisional_order=order, approach_distance=approach,
                    provisional_distance=route_distance, estimated_finish=estimated_finish,
                    cost=cost,
                ))
    if forbidden:
        by_group: dict[tuple[str, ...], list[DispatchCandidate]] = {}
        for candidate in candidates:
            by_group.setdefault(candidate.cargo_ids, []).append(candidate)
        policy_filtered: list[DispatchCandidate] = []
        for group_candidates in by_group.values():
            permitted = [
                candidate for candidate in group_candidates
                if not any(
                    (tr_id, cargo_id) in forbidden
                    for tr_id in candidate.tr_ids for cargo_id in candidate.cargo_ids
                )
            ]
            # A fixed symbolic reserve policy may rank alternatives, but it may not
            # manufacture permanent task infeasibility when every feasible TR is low.
            policy_filtered.extend(permitted or group_candidates)
        candidates = policy_filtered
    return sorted(candidates, key=lambda candidate: candidate.candidate_id)


def _capacity_complete_coalition_sets(
    ranked_trs: list[Robot],
    required: int,
    total_weight: float,
    origin: Point,
    combination_limit: int,
) -> list[tuple[Robot, ...]]:
    """Return bounded nearby coalitions plus a global feasibility witness.

    The highest-capacity ``required`` robots form a witness whenever any
    coalition can meet the load.  This preserves candidate completeness while
    keeping the normal near-robot combination set bounded for online CP-SAT.
    """
    if required <= 0 or len(ranked_trs) < required:
        return []
    nearest = ranked_trs[: max(required, combination_limit)]
    feasible: dict[tuple[str, ...], tuple[Robot, ...]] = {}

    def add(combo: Iterable[Robot]) -> None:
        normalized = tuple(sorted(combo, key=lambda robot: robot.robot_id))
        if len(normalized) != required or sum(robot.capacity for robot in normalized) < total_weight:
            return
        feasible[tuple(robot.robot_id for robot in normalized)] = normalized

    for combo in itertools.combinations(nearest, required):
        add(combo)

    capacity_witness = tuple(sorted(
        ranked_trs,
        key=lambda robot: (-robot.capacity, manhattan(robot.position, origin), robot.robot_id),
    )[:required])
    add(capacity_witness)

    # Add capacity-complete anchored alternatives so a distant high-capacity
    # witness is not the only option when a near robot can participate.
    for anchor in ranked_trs[:combination_limit]:
        partners = sorted(
            (robot for robot in ranked_trs if robot.robot_id != anchor.robot_id),
            key=lambda robot: (-robot.capacity, manhattan(robot.position, origin), robot.robot_id),
        )[: max(0, required - 1)]
        add((anchor, *partners))

    ordered = sorted(
        feasible.values(),
        key=lambda combo: (
            max(manhattan(robot.position, origin) for robot in combo),
            sum(manhattan(robot.position, origin) for robot in combo),
            sum(robot.capacity for robot in combo) - total_weight,
            tuple(robot.robot_id for robot in combo),
        ),
    )
    selected = ordered[: max(1, combination_limit)]
    witness_key = tuple(robot.robot_id for robot in sorted(capacity_witness, key=lambda robot: robot.robot_id))
    if witness_key in feasible and all(
        tuple(robot.robot_id for robot in combo) != witness_key for combo in selected
    ):
        selected.append(feasible[witness_key])
    return selected


def solve_stage_a(
    state: WarehouseState,
    pending: Iterable[Cargo],
    now: int,
    timeout_s: float = 1.0,
    method: str = "cp_sat",
    forbidden_assignments: set[tuple[str, str]] | None = None,
) -> StageAResult:
    started = time.perf_counter()
    candidates = build_dispatch_candidates(state, pending, now, forbidden_assignments=forbidden_assignments)
    if not candidates:
        return StageAResult((), False, "no_candidate", (time.perf_counter() - started) * 1000, False, 0)
    if method == "greedy":
        selected = _greedy_select(candidates)
        return StageAResult(tuple(selected), bool(selected), "greedy", (time.perf_counter() - started) * 1000, False, len(candidates))
    if cp_model is None:
        selected = _greedy_select(candidates)
        return StageAResult(tuple(selected), bool(selected), "ortools_missing", (time.perf_counter() - started) * 1000, True, len(candidates))

    model = cp_model.CpModel()
    chosen = [model.new_bool_var(f"candidate_{index}") for index in range(len(candidates))]
    all_cargos = sorted({cargo_id for candidate in candidates for cargo_id in candidate.cargo_ids})
    all_trs = sorted({tr_id for candidate in candidates for tr_id in candidate.tr_ids})
    all_lrs = sorted({candidate.lr_id for candidate in candidates})
    for cargo_id in all_cargos:
        model.add(sum(chosen[i] for i, c in enumerate(candidates) if cargo_id in c.cargo_ids) <= 1)
    for robot_id in all_trs:
        model.add(sum(chosen[i] for i, c in enumerate(candidates) if robot_id in c.tr_ids) <= 1)
    for robot_id in all_lrs:
        model.add(sum(chosen[i] for i, c in enumerate(candidates) if robot_id == c.lr_id) <= 1)
    model.maximize(sum(chosen[i] * (100_000 * len(c.cargo_ids) - c.cost) for i, c in enumerate(candidates)))
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = max(0.001, timeout_s)
    solver.parameters.num_search_workers = 1
    solver.parameters.random_seed = 0
    status = solver.solve(model)
    status_name = solver.status_name(status).lower()
    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        selected = tuple(c for i, c in enumerate(candidates) if solver.value(chosen[i]))
        return StageAResult(selected, bool(selected), status_name, (time.perf_counter() - started) * 1000, False, len(candidates))
    fallback = tuple(_greedy_select(candidates))
    return StageAResult(fallback, bool(fallback), status_name, (time.perf_counter() - started) * 1000, True, len(candidates))


def bind_stage_b(
    state: WarehouseState,
    dispatch: DispatchCandidate,
    now: int,
    router: GridRouter,
    reservations: ReservationTable,
    transport_started: bool,
    ur_reservations: URReservationTable | None = None,
    route_congestion: dict[Point, int] | None = None,
    max_departure_delay: int = 12,
    cargo_ids_override: tuple[str, ...] | None = None,
    start_override: Point | None = None,
    time_budget_s: float = 1.0,
    order_limit: int = 8,
) -> StageBResult:
    if not transport_started:
        raise ValueError("Stage B may run only after the loaded TR has entered in_transit")
    started = time.perf_counter()
    wall_deadline = started + max(0.001, time_budget_s)
    selected_cargo_ids = dispatch.cargo_ids if cargo_ids_override is None else cargo_ids_override
    cargos = [state.cargos[cargo_id] for cargo_id in selected_cargo_ids]
    if not cargos:
        latency = (time.perf_counter() - started) * 1000
        raise StageBFailure("Stage B received no remaining cargo", "empty_cargo_set", latency, 0)
    start = cargos[0].origin if start_override is None else start_override
    unloaders = sorted(
        (robot for robot in state.robots.values() if robot.role is RobotRole.UR),
        key=lambda robot: robot.robot_id,
    )
    if any(not any(
        ur.zone_id == state.destination_zones[cargo.destination_id] and ur.capacity >= cargo.weight
        for ur in unloaders
    ) for cargo in cargos):
        latency = (time.perf_counter() - started) * 1000
        raise StageBFailure("No zone/capacity-feasible UR exists", "no_eligible_ur", latency, 0)

    base_ur_table = ur_reservations or URReservationTable()
    penalties = state.congestion if route_congestion is None else route_congestion
    best_key: tuple[int, tuple[str, ...], tuple[tuple[str, str], ...]] | None = None
    best_payload: tuple[tuple[str, ...], tuple[tuple[str, str], ...], tuple[URServiceReservation, ...], RoutePlan, int, URReservationTable] | None = None
    candidate_count = 0
    timed_out = False
    for order_cargos in _bounded_stage_b_orders(start, cargos, dispatch.provisional_order, order_limit, now):
        for departure in range(now, now + max_departure_delay + 1):
            if time.perf_counter() >= wall_deadline:
                timed_out = True
                break
            candidate_count += 1
            temporary_ur = base_ur_table.clone()
            full_path: list[Point] = [start] * (departure - now + 1)
            goal_arrivals: list[int] = []
            assignments: list[tuple[str, str]] = []
            service_items: list[URServiceReservation] = []
            wait_total = 0
            current = start
            current_time = departure
            feasible = True
            for cargo in order_cargos:
                if time.perf_counter() >= wall_deadline:
                    timed_out = True
                    feasible = False
                    break
                try:
                    segment = router.route(
                        dispatch.candidate_id, current, cargo.destination, current_time,
                        reservations, state.dynamic_blocked_cells, state.blocked_edges, penalties,
                        wall_deadline=wall_deadline,
                    )
                except RouteDeadlineExceeded:
                    timed_out = True
                    feasible = False
                    break
                except RouteNotFound:
                    feasible = False
                    break
                if time.perf_counter() >= wall_deadline:
                    timed_out = True
                    feasible = False
                    break
                full_path.extend(segment[1:])
                arrival = current_time + len(segment) - 1
                goal_arrivals.append(arrival)
                service = _select_ur_service(
                    state, dispatch.candidate_id, cargo, arrival, now,
                    unloaders, temporary_ur,
                )
                if service is None:
                    feasible = False
                    break
                dwell = service.service_end - arrival
                if dwell > 0:
                    full_path.extend([cargo.destination] * dwell)
                if not reservations.can_reserve(dispatch.candidate_id, full_path, now):
                    feasible = False
                    break
                temporary_ur.reserve(service)
                service_items.append(service)
                assignments.append((cargo.cargo_id, service.ur_id))
                wait_total += max(0, service.service_start - arrival)
                current = cargo.destination
                current_time = service.service_end
            if not feasible or not reservations.can_reserve(dispatch.candidate_id, full_path, now):
                continue
            distance = sum(a != b for a, b in zip(full_path, full_path[1:]))
            plan = RoutePlan(
                tuple(full_path), now, tuple(c.destination for c in order_cargos),
                distance, now + len(full_path) - 1, tuple(goal_arrivals),
            )
            order_ids = tuple(c.cargo_id for c in order_cargos)
            assignment_ids = tuple(assignments)
            service_mass = sum(max(1, cargo.service_time) for cargo in order_cargos)
            objective = distance + (departure - now) + 5 * wait_total + service_mass
            key = (objective, order_ids, assignment_ids)
            if best_key is None or key < best_key:
                best_key = key
                best_payload = (
                    order_ids, assignment_ids, tuple(service_items), plan,
                    wait_total, temporary_ur,
                )
            if timed_out:
                break
        if timed_out:
            break
    if best_payload is None:
        latency = (time.perf_counter() - started) * 1000
        raise StageBFailure(
            "Stage B deadline expired without a feasible incumbent" if timed_out
            else "No atomic route, UR schedule, and dock binding is feasible",
            "timeout_no_incumbent" if timed_out else "no_atomic_binding",
            latency, candidate_count,
        )
    order, assignments, service_items, plan, wait_total, committed_ur = best_payload
    reservations.reserve(dispatch.candidate_id, list(plan.path), plan.start_time)
    if ur_reservations is not None:
        ur_reservations.replace_with(committed_ur)
    return StageBResult(
        order, assignments, service_items, plan, wait_total,
        (time.perf_counter() - started) * 1000, candidate_count,
        "feasible_timeout" if timed_out else "feasible",
    )


def _bounded_stage_b_orders(
    start: Point,
    cargos: list[Cargo],
    provisional_order: tuple[str, ...],
    limit: int,
    decision_time: int,
) -> list[tuple[Cargo, ...]]:
    """Prioritize a bounded deterministic set of cargo orders for Stage B.

    Manhattan scoring is cheap and independent of shared reservations; exact
    conflict-aware routing is then evaluated only for the strongest orders.
    All permutations remain available for groups of at most three cargoes.
    """
    by_id = {cargo.cargo_id: cargo for cargo in cargos}
    available_ids = set(by_id)
    preferred: list[tuple[Cargo, ...]] = []

    def add(order: Iterable[Cargo]) -> None:
        normalized = tuple(order)
        ids = tuple(cargo.cargo_id for cargo in normalized)
        if len(ids) != len(cargos) or set(ids) != available_ids:
            return
        if all(tuple(item.cargo_id for item in existing) != ids for existing in preferred):
            preferred.append(normalized)

    add(by_id[cargo_id] for cargo_id in provisional_order if cargo_id in by_id)
    add(sorted(cargos, key=lambda cargo: (cargo.deadline, cargo.destination, cargo.cargo_id)))
    add(reversed(preferred[0] if preferred else tuple(cargos)))

    permutations = list(itertools.permutations(cargos))
    scored = sorted(
        permutations,
        key=lambda order: (
            _manhattan_order_distance(start, order),
            sum(max(0, _manhattan_arrival(start, order, index, decision_time) - cargo.deadline)
                for index, cargo in enumerate(order)),
            tuple(cargo.cargo_id for cargo in order),
        ),
    )
    if len(cargos) <= 3:
        for order in scored:
            add(order)
        return preferred
    for order in scored:
        if len(preferred) >= max(1, limit):
            break
        add(order)
    return preferred[: max(1, limit)]


def _manhattan_order_distance(start: Point, order: Iterable[Cargo]) -> int:
    current = start
    distance = 0
    for cargo in order:
        distance += manhattan(current, cargo.destination)
        current = cargo.destination
    return distance


def _manhattan_arrival(start: Point, order: tuple[Cargo, ...], stop_index: int, decision_time: int) -> int:
    current = start
    elapsed = decision_time
    for cargo in order[: stop_index + 1]:
        elapsed += manhattan(current, cargo.destination) + max(1, cargo.service_time)
        current = cargo.destination
    return elapsed


def _select_ur_service(
    state: WarehouseState,
    owner: str,
    cargo: Cargo,
    tr_arrival: int,
    now: int,
    unloaders: list[Robot],
    table: URReservationTable,
) -> URServiceReservation | None:
    zone = state.destination_zones[cargo.destination_id]
    eligible = [ur for ur in unloaders if ur.zone_id == zone and ur.capacity >= cargo.weight]
    best: tuple[tuple[int, int, str], URServiceReservation] | None = None
    duration = max(1, cargo.service_time)
    for ur in eligible:
        tail_time, tail_position = table.tail(ur, now)
        ur_ready = tail_time + manhattan(tail_position, cargo.destination)
        service_start = table.next_dock_start(cargo.destination, max(tr_arrival, ur_ready), duration)
        reservation = URServiceReservation(
            owner=owner, cargo_id=cargo.cargo_id, ur_id=ur.robot_id,
            destination=cargo.destination, tr_arrival_time=tr_arrival,
            ur_ready_time=ur_ready, service_start=service_start,
            service_end=service_start + duration,
        )
        key = (reservation.service_end, max(0, service_start - tr_arrival), ur.robot_id)
        if best is None or key < best[0]:
            best = (key, reservation)
    return None if best is None else best[1]


def best_manhattan_order(start: Point, cargos: list[Cargo]) -> tuple[tuple[str, ...], int]:
    best_order: tuple[str, ...] | None = None
    best_distance = 10**18
    for permutation in itertools.permutations(cargos):
        current = start
        distance = 0
        for cargo in permutation:
            distance += manhattan(current, cargo.destination)
            current = cargo.destination
        order = tuple(c.cargo_id for c in permutation)
        if (distance, order) < (best_distance, best_order or tuple("~")):
            best_distance = distance
            best_order = order
    if best_order is None:
        return (), 0
    return best_order, int(best_distance)


def _greedy_select(candidates: list[DispatchCandidate]) -> list[DispatchCandidate]:
    selected: list[DispatchCandidate] = []
    used_cargos: set[str] = set()
    used_trs: set[str] = set()
    used_lrs: set[str] = set()
    ordered = sorted(candidates, key=lambda c: (c.estimated_finish, c.cost, c.candidate_id))
    for candidate in ordered:
        if used_cargos.intersection(candidate.cargo_ids) or used_trs.intersection(candidate.tr_ids) or candidate.lr_id in used_lrs:
            continue
        selected.append(candidate)
        used_cargos.update(candidate.cargo_ids)
        used_trs.update(candidate.tr_ids)
        used_lrs.add(candidate.lr_id)
    return selected
