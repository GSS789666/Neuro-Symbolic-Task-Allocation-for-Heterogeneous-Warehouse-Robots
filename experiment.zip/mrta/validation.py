from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from .domain import RobotRole, TransportMode, WarehouseState
from .scenario import stable_split
from .semantic import compile_authenticated_payload


EXPECTED_ATTRIBUTION_PAIRS = (
    ("static_cp_sat", "static_mivar_cp_sat"),
    ("static_mivar_cp_sat", "dynamic_facts_cp_sat"),
    ("dynamic_facts_cp_sat", "dynamic_rules_cp_sat"),
)
STRICT_AUDIT_SCHEMA = "mrta-audit-2.2"


def validate_dataset(data_dir: Path, minimum_harmful: int = 500, minimum_valid: int = 500) -> dict[str, Any]:
    failures: list[str] = []
    warnings: list[str] = []
    manifest_path = data_dir / "manifest.json"
    event_path = data_dir / "events.jsonl"
    if not manifest_path.exists() or not event_path.exists():
        return {"status": "fail", "failures": ["manifest.json or events.jsonl is missing"], "warnings": []}
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    for item in manifest["files"]:
        path = data_dir / item["path"]
        if not path.exists():
            failures.append(f"Missing manifest file: {path}")
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != item["sha256"]:
            failures.append(f"Checksum mismatch: {path}")

    records = [json.loads(line) for line in event_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(records) != manifest.get("event_count"):
        failures.append("Manifest event_count does not match events.jsonl")
    case_ids = [record["case_id"] for record in records]
    if len(case_ids) != len(set(case_ids)):
        failures.append("Duplicate event case_id values")
    group_splits: dict[str, set[str]] = defaultdict(set)
    label_counts: Counter[str] = Counter()
    test_label_counts: Counter[str] = Counter()
    for record in records:
        group_splits[record["map_family"]].add(record["split"])
        expected_split = stable_split(record["map_family"])
        if record["split"] != expected_split:
            failures.append(f"Split mismatch for {record['case_id']}")
        label = "valid" if record["valid"] else "harmful"
        label_counts[label] += 1
        if record["split"] == "test":
            test_label_counts[label] += 1
        expected = compile_authenticated_payload(record["event_type"], record["payload"])
        if _canonical(record["gold_operations"]) != _canonical(expected):
            failures.append(f"Gold/payload mismatch for {record['case_id']}")
    leaking_groups = [group for group, splits in group_splits.items() if len(splits) != 1]
    if leaking_groups:
        failures.append(f"Map groups cross splits: {leaking_groups[:10]}")
    if label_counts["harmful"] < minimum_harmful:
        failures.append(f"Only {label_counts['harmful']} harmful cases; need at least {minimum_harmful}")
    if label_counts["valid"] < minimum_valid:
        failures.append(f"Only {label_counts['valid']} valid cases; need at least {minimum_valid}")
    if test_label_counts["harmful"] < minimum_harmful:
        warnings.append(
            f"Held-out test has {test_label_counts['harmful']} harmful cases; "
            "the primary 500-case safety endpoint needs expansion or a dedicated test corpus"
        )

    mode_counts: Counter[str] = Counter()
    scenario_count = 0
    for item in manifest["files"]:
        if not item["path"].replace("\\", "/").startswith("scenarios/"):
            continue
        state = WarehouseState.from_dict(json.loads((data_dir / item["path"]).read_text(encoding="utf-8")))
        state.assert_role_invariants()
        scenario_count += 1
        trs = [robot for robot in state.robots.values() if robot.role is RobotRole.TR]
        max_tr_capacity = max((robot.capacity for robot in trs), default=0.0)
        tr_capacities = sorted((robot.capacity for robot in trs), reverse=True)
        ur_zones = {robot.zone_id for robot in state.robots.values() if robot.role is RobotRole.UR}
        batches: dict[str, list[Any]] = defaultdict(list)
        for cargo in state.cargos.values():
            mode_counts[cargo.mode.value] += 1
            if state.destination_zones[cargo.destination_id] not in ur_zones:
                failures.append(f"No UR zone coverage in {state.scenario_id}:{cargo.cargo_id}")
            if cargo.mode is TransportMode.COALITION:
                if not 2 <= cargo.coalition_size <= 4:
                    failures.append(f"Invalid coalition size in {state.scenario_id}:{cargo.cargo_id}")
                elif len(tr_capacities) < cargo.coalition_size or sum(tr_capacities[: cargo.coalition_size]) < cargo.weight:
                    failures.append(f"Structurally infeasible coalition in {state.scenario_id}:{cargo.cargo_id}")
            elif cargo.mode is TransportMode.INDIVIDUAL and cargo.weight > max_tr_capacity:
                failures.append(f"Structurally infeasible individual cargo in {state.scenario_id}:{cargo.cargo_id}")
            if cargo.mode is TransportMode.BATCH:
                if not cargo.batch_id:
                    failures.append(f"Batch cargo lacks batch_id in {state.scenario_id}:{cargo.cargo_id}")
                else:
                    batches[cargo.batch_id].append(cargo)
        for batch_id, cargos in batches.items():
            if not 2 <= len(cargos) <= 5:
                failures.append(f"Batch {state.scenario_id}:{batch_id} has invalid size {len(cargos)}")
            if len({cargo.origin_id for cargo in cargos}) != 1:
                failures.append(f"Batch {state.scenario_id}:{batch_id} crosses loading platforms")
            if len({cargo.release_time for cargo in cargos}) != 1:
                failures.append(f"Batch {state.scenario_id}:{batch_id} is not atomically released")
            if sum(cargo.weight for cargo in cargos) > max_tr_capacity:
                failures.append(f"Batch {state.scenario_id}:{batch_id} exceeds every TR capacity")
    for mode in TransportMode:
        if mode.value not in mode_counts:
            failures.append(f"No generated cargo for mode {mode.value}")
    return {
        "status": "fail" if failures else "pass",
        "failures": failures[:100],
        "failure_count": len(failures),
        "warnings": warnings,
        "scenario_count": scenario_count,
        "event_count": len(records),
        "label_counts": dict(label_counts),
        "test_label_counts": dict(test_label_counts),
        "mode_counts": dict(mode_counts),
        "structural_feasibility_gate": "pass" if not any("infeasible" in value or "exceeds" in value for value in failures) else "fail",
    }


def validate_run(
    run_dir: Path,
    require_tail_sample: bool = False,
    strict_engineering: bool = False,
    minimum_tail_sample: int | None = None,
) -> dict[str, Any]:
    failures: list[str] = []
    warnings: list[str] = []
    manifest_path = run_dir / "run_manifest.json"
    results_path = run_dir / "episode_results.jsonl"
    if not manifest_path.exists() or not results_path.exists():
        return {"status": "fail", "failures": ["run_manifest.json or episode_results.jsonl is missing"], "warnings": []}
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("status") != "complete":
        failures.append("Run manifest status is not complete")
    digest = hashlib.sha256(results_path.read_bytes()).hexdigest()
    if digest != manifest.get("results_sha256"):
        failures.append("episode_results.jsonl checksum mismatch")
    if not manifest.get("source_inventory"):
        failures.append("Run manifest lacks a per-file source inventory")
    expected_audit_schema = manifest.get("audit_schema")
    if strict_engineering and expected_audit_schema != STRICT_AUDIT_SCHEMA:
        failures.append(
            f"Strict engineering run must declare {STRICT_AUDIT_SCHEMA}, got {expected_audit_schema!r}"
        )
    repository = manifest.get("repository", {})
    if not repository.get("commit"):
        warnings.append("No Git commit was available; reproducibility relies on source_sha256 plus source_inventory")

    rows = [json.loads(line) for line in results_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(rows) != manifest.get("task_count"):
        failures.append("Task count differs from result row count")
    cell_methods: dict[tuple[Any, ...], set[str]] = defaultdict(set)
    results_by_cell_method: dict[tuple[Any, ...], dict[str, dict[str, Any]]] = defaultdict(dict)
    solver_invocations: Counter[str] = Counter()
    method_rows: Counter[str] = Counter()
    positive_ur_wait = 0
    derived_sources: Counter[str] = Counter()
    terminal_pending: Counter[str] = Counter()
    stage_b_latencies: dict[str, list[float]] = defaultdict(list)
    stage_b_timeouts: Counter[str] = Counter()
    stage_a_attempt_counts: Counter[str] = Counter()
    stage_a_fallbacks: Counter[str] = Counter()
    expected_scale_methods: set[str] = set()
    audited_episodes = 0
    audits_dir = run_dir / "audits"
    episodes_dir = run_dir / "episodes"

    for row in rows:
        task = row["task"]
        result = row["result"]
        task_id = task["task_id"]
        method = task["method"]
        method_rows[method] += 1
        if result["hard_violations"] != 0:
            failures.append(f"Hard violation in task {task_id}")
        if result.get("structurally_infeasible_cargo_count") != 0:
            failures.append(f"Structural infeasibility reached runtime in task {task_id}")
        terminal_pending[method] += int(result.get("cargo_pending", 0))
        if strict_engineering and result.get("cargo_pending") != 0:
            failures.append(f"Terminal pending cargo in strict engineering task {task_id}")
        if strict_engineering:
            for metric in ("moving_congestion_exposure_ticks", "low_reserve_tr_assignments"):
                if metric not in result:
                    failures.append(f"Strict engineering metric {metric} is missing in task {task_id}")
        for key, value in result.items():
            if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
                failures.append(f"Non-finite value {key} in task {task_id}")
        required_modes = {mode.value for mode in TransportMode}
        if set(result.get("mode_metrics", {})) != required_modes:
            failures.append(f"Per-mode metrics are incomplete in task {task_id}")
        if result.get("stage_a_attempts") != result.get("stage_a_nonempty_calls", 0) + result.get("stage_a_no_candidate_calls", 0):
            failures.append(f"Stage-A counters do not add up in task {task_id}")
        if result.get("stage_b_attempts") != result.get("stage_b_successes", 0) + result.get("stage_b_failures", 0):
            failures.append(f"Stage-B counters do not add up in task {task_id}")
        positive_ur_wait += int(result.get("tr_wait_for_ur_positive_count", 0))
        derived_sources[method] += int(result.get("derived_constraint_source_count", 0))
        proof = result.get("proof_trace_coverage")
        if result.get("derived_constraint_source_count", 0) and proof != 1.0:
            failures.append(f"Derived solver constraint lacks a complete proof trace in task {task_id}")

        cell = (task["scale"], task["seed"], task.get("trace_seed"), task["load_level"], task["disturbance_level"])
        cell_methods[cell].add(method)
        results_by_cell_method[cell][method] = result
        scale_method = f"{task['scale']}:{method}"
        expected_scale_methods.add(scale_method)
        solver_invocations[scale_method] += int(result["solver_invocations"])

        episode_path = episodes_dir / f"{task_id}.json"
        audit_path = audits_dir / f"{task_id}.jsonl.gz"
        if not episode_path.exists() or not audit_path.exists():
            failures.append(f"Incomplete episode/audit pair for task {task_id}")
            continue
        try:
            episode_payload = json.loads(episode_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            failures.append(f"Unreadable episode payload for task {task_id}: {exc}")
            continue
        if _canonical(episode_payload) != _canonical(row):
            failures.append(f"Episode payload differs from aggregate result row for task {task_id}")
        try:
            with gzip.open(audit_path, "rt", encoding="utf-8") as stream:
                audit = [json.loads(line) for line in stream if line.strip()]
        except (OSError, json.JSONDecodeError) as exc:
            failures.append(f"Unreadable audit log for task {task_id}: {exc}")
            continue
        if not audit or audit[-1].get("kind") != "audit_complete" or audit[-1].get("task_id") != task_id:
            failures.append(f"Audit log lacks a matching terminal record for task {task_id}")
            continue
        terminal = audit[-1]
        payload_sha256 = hashlib.sha256(
            json.dumps(episode_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        if terminal.get("payload_sha256") != payload_sha256:
            failures.append(f"Audit terminal payload hash mismatch for task {task_id}")
        if terminal.get("source_sha256") != task.get("source_sha256"):
            failures.append(f"Audit terminal source hash mismatch for task {task_id}")
        if task.get("source_sha256") != manifest.get("source_sha256"):
            failures.append(f"Task source hash differs from run manifest for task {task_id}")
        if task.get("audit_schema") != expected_audit_schema:
            failures.append(f"Task audit schema differs from run manifest for task {task_id}")
        summary_records = [item for item in audit if item.get("kind") == "episode_summary"]
        if len(summary_records) != 1:
            failures.append(f"Audit log must contain exactly one episode_summary for task {task_id}")
        elif _canonical(summary_records[0].get("result")) != _canonical(result):
            failures.append(f"Episode summary result mismatch for task {task_id}")
        if expected_audit_schema and (
            audit[-1].get("audit_schema") != expected_audit_schema
            or any(item.get("audit_schema") != expected_audit_schema for item in summary_records)
        ):
            failures.append(f"Audit schema mismatch for task {task_id}")
        stage_a_attempts = [item for item in audit if item.get("kind") == "stage_a_attempt"]
        stage_b_attempts = [item for item in audit if item.get("kind") == "stage_b_attempt"]
        if len(stage_a_attempts) != result.get("stage_a_attempts"):
            failures.append(f"Raw Stage-A audit count mismatch for task {task_id}")
        if len(stage_b_attempts) != result.get("stage_b_attempts"):
            failures.append(f"Raw Stage-B audit count mismatch for task {task_id}")
        for item in [*stage_a_attempts, *stage_b_attempts]:
            required = {"latency_ms", "candidate_count", "status", "success", "timeout", "fallback"}
            if required - set(item):
                failures.append(f"Raw decision audit is incomplete in task {task_id}")
                break
        stage_b_key = scale_method
        for item in stage_a_attempts:
            stage_a_attempt_counts[stage_b_key] += 1
            stage_a_fallbacks[stage_b_key] += int(bool(item.get("fallback")))
        for item in stage_b_attempts:
            stage_b_latencies[stage_b_key].append(float(item["latency_ms"]))
            stage_b_timeouts[stage_b_key] += int(bool(item.get("timeout")))
        audited_episodes += 1

    method_counts = {len(methods) for methods in cell_methods.values()}
    if len(method_counts) > 1:
        failures.append("Matched condition cells do not contain equal method counts")
    expected_method_count = len(set(method_rows))
    if method_counts and method_counts != {expected_method_count}:
        failures.append("At least one matched condition cell is missing a method")

    identity_findings: list[dict[str, Any]] = []
    for first, second in EXPECTED_ATTRIBUTION_PAIRS:
        comparable = 0
        different = 0
        for by_method in results_by_cell_method.values():
            if first not in by_method or second not in by_method:
                continue
            comparable += 1
            different += _operational_signature(by_method[first]) != _operational_signature(by_method[second])
        finding = {"method_a": first, "method_b": second, "comparable_cells": comparable, "different_cells": different}
        identity_findings.append(finding)
        if comparable >= 30 and different == 0:
            failures.append(f"Unexpected operational identity across all {comparable} cells: {first} == {second}")
        elif comparable and different == 0:
            warnings.append(f"Small run did not exercise the contrast {first} vs {second}; Pilot v2 must do so")

    if len(rows) >= 100 and positive_ur_wait == 0:
        failures.append("UR-wait metric is degenerate: no positive wait was recorded in a pressure-sized run")
    elif positive_ur_wait == 0:
        warnings.append("No positive UR wait in this small run; the Pilot v2 pressure gate will require it")
    if "dynamic_rules_cp_sat" in method_rows and derived_sources["dynamic_rules_cp_sat"] == 0:
        failures.append("Dynamic-rule method never supplied a derived constraint to a solver/router")

    tail_minimum = minimum_tail_sample if minimum_tail_sample is not None else (2000 if require_tail_sample else 0)
    if tail_minimum:
        for key in sorted(expected_scale_methods):
            if key.endswith(":greedy"):
                continue
            count = solver_invocations[key]
            if count < tail_minimum:
                failures.append(
                    f"{key} has only {count} nonempty solver calls; strict tail gate requires {tail_minimum}"
                )
        if strict_engineering:
            for key in sorted(expected_scale_methods):
                attempt_count = len(stage_b_latencies[key])
                if attempt_count < tail_minimum:
                    failures.append(
                        f"{key} has only {attempt_count} raw Stage-B attempts; strict tail gate requires {tail_minimum}"
                    )
    else:
        for key, count in solver_invocations.items():
            if key.endswith(":greedy"):
                continue
            if count < 2000:
                warnings.append(f"{key} has {count} nonempty solver calls; do not make confirmatory p99 claims")

    stage_b_tail: dict[str, dict[str, Any]] = {}
    for key in sorted(expected_scale_methods):
        values = stage_b_latencies[key]
        p95 = _percentile(values, 0.95)
        p99 = _percentile(values, 0.99)
        maximum = max(values) if values else None
        attempts = len(values)
        timeout_rate = stage_b_timeouts[key] / attempts if attempts else 0.0
        stage_a_fallback_rate = stage_a_fallbacks[key] / stage_a_attempt_counts[key] if stage_a_attempt_counts[key] else 0.0
        stage_b_tail[key] = {
            "attempts": attempts,
            "p95_ms": p95,
            "p99_ms": p99,
            "max_ms": maximum,
            "timeout_count": stage_b_timeouts[key],
            "timeout_rate": timeout_rate,
            "stage_a_fallback_count": stage_a_fallbacks[key],
            "stage_a_fallback_rate": stage_a_fallback_rate,
        }
        if strict_engineering:
            if not attempts:
                failures.append(f"Strict engineering run contains no raw Stage-B attempts for {key}")
            if p95 is not None and p95 > 800.0:
                failures.append(f"Stage-B p95 exceeds 800 ms for {key}: {p95:.3f}")
            if p99 is not None and p99 > 1000.0:
                failures.append(f"Stage-B p99 exceeds 1000 ms for {key}: {p99:.3f}")
            if maximum is not None and maximum > 1050.0:
                failures.append(f"Stage-B hard termination exceeds 1050 ms for {key}: {maximum:.3f}")
            if timeout_rate > 0.01:
                failures.append(f"Stage-B timeout rate exceeds 1% for {key}: {timeout_rate:.6f}")
            if stage_a_fallback_rate > 0.01:
                failures.append(f"Stage-A fallback rate exceeds 1% for {key}: {stage_a_fallback_rate:.6f}")

    mechanism_gates: dict[str, Any] = {}
    if strict_engineering:
        mechanism_gates["low_friction"] = _directional_mechanism_gate(
            results_by_cell_method, "dynamic_facts_cp_sat", "dynamic_rules_cp_sat",
            "low_friction_exposure_ticks", group_key_index=1,
        )
        mechanism_gates["moving_congestion"] = _directional_mechanism_gate(
            results_by_cell_method, "static_mivar_cp_sat", "dynamic_facts_cp_sat",
            "moving_congestion_exposure_ticks", group_key_index=1,
        )
        for name, gate in mechanism_gates.items():
            if gate["opportunity_cells"] == 0:
                failures.append(f"{name} mechanism gate had no exposure opportunities")
            elif gate["nonincrease_rate"] < 0.90:
                failures.append(
                    f"{name} exposure was non-increasing in only {gate['nonincrease_rate']:.3%} of opportunities"
                )
            if gate["layout_groups_worse"]:
                failures.append(f"{name} mean exposure worsened in layout groups {gate['layout_groups_worse']}")

        static_cp_low_reserve = sum(
            int(by_method.get("static_cp_sat", {}).get("low_reserve_tr_assignments", 0))
            for by_method in results_by_cell_method.values()
        )
        static_mivar_low_reserve = sum(
            int(by_method.get("static_mivar_cp_sat", {}).get("low_reserve_tr_assignments", 0))
            for by_method in results_by_cell_method.values()
        )
        mechanism_gates["low_reserve"] = {
            "static_cp_sat": static_cp_low_reserve,
            "static_mivar_cp_sat": static_mivar_low_reserve,
        }
    return {
        "status": "fail" if failures else "pass",
        "failures": failures[:100],
        "failure_count": len(failures),
        "warnings": warnings,
        "episode_rows": len(rows),
        "audited_episodes": audited_episodes,
        "matched_cells": len(cell_methods),
        "solver_invocations_by_scale_method": dict(solver_invocations),
        "positive_ur_wait_observations": positive_ur_wait,
        "derived_constraint_sources_by_method": dict(derived_sources),
        "terminal_pending_by_method": dict(terminal_pending),
        "stage_b_tail_by_scale_method": stage_b_tail,
        "mechanism_gates": mechanism_gates,
        "method_attribution_gate": identity_findings,
    }


def _directional_mechanism_gate(
    results_by_cell_method: dict[tuple[Any, ...], dict[str, dict[str, Any]]],
    baseline_method: str,
    intervention_method: str,
    metric: str,
    group_key_index: int,
) -> dict[str, Any]:
    opportunities = 0
    nonincrease = 0
    decreases = 0
    by_group: dict[Any, list[float]] = defaultdict(list)
    for cell, by_method in results_by_cell_method.items():
        if baseline_method not in by_method or intervention_method not in by_method:
            continue
        baseline = float(by_method[baseline_method].get(metric, 0))
        intervention = float(by_method[intervention_method].get(metric, 0))
        by_group[cell[group_key_index]].append(intervention - baseline)
        if baseline > 0:
            opportunities += 1
            nonincrease += int(intervention <= baseline)
            decreases += int(intervention < baseline)
    group_mean_differences = {
        str(group): sum(values) / len(values) for group, values in sorted(by_group.items()) if values
    }
    return {
        "baseline_method": baseline_method,
        "intervention_method": intervention_method,
        "metric": metric,
        "opportunity_cells": opportunities,
        "decrease_cells": decreases,
        "nonincrease_cells": nonincrease,
        "nonincrease_rate": nonincrease / opportunities if opportunities else 0.0,
        "layout_group_mean_differences": group_mean_differences,
        "layout_groups_worse": [group for group, value in group_mean_differences.items() if value > 0],
    }


def _percentile(values: list[float], probability: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = position - lower
    return ordered[lower] * (1.0 - fraction) + ordered[upper] * fraction


def _operational_signature(result: dict[str, Any]) -> str:
    keys = (
        "cargo_completed",
        "cargo_pending",
        "deadline_miss_rate",
        "travel_distance_per_cargo",
        "energy_proxy",
        "tr_wait_for_ur_mean",
        "low_friction_exposure_ticks",
        "moving_congestion_exposure_ticks",
        "low_reserve_tr_assignments",
        "recovery_attempts",
        "recovery_successes",
        "mode_metrics",
    )
    return _canonical({key: result.get(key) for key in keys})


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate generated data or completed simulation runs")
    subparsers = parser.add_subparsers(dest="command", required=True)
    data_parser = subparsers.add_parser("data")
    data_parser.add_argument("--data", type=Path, required=True)
    data_parser.add_argument("--minimum-harmful", type=int, default=500)
    data_parser.add_argument("--minimum-valid", type=int, default=500)
    data_parser.add_argument("--output", type=Path)
    run_parser = subparsers.add_parser("run")
    run_parser.add_argument("--run", type=Path, required=True)
    run_parser.add_argument("--require-tail-sample", action="store_true")
    run_parser.add_argument("--strict-engineering", action="store_true")
    run_parser.add_argument("--minimum-tail-sample", type=int)
    run_parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.command == "data":
        result = validate_dataset(args.data, args.minimum_harmful, args.minimum_valid)
    else:
        result = validate_run(
            args.run, args.require_tail_sample, args.strict_engineering, args.minimum_tail_sample,
        )
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    raise SystemExit(0 if result["status"] == "pass" else 1)


if __name__ == "__main__":
    main()
