"""Versioned neuro-symbolic LR-TR-UR warehouse research code."""

__version__ = "0.3.6-llm-track-v1.4"
