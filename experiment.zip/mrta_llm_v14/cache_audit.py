from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from .grounding import (
    DEFAULT_MODEL,
    DEFAULT_THINKING_MODE,
    CacheMiss,
    DeepSeekGrounder,
    GroundingError,
    build_record_grounding_context,
)
from .shield import ALLOWED_PROFILES, FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE, RULE_EVENT_TYPES


def audit_cache(
    events_path: Path,
    cache_dir: Path,
    model: str,
    profiles: list[str],
    thinking_mode: str = DEFAULT_THINKING_MODE,
    sealed_manifest_path: Path | None = None,
) -> dict:
    records = [json.loads(line) for line in events_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    grounder = DeepSeekGrounder(
        cache_dir, model=model, thinking_mode=thinking_mode,
        sealed_manifest_path=sealed_manifest_path,
    )
    jobs = [
        (record, profile)
        for record in records
        for profile in profiles
        if profile != RESTRICTED_RULE_PROFILE or record["event_type"] in RULE_EVENT_TYPES
    ]
    missing: list[str] = []
    corrupt: list[dict[str, str]] = []
    invalid: list[dict[str, str]] = []
    valid = 0
    for record, profile in jobs:
        context = build_record_grounding_context(record)
        identity = f"{record['case_id']}:{profile}"
        try:
            result = grounder.ground(
                record["text"], context, offline=True, inference_profile=profile,
            )
            if result.candidate is None:
                invalid.append({"identity": identity, "error": result.validation_error or "invalid_response"})
            else:
                valid += 1
        except CacheMiss:
            missing.append(identity)
        except GroundingError as exc:
            corrupt.append({"identity": identity, "error": str(exc)})
    return {
        "status": "pass" if not missing and not corrupt else "fail",
        "model": model,
        "thinking_mode": thinking_mode,
        "profiles": profiles,
        "sealed_manifest": str(sealed_manifest_path) if sealed_manifest_path else None,
        "sealed_manifest_sha256": (
            hashlib.sha256(sealed_manifest_path.read_bytes()).hexdigest()
            if sealed_manifest_path else None
        ),
        "events": len(records),
        "required_cache_entries": len(jobs),
        "complete_cache_entries": len(jobs) - len(missing) - len(corrupt),
        "valid_response_count": valid,
        "invalid_response_count": len(invalid),
        "missing_count": len(missing),
        "corrupt_count": len(corrupt),
        "missing_examples": missing[:20],
        "corrupt_examples": corrupt[:20],
        "invalid_examples": invalid[:20],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify complete and metadata-bound offline DeepSeek response caches")
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--profiles", nargs="+", choices=sorted(ALLOWED_PROFILES), default=[FACTS_ONLY_PROFILE])
    parser.add_argument("--thinking-mode", choices=["enabled", "disabled"], default=DEFAULT_THINKING_MODE)
    parser.add_argument("--sealed-manifest", type=Path)
    args = parser.parse_args()
    result = audit_cache(
        args.events, args.cache, args.model, args.profiles,
        args.thinking_mode, args.sealed_manifest,
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    raise SystemExit(0 if result["status"] == "pass" else 1)


if __name__ == "__main__":
    main()
