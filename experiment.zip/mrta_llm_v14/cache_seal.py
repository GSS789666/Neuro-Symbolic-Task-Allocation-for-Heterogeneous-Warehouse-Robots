from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from .experiment import _source_digest
from .grounding import (
    CACHE_SEAL_SCHEMA_VERSION,
    DEFAULT_MAX_TOKENS,
    DEFAULT_MODEL,
    DEFAULT_THINKING_MODE,
    PROMPT_SCHEMA_VERSION,
    REQUEST_PLAN_SCHEMA_VERSION,
    CacheMiss,
    DeepSeekGrounder,
    GroundingError,
    build_record_grounding_context,
)
from .shield import FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE, RULE_EVENT_TYPES


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def case_ids_sha256(records: list[dict[str, Any]]) -> str:
    raw = "\n".join(sorted(str(record["case_id"]) for record in records))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def request_jobs(
    records: list[dict[str, Any]], profiles: list[str],
) -> list[tuple[dict[str, Any], str]]:
    return [
        (record, profile)
        for record in records
        for profile in profiles
        if profile != RESTRICTED_RULE_PROFILE or record["event_type"] in RULE_EVENT_TYPES
    ]


def build_request_plan(
    events_path: Path,
    cache_dir: Path,
    model: str = DEFAULT_MODEL,
    profiles: list[str] | None = None,
    thinking_mode: str = DEFAULT_THINKING_MODE,
    max_tokens: int = DEFAULT_MAX_TOKENS,
) -> dict[str, Any]:
    selected_profiles = profiles or [FACTS_ONLY_PROFILE]
    records = [
        json.loads(line) for line in events_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    grounder = DeepSeekGrounder(
        cache_dir, model=model, thinking_mode=thinking_mode, max_tokens=max_tokens,
    )
    entries: list[dict[str, Any]] = []
    for record, profile in request_jobs(records, selected_profiles):
        context = build_record_grounding_context(record)
        entries.append({
            "case_id": record["case_id"],
            "event_id": record["event_id"],
            "event_type": record["event_type"],
            "profile": profile,
            "cache_key": grounder.cache_key(record["text"], context, profile),
            "request_body_sha256": _canonical_sha256(
                grounder._request_body(record["text"], context, profile)
            ),
        })
    entries.sort(key=lambda item: (item["case_id"], item["profile"]))
    return {
        "schema_version": REQUEST_PLAN_SCHEMA_VERSION,
        "source_sha256": _source_digest(),
        "model": model,
        "thinking_mode": thinking_mode,
        "max_tokens": max_tokens,
        "prompt_schema_version": PROMPT_SCHEMA_VERSION,
        "profiles": selected_profiles,
        "event_file": str(events_path.resolve()),
        "event_file_sha256": sha256(events_path),
        "case_ids_sha256": case_ids_sha256(records),
        "event_count": len(records),
        "request_count": len(entries),
        "entries": entries,
    }


def write_request_plan(path: Path, plan: dict[str, Any]) -> None:
    content = json.dumps(plan, indent=2, sort_keys=True)
    if path.exists() and path.read_text(encoding="utf-8") != content:
        raise GroundingError(f"Refusing to overwrite a different request plan: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def verify_request_plan(
    plan_path: Path,
    events_path: Path,
    cache_dir: Path,
) -> dict[str, Any]:
    frozen = json.loads(plan_path.read_text(encoding="utf-8"))
    recomputed = build_request_plan(
        events_path,
        cache_dir,
        model=str(frozen["model"]),
        profiles=list(frozen["profiles"]),
        thinking_mode=str(frozen["thinking_mode"]),
        max_tokens=int(frozen["max_tokens"]),
    )
    if frozen != recomputed:
        raise GroundingError("Request plan differs from current event/prompt/source identities")
    return frozen


def verify_existing_cache_against_plan(
    plan_path: Path,
    events_path: Path,
    cache_dir: Path,
) -> dict[str, Any]:
    plan = verify_request_plan(plan_path, events_path, cache_dir)
    records = [
        json.loads(line) for line in events_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    by_identity = {
        (str(record["case_id"]), profile): record
        for record, profile in request_jobs(records, list(plan["profiles"]))
    }
    expected_keys = {str(entry["cache_key"]) for entry in plan["entries"]}
    observed_paths = list(cache_dir.glob("*.json")) if cache_dir.exists() else []
    unexpected = [path.name for path in observed_paths if path.stem not in expected_keys]
    if unexpected:
        raise GroundingError(f"Unexpected cache records outside frozen plan: {unexpected[:10]}")
    grounder = DeepSeekGrounder(
        cache_dir,
        model=str(plan["model"]),
        thinking_mode=str(plan["thinking_mode"]),
        max_tokens=int(plan["max_tokens"]),
    )
    verified = 0
    for entry in plan["entries"]:
        path = cache_dir / f"{entry['cache_key']}.json"
        if not path.exists():
            continue
        record = by_identity[(str(entry["case_id"]), str(entry["profile"]))]
        context = build_record_grounding_context(record)
        result = grounder.ground(
            record["text"], context, offline=True,
            inference_profile=str(entry["profile"]),
        )
        if not result.cache_hit:
            raise GroundingError("Existing-cache verification unexpectedly called the API")
        verified += 1
    return {
        "status": "pass",
        "request_count": int(plan["request_count"]),
        "verified_existing_records": verified,
        "missing_records": int(plan["request_count"]) - verified,
        "unexpected_records": 0,
        "request_plan_sha256": sha256(plan_path),
    }


def seal_cache(
    plan_path: Path,
    events_path: Path,
    cache_dir: Path,
    output_path: Path,
) -> dict[str, Any]:
    plan = verify_request_plan(plan_path, events_path, cache_dir)
    existing = verify_existing_cache_against_plan(plan_path, events_path, cache_dir)
    if existing["missing_records"] != 0:
        raise GroundingError("Cannot seal an incomplete cache")
    entries: list[dict[str, Any]] = []
    valid = 0
    invalid = 0
    for planned in plan["entries"]:
        path = cache_dir / f"{planned['cache_key']}.json"
        record = json.loads(path.read_text(encoding="utf-8"))
        entries.append({
            **planned,
            "cache_file": path.name,
            "cache_file_sha256": sha256(path),
            "raw_content_sha256": record["raw_content_sha256"],
            "raw_response_sha256": record["raw_response_sha256"],
            "canonical_candidate_sha256": record["canonical_candidate_sha256"],
            "response_status": record["response_status"],
            "response_id": record.get("response_id"),
            "response_model": record.get("response_model"),
            "system_fingerprint": record.get("system_fingerprint"),
            "finish_reason": record.get("finish_reason"),
        })
        valid += int(record["response_status"] == "valid")
        invalid += int(record["response_status"] == "invalid")
    manifest = {
        "schema_version": CACHE_SEAL_SCHEMA_VERSION,
        "status": "sealed_complete",
        "source_sha256": _source_digest(),
        "model": plan["model"],
        "thinking_mode": plan["thinking_mode"],
        "max_tokens": plan["max_tokens"],
        "prompt_schema_version": plan["prompt_schema_version"],
        "profiles": plan["profiles"],
        "event_file": str(events_path.resolve()),
        "event_file_sha256": sha256(events_path),
        "case_ids_sha256": plan["case_ids_sha256"],
        "request_plan": str(plan_path.resolve()),
        "request_plan_sha256": sha256(plan_path),
        "cache_directory": str(cache_dir.resolve()),
        "request_count": len(entries),
        "valid_response_count": valid,
        "invalid_response_count": invalid,
        "entries": entries,
    }
    content = json.dumps(manifest, indent=2, sort_keys=True)
    if output_path.exists() and output_path.read_text(encoding="utf-8") != content:
        raise GroundingError(f"Refusing to overwrite a different cache seal: {output_path}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(content, encoding="utf-8")
    return manifest


def verify_cache_seal(
    seal_path: Path,
    plan_path: Path,
    events_path: Path,
    cache_dir: Path,
) -> dict[str, Any]:
    manifest = json.loads(seal_path.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != CACHE_SEAL_SCHEMA_VERSION:
        raise GroundingError("Unknown cache seal schema")
    plan = verify_request_plan(plan_path, events_path, cache_dir)
    checks = {
        "status": manifest.get("status") == "sealed_complete",
        "source_sha256": manifest.get("source_sha256") == _source_digest(),
        "event_file_sha256": manifest.get("event_file_sha256") == sha256(events_path),
        "case_ids_sha256": manifest.get("case_ids_sha256") == plan["case_ids_sha256"],
        "request_plan_sha256": manifest.get("request_plan_sha256") == sha256(plan_path),
        "model": manifest.get("model") == plan["model"],
        "thinking_mode": manifest.get("thinking_mode") == plan["thinking_mode"],
        "prompt_schema_version": manifest.get("prompt_schema_version") == PROMPT_SCHEMA_VERSION,
        "request_count": int(manifest.get("request_count", -1)) == int(plan["request_count"]),
    }
    if not all(checks.values()):
        raise GroundingError(f"Cache seal metadata failed: {[key for key, value in checks.items() if not value]}")
    records = [
        json.loads(line) for line in events_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    grounder = DeepSeekGrounder(
        cache_dir,
        model=str(plan["model"]),
        thinking_mode=str(plan["thinking_mode"]),
        max_tokens=int(plan["max_tokens"]),
        sealed_manifest_path=seal_path,
    )
    verified = 0
    for record, profile in request_jobs(records, list(plan["profiles"])):
        grounder.ground(
            record["text"], build_record_grounding_context(record), offline=True,
            inference_profile=profile,
        )
        verified += 1
    return {
        "status": "pass",
        "checks": checks,
        "verified_records": verified,
        "seal_sha256": sha256(seal_path),
        "request_plan_sha256": sha256(plan_path),
    }


def _canonical_sha256(payload: Any) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description="Freeze and verify DeepSeek request plans and cache evidence")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command in ("plan", "gate", "seal", "verify"):
        sub = subparsers.add_parser(command)
        sub.add_argument("--events", type=Path, required=True)
        sub.add_argument("--cache", type=Path, required=True)
        sub.add_argument("--plan", type=Path, required=True)
        if command == "plan":
            sub.add_argument("--model", default=DEFAULT_MODEL)
            sub.add_argument("--profiles", nargs="+", default=[FACTS_ONLY_PROFILE])
            sub.add_argument("--thinking-mode", default=DEFAULT_THINKING_MODE)
            sub.add_argument("--max-tokens", type=int, default=DEFAULT_MAX_TOKENS)
        if command in {"seal", "verify"}:
            sub.add_argument("--seal", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "plan":
        plan = build_request_plan(
            args.events, args.cache, args.model, args.profiles,
            args.thinking_mode, args.max_tokens,
        )
        write_request_plan(args.plan, plan)
        result = {"status": "pass", "request_count": plan["request_count"], "plan_sha256": sha256(args.plan)}
    elif args.command == "gate":
        result = verify_existing_cache_against_plan(args.plan, args.events, args.cache)
    elif args.command == "seal":
        manifest = seal_cache(args.plan, args.events, args.cache, args.seal)
        result = {"status": "pass", "request_count": manifest["request_count"], "seal_sha256": sha256(args.seal)}
    else:
        result = verify_cache_seal(args.seal, args.plan, args.events, args.cache)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
