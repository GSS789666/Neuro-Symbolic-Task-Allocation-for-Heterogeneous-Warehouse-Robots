from __future__ import annotations

import argparse
import concurrent.futures
import gzip
import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .scenario import GeneratorConfig, generate_scenario, stable_split
from .grounding import DEFAULT_MODEL, DEFAULT_THINKING_MODE, PROMPT_SCHEMA_VERSION, DeepSeekGrounder
from .simulator import WarehouseSimulator


@dataclass(frozen=True)
class ExperimentTask:
    task_id: str
    scale: str
    seed: int
    trace_seed: int
    episode_index: int
    method: str
    load_level: float
    disturbance_level: str
    horizon: int
    timeout_s: float
    split: str
    llm_cache: str
    llm_cache_manifest: str
    llm_model: str
    llm_thinking_mode: str
    prompt_schema_version: str
    offline_llm: bool
    audit_schema: str
    source_sha256: str


def build_tasks(config: dict[str, Any], include_secondary: bool = False) -> list[ExperimentTask]:
    scales = list(config["scales"])
    if include_secondary:
        scales.extend(config.get("secondary_scales", []))
    allowed_splits = set(config.get("allowed_splits", ["development", "validation", "test"]))
    llm_model = os.environ.get("DEEPSEEK_MODEL", str(config.get("llm_model", DEFAULT_MODEL)))
    llm_thinking_mode = str(config.get("llm_thinking_mode", DEFAULT_THINKING_MODE))
    audit_schema = str(config.get("audit_schema", "mrta-audit-llm-1.1"))
    source_sha256 = _source_digest()
    tasks: list[ExperimentTask] = []
    for scale in scales:
        for base_seed in config["seeds"]:
            for episode_index in range(int(config["episodes_per_seed"])):
                seed = int(base_seed)
                trace_seed = seed + episode_index * 100_000
                split = stable_split(f"{scale}-map-{seed % 20}")
                if split not in allowed_splits:
                    raise ValueError(
                        f"Seed {seed} maps to split {split}, which is outside allowed_splits={sorted(allowed_splits)}"
                    )
                for load_level in config["load_levels"]:
                    for disturbance in config["disturbance_levels"]:
                        for method in config["methods"]:
                            identity = {
                                "scale": scale, "seed": seed, "trace_seed": trace_seed, "episode": episode_index,
                                "method": method, "load": load_level, "disturbance": disturbance,
                                "horizon": config["horizon"], "timeout": config["solver_timeout_s"],
                                "llm_model": llm_model,
                                "llm_cache_manifest": str(config.get("llm_cache_manifest", "")),
                                "llm_thinking_mode": llm_thinking_mode,
                                "prompt_schema_version": PROMPT_SCHEMA_VERSION,
                                "audit_schema": audit_schema,
                                "source_sha256": source_sha256,
                            }
                            raw = json.dumps(identity, sort_keys=True, separators=(",", ":"))
                            task_id = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]
                            tasks.append(ExperimentTask(
                                task_id=task_id, scale=scale, seed=seed, trace_seed=trace_seed,
                                episode_index=episode_index, method=method,
                                load_level=float(load_level), disturbance_level=disturbance,
                                horizon=int(config["horizon"]), timeout_s=float(config["solver_timeout_s"]),
                                split=split,
                                llm_cache=str(config.get("llm_cache", "llm_track_v1_4/cache/e2e_deepseek_v4")),
                                llm_cache_manifest=str(config.get("llm_cache_manifest", "")),
                                llm_model=llm_model,
                                llm_thinking_mode=llm_thinking_mode,
                                prompt_schema_version=PROMPT_SCHEMA_VERSION,
                                offline_llm=bool(config.get("offline_llm", True)),
                                audit_schema=audit_schema,
                                source_sha256=source_sha256,
                            ))
    return tasks


def execute_task(task: ExperimentTask) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    generator_config = GeneratorConfig(
        scale=task.scale, seed=task.seed, trace_seed=task.trace_seed, load_level=task.load_level,
        disturbance_level=task.disturbance_level, horizon=task.horizon,
    )
    state = generate_scenario(generator_config)
    grounder = None
    if task.method.startswith("deepseek_"):
        grounder = DeepSeekGrounder(
            Path(task.llm_cache),
            model=task.llm_model,
            thinking_mode=task.llm_thinking_mode,
            sealed_manifest_path=Path(task.llm_cache_manifest) if task.llm_cache_manifest else None,
        )
    simulator = WarehouseSimulator(
        state=state,
        method=task.method,
        timeout_s=task.timeout_s,
        grounder=grounder,
        offline_llm=task.offline_llm,
        audit_schema=task.audit_schema,
        load_level=task.load_level,
        disturbance_level=task.disturbance_level,
        dataset_split=task.split,
    )
    result, audit = simulator.run(task.horizon)
    payload = {
        "task": asdict(task), "result": asdict(result),
        "generator_config_sha256": generator_config.digest(),
    }
    return payload, audit


def run_experiment(config_path: Path, output_root: Path, include_secondary: bool = False) -> Path:
    config = json.loads(config_path.read_text(encoding="utf-8"))
    tasks = build_tasks(config, include_secondary)
    config_hash = hashlib.sha256(config_path.read_bytes()).hexdigest()
    freeze_binding = _required_freeze_binding(config, config_path, tasks, config_hash)
    cache_manifest_binding = _cache_manifest_binding(tasks)
    run_dir = output_root / config["run_name"]
    episodes_dir = run_dir / "episodes"
    audits_dir = run_dir / "audits"
    episodes_dir.mkdir(parents=True, exist_ok=True)
    audits_dir.mkdir(parents=True, exist_ok=True)
    started_utc = datetime.now(timezone.utc).isoformat()
    _atomic_json(run_dir / "run_manifest.json", {
        "status": "running", "run_name": config["run_name"],
        "provenance": config["provenance"], "config_path": str(config_path.resolve()),
        "config_sha256": config_hash, "started_utc": started_utc,
        "task_count": len(tasks), "include_secondary": include_secondary,
        "audit_schema": str(config.get("audit_schema", "mrta-audit-llm-1.1")),
        "source_sha256": _source_digest(),
        "source_inventory": _source_inventory(),
        "host": _host_metadata(), "repository": _git_metadata(config_path.parent),
        "command": " ".join(sys.argv),
        **freeze_binding,
        **cache_manifest_binding,
    })
    pending = [
        task for task in tasks
        if not (episodes_dir / f"{task.task_id}.json").exists()
        or not (audits_dir / f"{task.task_id}.jsonl.gz").exists()
    ]
    workers = min(int(config.get("max_parallel_workers", 1)), max(1, os.cpu_count() or 1), 8)
    print(json.dumps({"run_dir": str(run_dir), "tasks": len(tasks), "already_complete": len(tasks) - len(pending), "workers": workers}))
    if workers == 1:
        for index, task in enumerate(pending, 1):
            _execute_and_store(task, episodes_dir, audits_dir)
            print(json.dumps({"completed_now": index, "pending_total": len(pending), "task_id": task.task_id}))
    else:
        with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as executor:
            future_by_task = {executor.submit(execute_task, task): task for task in pending}
            for index, future in enumerate(concurrent.futures.as_completed(future_by_task), 1):
                task = future_by_task[future]
                payload, audit = future.result()
                _store_task(task, payload, audit, episodes_dir, audits_dir)
                print(json.dumps({"completed_now": index, "pending_total": len(pending), "task_id": task.task_id}))
    results = []
    for task in tasks:
        episode_path = episodes_dir / f"{task.task_id}.json"
        if not episode_path.exists():
            raise RuntimeError(f"Missing episode result after execution: {episode_path}")
        results.append(json.loads(episode_path.read_text(encoding="utf-8")))
    results_path = run_dir / "episode_results.jsonl"
    _atomic_jsonl(results_path, results)
    _atomic_json(run_dir / "run_manifest.json", {
        "status": "complete", "run_name": config["run_name"],
        "provenance": config["provenance"], "config_path": str(config_path.resolve()),
        "config_sha256": config_hash, "started_utc": started_utc,
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "task_count": len(tasks), "include_secondary": include_secondary,
        "audit_schema": str(config.get("audit_schema", "mrta-audit-llm-1.1")),
        "source_sha256": _source_digest(),
        "source_inventory": _source_inventory(),
        "results_sha256": hashlib.sha256(results_path.read_bytes()).hexdigest(),
        "host": _host_metadata(), "repository": _git_metadata(config_path.parent),
        "command": " ".join(sys.argv),
        **freeze_binding,
        **cache_manifest_binding,
    })
    return run_dir


def _execute_and_store(task: ExperimentTask, episodes_dir: Path, audits_dir: Path) -> None:
    payload, audit = execute_task(task)
    _store_task(task, payload, audit, episodes_dir, audits_dir)


def _store_task(
    task: ExperimentTask,
    payload: dict[str, Any],
    audit: list[dict[str, Any]],
    episodes_dir: Path,
    audits_dir: Path,
) -> None:
    _atomic_json(episodes_dir / f"{task.task_id}.json", payload)
    payload_sha256 = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    audit = [*audit, {
        "time": payload["result"]["horizon"],
        "kind": "audit_complete",
        "task_id": task.task_id,
        "source_sha256": task.source_sha256,
        "payload_sha256": payload_sha256,
        "audit_schema": task.audit_schema,
    }]
    audit_path = audits_dir / f"{task.task_id}.jsonl.gz"
    descriptor, temporary = tempfile.mkstemp(prefix=audit_path.name, suffix=".tmp", dir=audits_dir)
    os.close(descriptor)
    try:
        with gzip.open(temporary, "wt", encoding="utf-8", newline="\n") as stream:
            for record in audit:
                stream.write(json.dumps(record, sort_keys=True) + "\n")
        os.replace(temporary, audit_path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    descriptor, temporary = tempfile.mkstemp(prefix=path.name, suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(payload, stream, sort_keys=True, indent=2)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _atomic_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    descriptor, temporary = tempfile.mkstemp(prefix=path.name, suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            for row in rows:
                stream.write(json.dumps(row, sort_keys=True) + "\n")
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _host_metadata() -> dict[str, Any]:
    versions = {}
    for package in ("ortools", "pytest"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    return {
        "python": sys.version, "platform": platform.platform(),
        "processor": platform.processor(), "logical_cpu_count": os.cpu_count(),
        "packages": versions,
    }


def _source_digest() -> str:
    source_root = Path(__file__).resolve().parent
    digest = hashlib.sha256()
    for path in sorted(source_root.glob("*.py")):
        digest.update(path.name.encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _source_inventory() -> dict[str, str]:
    source_root = Path(__file__).resolve().parent
    return {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(source_root.glob("*.py"))
    }


def _required_freeze_binding(
    config: dict[str, Any],
    config_path: Path,
    tasks: list[ExperimentTask],
    config_hash: str,
) -> dict[str, Any]:
    required = config.get("required_freeze_manifest")
    if not required:
        return {}
    freeze_path = Path(str(required))
    if not freeze_path.is_absolute():
        freeze_path = config_path.resolve().parent.parent / freeze_path
    if not freeze_path.exists():
        raise RuntimeError(f"Required pre-Main freeze manifest is missing: {freeze_path}")
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    if freeze.get("status") != "frozen_before_main" or freeze.get("main_results_opened") is not False:
        raise RuntimeError("Required freeze manifest is not an unopened pre-Main freeze")
    task_payload = [asdict(task) for task in sorted(tasks, key=lambda item: item.task_id)]
    task_digest = hashlib.sha256(
        json.dumps(task_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    checks = {
        "run_name": config["run_name"],
        "config_sha256": config_hash,
        "source_sha256": _source_digest(),
        "source_inventory": _source_inventory(),
        "task_count": len(tasks),
        "task_ids_sha256": task_digest,
        "audit_schema": str(config.get("audit_schema", "mrta-audit-llm-1.1")),
    }
    for key, expected in checks.items():
        if freeze.get(key) != expected:
            raise RuntimeError(f"Required freeze manifest mismatch for {key}")
    return {
        "freeze_manifest_path": str(freeze_path),
        "freeze_manifest_sha256": hashlib.sha256(freeze_path.read_bytes()).hexdigest(),
        "protocol_id": freeze.get("protocol_id"),
    }


def _cache_manifest_binding(tasks: list[ExperimentTask]) -> dict[str, Any]:
    manifests = sorted({task.llm_cache_manifest for task in tasks if task.method.startswith("deepseek_")})
    if not manifests:
        return {"cache_manifests": []}
    if "" in manifests:
        raise RuntimeError("DeepSeek experiment tasks require a sealed cache manifest")
    records = []
    for value in manifests:
        path = Path(value)
        if not path.exists():
            raise RuntimeError(f"Required sealed cache manifest is missing: {path}")
        records.append({
            "path": str(path.resolve()),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        })
    return {"cache_manifests": records}


def _git_metadata(start: Path) -> dict[str, Any]:
    try:
        root = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"], cwd=start,
            capture_output=True, text=True, check=True,
        ).stdout.strip()
        commit = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=start,
            capture_output=True, text=True, check=True,
        ).stdout.strip()
        dirty = bool(subprocess.run(
            ["git", "status", "--porcelain"], cwd=start,
            capture_output=True, text=True, check=True,
        ).stdout.strip())
        return {"root": root, "commit": commit, "dirty": dirty}
    except (subprocess.CalledProcessError, FileNotFoundError):
        return {"root": None, "commit": None, "dirty": None}


def main() -> None:
    parser = argparse.ArgumentParser(description="Run resumable LR-TR-UR simulation experiments")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("runs"))
    parser.add_argument("--include-secondary", action="store_true")
    args = parser.parse_args()
    started = time.perf_counter()
    run_dir = run_experiment(args.config, args.output, args.include_secondary)
    print(json.dumps({"status": "complete", "run_dir": str(run_dir), "wall_time_s": time.perf_counter() - started}, indent=2))


if __name__ == "__main__":
    main()
