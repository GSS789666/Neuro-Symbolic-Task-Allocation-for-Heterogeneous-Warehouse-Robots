from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import random
import tempfile
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .domain import DynamicEvent, RobotRole, WarehouseState, canonical_jsonable
from .knowledge import Atom, KnowledgeError, Rule, VersionedKnowledgeBase
from .shield import ALLOWED_PROFILES, FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE, RULE_EVENT_TYPES


PROMPT_SCHEMA_VERSION = "deepseek-grounding-2.3"
CACHE_RECORD_SCHEMA_VERSION = "deepseek-cache-record-2.0"
CACHE_SEAL_SCHEMA_VERSION = "deepseek-cache-seal-1.0"
REQUEST_PLAN_SCHEMA_VERSION = "deepseek-request-plan-1.0"
DEFAULT_MODEL = "deepseek-v4-flash"
DEFAULT_THINKING_MODE = "disabled"
DEFAULT_MAX_TOKENS = 1024
ALLOWED_OPERATIONS = {"insert_fact", "retract_fact", "supersede_fact", "insert_rule"}


class CacheMiss(RuntimeError):
    pass


class GroundingError(RuntimeError):
    pass


@dataclass(frozen=True)
class GroundingResult:
    cache_key: str
    model: str
    inference_profile: str
    thinking_mode: str
    candidate: dict[str, Any] | None
    response_status: str
    validation_error: str | None
    cache_hit: bool
    latency_ms: float
    api_latency_ms: float | None
    request_utc: str | None


class DeepSeekGrounder:
    def __init__(
        self,
        cache_dir: Path,
        model: str = DEFAULT_MODEL,
        base_url: str = "https://api.deepseek.com",
        timeout_s: float = 90.0,
        max_retries: int = 5,
        inference_profile: str = FACTS_ONLY_PROFILE,
        thinking_mode: str = DEFAULT_THINKING_MODE,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        sealed_manifest_path: Path | None = None,
    ) -> None:
        if inference_profile not in ALLOWED_PROFILES:
            raise ValueError(f"Unknown inference profile {inference_profile!r}")
        if thinking_mode not in {"enabled", "disabled"}:
            raise ValueError("thinking_mode must be 'enabled' or 'disabled'")
        if max_tokens <= 0:
            raise ValueError("max_tokens must be positive")
        self.cache_dir = cache_dir
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.timeout_s = timeout_s
        self.max_retries = max_retries
        self.inference_profile = inference_profile
        self.thinking_mode = thinking_mode
        self.max_tokens = max_tokens
        self.sealed_manifest_path = sealed_manifest_path
        self._sealed_entries: dict[str, dict[str, Any]] | None = None
        if sealed_manifest_path is not None:
            if not sealed_manifest_path.exists():
                raise GroundingError(f"Sealed cache manifest is missing: {sealed_manifest_path}")
            manifest = json.loads(sealed_manifest_path.read_text(encoding="utf-8"))
            if manifest.get("schema_version") != CACHE_SEAL_SCHEMA_VERSION:
                raise GroundingError("Unknown sealed cache manifest schema")
            if manifest.get("status") != "sealed_complete":
                raise GroundingError("Sealed cache manifest is not complete")
            if manifest.get("source_sha256") != _package_source_digest():
                raise GroundingError("Sealed cache manifest source digest mismatch")
            if Path(str(manifest.get("cache_directory", ""))).resolve() != cache_dir.resolve():
                raise GroundingError("Sealed cache manifest points to a different cache directory")
            if manifest.get("model") != model or manifest.get("thinking_mode") != thinking_mode:
                raise GroundingError("Sealed cache manifest model/thinking contract mismatch")
            if manifest.get("prompt_schema_version") != PROMPT_SCHEMA_VERSION:
                raise GroundingError("Sealed cache manifest prompt schema mismatch")
            self._sealed_entries = {
                str(entry["cache_key"]): entry for entry in manifest.get("entries", [])
            }
            if len(self._sealed_entries) != len(manifest.get("entries", [])):
                raise GroundingError("Duplicate cache keys in sealed manifest")
            if int(manifest.get("request_count", -1)) != len(self._sealed_entries):
                raise GroundingError("Sealed cache manifest request count mismatch")
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def cache_key(
        self,
        text: str,
        context: dict[str, Any],
        inference_profile: str | None = None,
    ) -> str:
        profile = inference_profile or self.inference_profile
        if profile not in ALLOWED_PROFILES:
            raise ValueError(f"Unknown inference profile {profile!r}")
        payload = {
            "model": self.model,
            "prompt_schema_version": PROMPT_SCHEMA_VERSION,
            "inference_profile": profile,
            "thinking_mode": self.thinking_mode,
            "max_tokens": self.max_tokens,
            "text": text,
            "context": canonical_jsonable(context),
        }
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def ground(
        self,
        text: str,
        context: dict[str, Any],
        offline: bool,
        api_key: str | None = None,
        inference_profile: str | None = None,
    ) -> GroundingResult:
        profile = inference_profile or self.inference_profile
        if profile not in ALLOWED_PROFILES:
            raise GroundingError(f"Unknown inference profile {profile!r}")
        key = self.cache_key(text, context, profile)
        path = self.cache_dir / f"{key}.json"
        started = time.perf_counter()
        if path.exists():
            record = json.loads(path.read_text(encoding="utf-8"))
            candidate = self._validate_cache_record(
                record, path, text, context, profile, key,
            )
            validation_error = record.get("validation_error")
            return GroundingResult(
                key, record["model"], profile, self.thinking_mode, candidate,
                record["response_status"], validation_error, True,
                (time.perf_counter() - started) * 1000, record.get("api_latency_ms"),
                record.get("request_utc"),
            )
        if offline:
            raise CacheMiss(f"Missing DeepSeek cache entry {key}; run the resumable prefetch command while online")
        token = api_key or os.environ.get("DEEPSEEK_API_KEY")
        if not token:
            raise GroundingError("DEEPSEEK_API_KEY is not set")
        request_body = self._request_body(text, context, profile)
        request_body_sha256 = _json_sha256(request_body)
        last_error: Exception | None = None
        for attempt in range(self.max_retries):
            try:
                response, request_utc = self._post(request_body, token)
                content = response["choices"][0]["message"]["content"]
                candidate: dict[str, Any] | None = None
                validation_error: str | None = None
                try:
                    if not content:
                        raise GroundingError("DeepSeek returned empty JSON content")
                    candidate = validate_candidate(json.loads(content))
                except (json.JSONDecodeError, KnowledgeError, GroundingError) as exc:
                    validation_error = f"{type(exc).__name__}:{exc}"
                api_latency_ms = (time.perf_counter() - started) * 1000
                record = {
                    "cache_record_schema_version": CACHE_RECORD_SCHEMA_VERSION,
                    "cache_key": key, "model": self.model,
                    "prompt_schema_version": PROMPT_SCHEMA_VERSION,
                    "inference_profile": profile,
                    "thinking_mode": self.thinking_mode,
                    "max_tokens": self.max_tokens,
                    "request_body_sha256": request_body_sha256,
                    "request_utc": request_utc,
                    "api_latency_ms": api_latency_ms,
                    "response_status": "valid" if candidate is not None else "invalid",
                    "candidate": candidate,
                    "raw_content": content,
                    "raw_content_sha256": _text_sha256(content),
                    "canonical_candidate_sha256": _canonical_sha256(candidate),
                    "raw_response": response,
                    "raw_response_sha256": _canonical_sha256(response),
                    "validation_error": validation_error,
                    "usage": response.get("usage"),
                    "response_id": response.get("id"),
                    "response_model": response.get("model"),
                    "system_fingerprint": response.get("system_fingerprint"),
                    "finish_reason": response.get("choices", [{}])[0].get("finish_reason"),
                }
                _atomic_json(path, record)
                return GroundingResult(
                    key, self.model, profile, self.thinking_mode, candidate,
                    record["response_status"], validation_error, False,
                    api_latency_ms, api_latency_ms, request_utc,
                )
            except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, KeyError, GroundingError) as exc:
                last_error = exc
                if attempt + 1 >= self.max_retries:
                    break
                time.sleep(min(20.0, (2**attempt) + random.random()))
        raise GroundingError(f"DeepSeek request failed after {self.max_retries} attempts: {last_error}")

    def _validate_cache_record(
        self,
        record: dict[str, Any],
        path: Path,
        text: str,
        context: dict[str, Any],
        profile: str,
        key: str,
    ) -> dict[str, Any] | None:
        expected_metadata = {
            "cache_record_schema_version": CACHE_RECORD_SCHEMA_VERSION,
            "cache_key": key,
            "model": self.model,
            "prompt_schema_version": PROMPT_SCHEMA_VERSION,
            "inference_profile": profile,
            "thinking_mode": self.thinking_mode,
            "max_tokens": self.max_tokens,
            "request_body_sha256": _json_sha256(self._request_body(text, context, profile)),
        }
        for field, expected_value in expected_metadata.items():
            if record.get(field) != expected_value:
                raise GroundingError(
                    f"Cache metadata mismatch for {field}: {record.get(field)!r} != {expected_value!r}"
                )
        raw_content = record.get("raw_content")
        raw_response = record.get("raw_response")
        if not isinstance(raw_content, str) or not isinstance(raw_response, dict):
            raise GroundingError("Cache must retain raw_content and the full raw_response object")
        hash_checks = {
            "raw_content_sha256": _text_sha256(raw_content),
            "raw_response_sha256": _canonical_sha256(raw_response),
            "canonical_candidate_sha256": _canonical_sha256(record.get("candidate")),
        }
        for field, expected_value in hash_checks.items():
            if record.get(field) != expected_value:
                raise GroundingError(f"Cache cryptographic binding mismatch for {field}")
        try:
            response_content = raw_response["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise GroundingError("Malformed retained raw_response") from exc
        if response_content != raw_content:
            raise GroundingError("raw_response content differs from raw_content")
        response_bindings = {
            "response_id": raw_response.get("id"),
            "response_model": raw_response.get("model"),
            "system_fingerprint": raw_response.get("system_fingerprint"),
            "finish_reason": raw_response.get("choices", [{}])[0].get("finish_reason"),
            "usage": raw_response.get("usage"),
        }
        for field, expected_value in response_bindings.items():
            if record.get(field) != expected_value:
                raise GroundingError(f"Retained response field mismatch for {field}")

        candidate: dict[str, Any] | None = None
        status = record.get("response_status")
        parsed_candidate: dict[str, Any] | None = None
        parse_error: Exception | None = None
        try:
            parsed_candidate = validate_candidate(json.loads(raw_content))
        except (json.JSONDecodeError, KnowledgeError, GroundingError) as exc:
            parse_error = exc
        if status == "valid":
            candidate = validate_candidate(record.get("candidate"))
            if parsed_candidate != candidate:
                raise GroundingError("Stored candidate differs from the candidate parsed from raw_content")
        elif status == "invalid":
            if record.get("candidate") is not None or parsed_candidate is not None:
                raise GroundingError("Invalid cache status is inconsistent with candidate/raw_content")
            if parse_error is None:
                raise GroundingError("Invalid cache response lacks a reproducible validation failure")
        else:
            raise GroundingError("Cache response_status must be valid or invalid")

        if self._sealed_entries is not None:
            entry = self._sealed_entries.get(key)
            if entry is None:
                raise GroundingError(f"Cache key {key} is absent from sealed manifest")
            sealed_checks = {
                "profile": profile,
                "cache_file_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "request_body_sha256": record["request_body_sha256"],
                "raw_content_sha256": record["raw_content_sha256"],
                "raw_response_sha256": record["raw_response_sha256"],
                "canonical_candidate_sha256": record["canonical_candidate_sha256"],
                "response_model": record.get("response_model"),
                "system_fingerprint": record.get("system_fingerprint"),
            }
            for field, actual_value in sealed_checks.items():
                if entry.get(field) != actual_value:
                    raise GroundingError(f"Sealed cache entry mismatch for {field}")
        return candidate

    def _request_body(
        self,
        text: str,
        context: dict[str, Any],
        inference_profile: str,
    ) -> dict[str, Any]:
        schema = {
            "top_level_exact_keys": ["schema_version", "operations", "confidence", "rationale_code"],
            "schema_version_exact_value": PROMPT_SCHEMA_VERSION,
            "operation_contracts": {
                "insert_fact_or_retract_fact": {"exact_keys": ["op", "atom"], "atom": {"predicate": "string", "args": ["typed strings"]}},
                "supersede_fact": {"exact_keys": ["op", "key", "atom"], "key": ["atom argument prefix"], "atom": {"predicate": "string", "args": ["typed strings"]}},
                "insert_rule": {"exact_keys": ["op", "rule"], "rule": {"rule_id": "string", "body": ["atoms"], "head": ["atoms"], "temporary": True, "ttl": 10}},
            },
            "confidence": "number in [0,1]",
            "rationale_code": "short code, at most 80 characters",
        }
        system = (
            "You translate a warehouse event into a JSON symbolic candidate. Output JSON only. "
            "Never issue motor commands, declare an unobserved path clear, remove a safety constraint, "
            "or invent an entity. Use only the supplied ontology and entities. A temporary rule must be "
            "range restricted and may change only eligibility, priority, route penalty, or required checks. "
            "Extract identifiers, coordinates, values, and TTLs from event_text. The authenticated sensor/WMS "
            "payload is deliberately hidden from you and will be checked independently by a deterministic shield."
        )
        profile_instruction = (
            "Return exactly one operation: the required event-fact operation. Do not return a rule."
            if inference_profile == FACTS_ONLY_PROFILE
            else (
                "Return exactly two operations in this order: (1) the required event-fact operation from "
                "event_fact_contracts; (2) exactly one insert_rule operation copied from the matching "
                "restricted_rule_templates blueprint. A rule-only answer, a fact-only answer, or a second "
                "rule is invalid. Instantiate rule_id with context.event_id, parse TTL and any indicated "
                "numeric/role placeholder from event_text, and preserve every ?variable exactly as shown."
            )
        )
        prompt_context = {
            key: value for key, value in canonical_jsonable(context).items()
            if key not in {"authenticated_payload", "event_type"}
        }
        # Accepted writes use surface_condition(x,y,low_friction). The legacy
        # observation alias is excluded because it is never a write target.
        if isinstance(prompt_context.get("ontology"), dict):
            prompt_context["ontology"].pop("low_friction_cell", None)
        event_fact_contracts = {
            "temporary_obstacle_or_blocked_cell": {
                "operation": {"op": "insert_fact", "atom": {"predicate": "blocked_cell", "args": ["<x>", "<y>", "true"]}},
                "distinguish_from": "role-specific access restrictions use access_restricted, not blocked_cell",
            },
            "moving_person_or_robot_congestion": {
                "operation": {"op": "supersede_fact", "key": ["<x>", "<y>"], "atom": {"predicate": "congestion", "args": ["<x>", "<y>", "<parsed_penalty>"]}},
                "forbidden_substitutes": ["insert_fact", "route_penalty"],
            },
            "robot_unavailable_or_out_of_service": {
                "operation": {"op": "supersede_fact", "key": ["<robot_id>"], "atom": {"predicate": "robot_status", "args": ["<robot_id>", "unavailable"]}},
                "forbidden_substitutes": ["insert_fact", "robot_eligible"],
            },
            "low_friction_surface": {
                "operation": {"op": "insert_fact", "atom": {"predicate": "surface_condition", "args": ["<x>", "<y>", "low_friction"]}},
                "forbidden_predicate": "low_friction_cell",
            },
            "role_specific_access_restriction": {
                "operation": {"op": "insert_fact", "atom": {"predicate": "access_restricted", "args": ["<x>", "<y>", "<normalized_role_token>"]}},
                "forbidden_predicate": "blocked_cell",
            },
            "cargo_service_or_unloading_time_update": {
                "operation": {"op": "supersede_fact", "key": ["<cargo_id>"], "atom": {"predicate": "service_time", "args": ["<cargo_id>", "<parsed_time>"]}},
                "forbidden_operation": "insert_fact",
            },
            "cargo_cancelled": {
                "operation": {"op": "insert_fact", "atom": {"predicate": "cargo_cancelled", "args": ["<cargo_id>", "true"]}},
            },
        }
        role_token_normalization = {
            "TR": ["TR", "transport", "transport-role", "transport robot"],
            "LR": ["LR", "loader", "loading-role", "loader robot"],
            "UR": ["UR", "unloader", "unloading-role", "unloader robot"],
            "output_rule": "Emit only the canonical uppercase token TR, LR, or UR; never emit words such as transport, loader, or unloader.",
        }
        restricted_rule_templates = {
            "low_friction": {
                "op": "insert_rule",
                "rule": {
                    "rule_id": "temporary_low_friction_policy_<event_id>",
                    "body": [{"predicate": "surface_condition", "args": ["?x", "?y", "low_friction"]}],
                    "head": [{"predicate": "route_penalty", "args": ["?x", "?y", "9"]}],
                    "temporary": True,
                    "ttl": "<parsed_ttl>",
                },
            },
            "moving_congestion": {
                "op": "insert_rule",
                "rule": {
                    "rule_id": "temporary_moving_congestion_policy_<event_id>",
                    "body": [{"predicate": "congestion", "args": ["?x", "?y", "?level"]}],
                    "head": [{"predicate": "route_penalty", "args": ["?x", "?y", "<parsed_penalty>"]}],
                    "temporary": True,
                    "ttl": "<parsed_ttl>",
                },
            },
            "robot_unavailable": {
                "op": "insert_rule",
                "rule": {
                    "rule_id": "temporary_robot_unavailable_policy_<event_id>",
                    "body": [
                        {"predicate": "robot_status", "args": ["?robot", "unavailable"]},
                        {"predicate": "cargo_known", "args": ["?cargo", "true"]},
                    ],
                    "head": [{"predicate": "robot_eligible", "args": ["?robot", "?cargo", "false"]}],
                    "temporary": True,
                    "ttl": "<parsed_ttl>",
                },
            },
            "access_restriction": {
                "op": "insert_rule",
                "rule": {
                    "rule_id": "temporary_access_restriction_policy_<event_id>",
                    "body": [{"predicate": "access_restricted", "args": ["?x", "?y", "<normalized_role_token>"]}],
                    "head": [{"predicate": "requires_safety_check", "args": ["?x", "?y", "true"]}],
                    "temporary": True,
                    "ttl": "<parsed_ttl>",
                },
            },
        }
        output_example = (
            {
                "schema_version": PROMPT_SCHEMA_VERSION,
                "operations": [{"op": "supersede_fact", "key": ["6", "2"], "atom": {"predicate": "congestion", "args": ["6", "2", "5"]}}],
                "confidence": 0.99,
                "rationale_code": "authenticated_event_translation",
            }
            if inference_profile == FACTS_ONLY_PROFILE
            else {
                "schema_version": PROMPT_SCHEMA_VERSION,
                "operations": [
                    {"op": "insert_fact", "atom": {"predicate": "access_restricted", "args": ["3", "4", "TR"]}},
                    {"op": "insert_rule", "rule": {
                        "rule_id": "temporary_access_restriction_policy_E-DEMO",
                        "body": [{"predicate": "access_restricted", "args": ["?x", "?y", "TR"]}],
                        "head": [{"predicate": "requires_safety_check", "args": ["?x", "?y", "true"]}],
                        "temporary": True,
                        "ttl": 10,
                    }},
                ],
                "confidence": 0.99,
                "rationale_code": "authenticated_event_translation",
            }
        )
        user = json.dumps({
            "instruction": (
                "Return exactly one JSON object matching output_schema. Use only the exact keys for each "
                "selected operation type; omit keys belonging to other operation types. Infer the event family "
                "only from event_text, then follow its event_fact_contract exactly. Coordinates, identifiers, "
                "penalties, roles, service times, and TTLs must be copied from event_text as typed strings except "
                "rule.ttl, which is an integer. Normalize a role through role_token_normalization even when the "
                "text contains both a descriptive word and an uppercase token. Do not convert a supersede_fact "
                "into insert_fact. " + profile_instruction
            ),
            "inference_profile": inference_profile,
            "event_text": text,
            "context": prompt_context,
            "event_fact_contracts": event_fact_contracts,
            "role_token_normalization": role_token_normalization,
            "restricted_rule_templates": restricted_rule_templates if inference_profile == RESTRICTED_RULE_PROFILE else None,
            "output_schema": schema,
            "profile_correct_example": output_example,
        }, ensure_ascii=False, sort_keys=True)
        body = {
            "model": self.model,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "response_format": {"type": "json_object"},
            "thinking": {"type": self.thinking_mode},
            "max_tokens": self.max_tokens,
            "stream": False,
        }
        if self.thinking_mode == "disabled":
            body["temperature"] = 0.0
        return body

    def _post(self, body: dict[str, Any], token: str) -> tuple[dict[str, Any], str]:
        from datetime import datetime, timezone

        request_utc = datetime.now(timezone.utc).isoformat()
        request = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_s) as response:
                return json.loads(response.read().decode("utf-8")), request_utc
        except urllib.error.HTTPError as exc:
            safe_body = exc.read(1000).decode("utf-8", errors="replace")
            raise GroundingError(f"HTTP {exc.code}: {safe_body}") from exc


def build_grounding_context(state: WarehouseState, event: DynamicEvent) -> dict[str, Any]:
    robot_id = event.payload.get("robot_id")
    cargo_id = event.payload.get("cargo_id")
    relevant_robot = None
    if robot_id in state.robots:
        robot = state.robots[robot_id]
        relevant_robot = {
            "robot_id": robot.robot_id, "role": robot.role.value,
            "capacity": robot.capacity, "platform_id": robot.platform_id, "zone_id": robot.zone_id,
        }
    relevant_cargo = None
    if cargo_id in state.cargos:
        cargo = state.cargos[cargo_id]
        relevant_cargo = {
            "cargo_id": cargo.cargo_id, "origin_id": cargo.origin_id,
            "destination_id": cargo.destination_id, "weight": cargo.weight,
            "mode": cargo.mode.value, "batch_id": cargo.batch_id,
            "coalition_size": cargo.coalition_size,
        }
    return {
        "scenario_id": state.scenario_id,
        "event_id": event.event_id,
        "event_type": event.event_type,
        "event_time": event.time,
        "warehouse": {
            "width": state.width, "height": state.height,
            "platform_ids": sorted(state.platforms),
            "destination_ids": sorted(state.destinations),
        },
        "entity_registry": {
            role.value: sorted(robot.robot_id for robot in state.robots.values() if robot.role is role)
            for role in RobotRole
        } | {"cargo": sorted(state.cargos)},
        "relevant_robot": relevant_robot,
        "relevant_cargo": relevant_cargo,
        "authenticated_payload": canonical_jsonable(event.payload),
        "ontology": {key: list(value) for key, value in sorted(VersionedKnowledgeBase().signatures.items())},
    }


def build_record_grounding_context(record: dict[str, Any]) -> dict[str, Any]:
    """Upgrade stored v1 contexts deterministically for the v2 prompt contract."""
    context = json.loads(json.dumps(record.get("grounding_context") or {}))
    context["scenario_id"] = record["scenario_id"]
    context["event_id"] = record["event_id"]
    context["event_type"] = record["event_type"]
    context["event_time"] = record["time"]
    context["authenticated_payload"] = canonical_jsonable(record["payload"])
    context.setdefault(
        "ontology",
        {key: list(value) for key, value in sorted(VersionedKnowledgeBase().signatures.items())},
    )
    return context


def validate_candidate(candidate: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(candidate, dict):
        raise GroundingError("Candidate must be a JSON object")
    required = {"schema_version", "operations", "confidence", "rationale_code"}
    if set(candidate) != required:
        raise GroundingError(f"Candidate keys must be exactly {sorted(required)}")
    if candidate["schema_version"] != PROMPT_SCHEMA_VERSION:
        raise GroundingError("Prompt schema version mismatch")
    if not isinstance(candidate["operations"], list) or not candidate["operations"]:
        raise GroundingError("operations must be a non-empty list")
    if not isinstance(candidate["confidence"], (int, float)) or not 0 <= candidate["confidence"] <= 1:
        raise GroundingError("confidence must be numeric and in [0,1]")
    if not isinstance(candidate["rationale_code"], str) or len(candidate["rationale_code"]) > 80:
        raise GroundingError("rationale_code must be a short string")
    kb = VersionedKnowledgeBase()
    normalized: list[dict[str, Any]] = []
    for operation in candidate["operations"]:
        if not isinstance(operation, dict) or operation.get("op") not in ALLOWED_OPERATIONS:
            raise GroundingError("Unsupported or malformed operation")
        op = operation["op"]
        if op == "insert_rule":
            if set(operation) != {"op", "rule"}:
                raise GroundingError("insert_rule accepts only op and rule")
            rule = Rule.from_dict(operation["rule"])
            kb.validate_rule(rule)
            normalized.append({"op": op, "rule": rule.to_dict()})
        else:
            allowed = {"op", "atom"} if op != "supersede_fact" else {"op", "atom", "key"}
            if set(operation) != allowed:
                raise GroundingError(f"{op} keys must be exactly {sorted(allowed)}")
            atom = Atom.from_dict(operation["atom"])
            kb.validate_atom(atom)
            item: dict[str, Any] = {"op": op, "atom": atom.to_dict()}
            if op == "supersede_fact":
                item["key"] = [str(value) for value in operation["key"]]
            normalized.append(item)
    return {
        "schema_version": PROMPT_SCHEMA_VERSION,
        "operations": normalized,
        "confidence": float(candidate["confidence"]),
        "rationale_code": candidate["rationale_code"],
    }


def gold_candidate(operations: list[dict[str, Any]]) -> dict[str, Any]:
    """Testing oracle; never used as a substitute for a missing DeepSeek response."""
    return validate_candidate({
        "schema_version": PROMPT_SCHEMA_VERSION,
        "operations": operations,
        "confidence": 1.0,
        "rationale_code": "gold_annotation",
    })


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=path.name, suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(payload, stream, ensure_ascii=False, sort_keys=True, indent=2)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _canonical_sha256(payload: Any) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _json_sha256(payload: dict[str, Any]) -> str:
    return _canonical_sha256(payload)


def _text_sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _package_source_digest() -> str:
    source_root = Path(__file__).resolve().parent
    digest = hashlib.sha256()
    for path in sorted(source_root.glob("*.py")):
        digest.update(path.name.encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def prefetch_main() -> None:
    parser = argparse.ArgumentParser(description="Resumably prefetch DeepSeek grounding responses")
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=Path("llm_track_v1_4/cache/deepseek_v4"))
    parser.add_argument("--model", default=os.environ.get("DEEPSEEK_MODEL", DEFAULT_MODEL))
    parser.add_argument("--base-url", default=os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com"))
    parser.add_argument("--split", choices=["development", "validation", "test"])
    parser.add_argument("--profiles", nargs="+", choices=sorted(ALLOWED_PROFILES), default=[FACTS_ONLY_PROFILE])
    parser.add_argument("--thinking-mode", choices=["enabled", "disabled"], default=DEFAULT_THINKING_MODE)
    parser.add_argument("--max-tokens", type=int, default=DEFAULT_MAX_TOKENS)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    records = [json.loads(line) for line in args.events.read_text(encoding="utf-8").splitlines() if line.strip()]
    if args.split:
        records = [record for record in records if record["split"] == args.split]
    if args.limit is not None:
        records = records[: args.limit]

    jobs: list[tuple[dict[str, Any], str]] = []
    for record in records:
        for profile in args.profiles:
            if profile == RESTRICTED_RULE_PROFILE and record["event_type"] not in RULE_EVENT_TYPES:
                continue
            jobs.append((record, profile))
    grounder = DeepSeekGrounder(
        args.cache,
        args.model,
        args.base_url,
        inference_profile=FACTS_ONLY_PROFILE,
        thinking_mode=args.thinking_mode,
        max_tokens=args.max_tokens,
    )
    print_lock = threading.Lock()

    def fetch(job: tuple[dict[str, Any], str]) -> dict[str, Any]:
        record, profile = job
        context = build_record_grounding_context(record)
        try:
            result = grounder.ground(
                record["text"], context, offline=False, inference_profile=profile,
            )
            return {
                "ok": True,
                "case_id": record["case_id"],
                "profile": profile,
                "cache_hit": result.cache_hit,
                "response_status": result.response_status,
                "validation_error": result.validation_error,
                "latency_ms": result.latency_ms,
                "api_latency_ms": result.api_latency_ms,
            }
        except GroundingError as exc:
            return {"ok": False, "case_id": record["case_id"], "profile": profile, "error": str(exc)}

    completed = 0
    failures = 0
    invalid_responses = 0
    workers = max(1, min(args.workers, 32))
    started = time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(fetch, job): index for index, job in enumerate(jobs, 1)}
        for future in concurrent.futures.as_completed(futures):
            index = futures[future]
            result = future.result()
            completed += int(result["ok"])
            failures += int(not result["ok"])
            invalid_responses += int(result.get("response_status") == "invalid")
            with print_lock:
                print(json.dumps({"finished": index, "total": len(jobs), **result}, ensure_ascii=False), flush=True)
    elapsed = time.perf_counter() - started
    print(json.dumps({
        "status": "complete" if completed == len(jobs) else "partial",
        "completed": completed,
        "failures": failures,
        "invalid_responses": invalid_responses,
        "total": len(jobs),
        "workers": workers,
        "elapsed_s": elapsed,
        "throughput_requests_per_s": completed / elapsed if elapsed else None,
    }, ensure_ascii=False))


if __name__ == "__main__":
    prefetch_main()
