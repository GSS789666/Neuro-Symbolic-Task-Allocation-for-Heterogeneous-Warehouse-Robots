from __future__ import annotations

import copy
import hashlib
import json
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable


class KnowledgeError(ValueError):
    pass


class VersionConflict(KnowledgeError):
    pass


@dataclass(frozen=True, order=True)
class Atom:
    predicate: str
    args: tuple[str, ...]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Atom":
        return cls(predicate=str(data["predicate"]), args=tuple(str(x) for x in data["args"]))

    def to_dict(self) -> dict[str, Any]:
        return {"predicate": self.predicate, "args": list(self.args)}


@dataclass(frozen=True)
class Rule:
    rule_id: str
    body: tuple[Atom, ...]
    head: tuple[Atom, ...]
    temporary: bool = False
    ttl: int | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Rule":
        return cls(
            rule_id=str(data["rule_id"]),
            body=tuple(Atom.from_dict(atom) for atom in data["body"]),
            head=tuple(Atom.from_dict(atom) for atom in data["head"]),
            temporary=bool(data.get("temporary", False)),
            ttl=int(data["ttl"]) if data.get("ttl") is not None else None,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "body": [atom.to_dict() for atom in self.body],
            "head": [atom.to_dict() for atom in self.head],
            "temporary": self.temporary,
            "ttl": self.ttl,
        }


@dataclass(frozen=True)
class FactMetadata:
    source: str
    confidence: float
    asserted_version: int
    transaction_id: str


@dataclass(frozen=True)
class ProofNode:
    atom: Atom
    version: int
    rule_id: str | None
    antecedents: tuple[Atom, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "atom": self.atom.to_dict(),
            "version": self.version,
            "rule_id": self.rule_id,
            "antecedents": [a.to_dict() for a in self.antecedents],
        }


@dataclass
class Snapshot:
    version: int
    asserted: set[Atom] = field(default_factory=set)
    rules: dict[str, Rule] = field(default_factory=dict)
    closure: set[Atom] = field(default_factory=set)
    proofs: dict[Atom, ProofNode] = field(default_factory=dict)
    metadata: dict[Atom, FactMetadata] = field(default_factory=dict)

    def digest(self) -> str:
        payload = {
            "asserted": [a.to_dict() for a in sorted(self.asserted)],
            "rules": [self.rules[k].to_dict() for k in sorted(self.rules)],
            "closure": [a.to_dict() for a in sorted(self.closure)],
        }
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class TransactionResult:
    transaction_id: str
    base_version: int
    version: int
    committed: bool
    applied_operations: int
    quarantined_rules: tuple[str, ...]
    snapshot_hash: str


DEFAULT_SIGNATURES: dict[str, tuple[str, ...]] = {
    "blocked_cell": ("int", "int", "bool"),
    "congestion": ("int", "int", "int"),
    "robot_status": ("robot", "status"),
    "surface_condition": ("int", "int", "surface"),
    "access_restricted": ("int", "int", "role"),
    "service_time": ("cargo", "int"),
    "cargo_cancelled": ("cargo", "bool"),
    "battery_reserve_low": ("robot", "bool"),
    "cargo_known": ("cargo", "bool"),
    "low_friction_cell": ("int", "int"),
    "route_penalty": ("int", "int", "int"),
    "robot_eligible": ("robot", "cargo", "bool"),
    "requires_safety_check": ("int", "int", "bool"),
}


FORBIDDEN_HEADS = {"motor_command", "path_clear", "erase_safety_constraint", "disable_collision_check"}
TEMPORARY_ALLOWED_HEADS = {"route_penalty", "robot_eligible", "requires_safety_check"}
# Multiple independent hazards may contribute route penalties at the same cell.
# They remain individually traceable in the closure and the routing layer uses
# their deterministic maximum.  All predicates below retain single-valued
# functional semantics.
AGGREGATED_PREDICATES = {"route_penalty": "max"}
FUNCTIONAL_PREDICATES = {
    "blocked_cell", "congestion", "robot_status", "surface_condition",
    "access_restricted", "service_time", "cargo_cancelled", "battery_reserve_low",
    "cargo_known",
    "robot_eligible", "requires_safety_check",
}


class VersionedKnowledgeBase:
    """Finite, monotonic-per-version production-rule engine with atomic transactions."""

    def __init__(self, signatures: dict[str, tuple[str, ...]] | None = None) -> None:
        self.signatures = dict(DEFAULT_SIGNATURES if signatures is None else signatures)
        initial = Snapshot(version=0)
        self._snapshots: dict[int, Snapshot] = {0: initial}
        self._active_version = 0
        self.transaction_log: list[dict[str, Any]] = []
        self.quarantine: list[dict[str, Any]] = []

    @property
    def version(self) -> int:
        return self._active_version

    @property
    def snapshot(self) -> Snapshot:
        return self._snapshots[self._active_version]

    def commit(
        self,
        transaction_id: str,
        base_version: int,
        operations: list[dict[str, Any]],
        source: str,
        confidence: float = 1.0,
    ) -> TransactionResult:
        if base_version != self._active_version:
            raise VersionConflict(f"base_version={base_version}, active_version={self._active_version}")
        if not 0.0 <= confidence <= 1.0:
            raise KnowledgeError("confidence must be in [0, 1]")
        working = copy.deepcopy(self.snapshot)
        next_version = self._active_version + 1
        working.version = next_version
        quarantined: list[str] = []
        inserted_rule_ids: list[str] = []
        applied = 0
        for operation in operations:
            op = operation.get("op")
            if op == "insert_fact":
                atom = Atom.from_dict(operation["atom"])
                self.validate_atom(atom)
                working.asserted.add(atom)
                working.metadata[atom] = FactMetadata(source, confidence, next_version, transaction_id)
                applied += 1
            elif op == "retract_fact":
                atom = Atom.from_dict(operation["atom"])
                self.validate_atom(atom)
                working.asserted.discard(atom)
                working.metadata.pop(atom, None)
                applied += 1
            elif op == "supersede_fact":
                atom = Atom.from_dict(operation["atom"])
                self.validate_atom(atom)
                key = tuple(str(x) for x in operation.get("key", []))
                if atom.args[: len(key)] != key:
                    raise KnowledgeError("supersede key must be a prefix of the replacement atom arguments")
                old = {a for a in working.asserted if a.predicate == atom.predicate and a.args[: len(key)] == key}
                working.asserted.difference_update(old)
                for prior in old:
                    working.metadata.pop(prior, None)
                working.asserted.add(atom)
                working.metadata[atom] = FactMetadata(source, confidence, next_version, transaction_id)
                applied += 1
            elif op == "insert_rule":
                rule = Rule.from_dict(operation["rule"])
                try:
                    self.validate_rule(rule, [*working.rules.values(), rule])
                except KnowledgeError as exc:
                    quarantined.append(rule.rule_id)
                    self.quarantine.append({
                        "transaction_id": transaction_id, "rule": rule.to_dict(), "reason": str(exc),
                    })
                    continue
                working.rules[rule.rule_id] = rule
                inserted_rule_ids.append(rule.rule_id)
                applied += 1
            elif op == "retract_rule":
                rule_id = str(operation["rule_id"])
                working.rules.pop(rule_id, None)
                applied += 1
            else:
                raise KnowledgeError(f"Unsupported operation: {op!r}")

        committed = applied > 0
        if committed:
            self._infer(working)
            conflicts = _functional_conflicts(working.closure)
            if conflicts and inserted_rule_ids:
                reason = f"Finite regression produced functional contradictions: {conflicts[:3]}"
                for rule_id in inserted_rule_ids:
                    working.rules.pop(rule_id, None)
                    quarantined.append(rule_id)
                    self.quarantine.append({"transaction_id": transaction_id, "rule_id": rule_id, "reason": reason})
                    applied -= 1
                self._infer(working)
                committed = applied > 0
            elif conflicts:
                raise KnowledgeError(f"Asserted facts contain functional contradictions: {conflicts[:3]}")
        if committed:
            self._snapshots[next_version] = working
            self._active_version = next_version
            digest = working.digest()
        else:
            next_version = self._active_version
            digest = self.snapshot.digest()
        record = {
            "transaction_id": transaction_id, "base_version": base_version,
            "version": next_version, "source": source, "confidence": confidence,
            "operations": operations, "applied_operations": applied,
            "quarantined_rules": quarantined, "committed": committed,
            "snapshot_hash": digest,
        }
        self.transaction_log.append(record)
        return TransactionResult(
            transaction_id, base_version, next_version, committed, applied,
            tuple(quarantined), digest,
        )

    def rollback(self, transaction_id: str, target_version: int, source: str = "administrator") -> TransactionResult:
        if target_version not in self._snapshots:
            raise KnowledgeError(f"Unknown target version {target_version}")
        base = self._active_version
        restored = copy.deepcopy(self._snapshots[target_version])
        restored.version = base + 1
        self._infer(restored)
        self._snapshots[restored.version] = restored
        self._active_version = restored.version
        result = TransactionResult(transaction_id, base, restored.version, True, 1, (), restored.digest())
        self.transaction_log.append({
            "transaction_id": transaction_id, "base_version": base, "version": restored.version,
            "source": source, "rollback_target": target_version, "committed": True,
            "snapshot_hash": restored.digest(),
        })
        return result

    def validate_atom(self, atom: Atom, allow_variables: bool = False) -> None:
        if atom.predicate not in self.signatures:
            raise KnowledgeError(f"Unknown predicate {atom.predicate}")
        signature = self.signatures[atom.predicate]
        if len(signature) != len(atom.args):
            raise KnowledgeError(f"Arity mismatch for {atom.predicate}: expected {len(signature)}")
        for value, type_name in zip(atom.args, signature):
            if allow_variables and value.startswith("?"):
                continue
            if not _value_matches(value, type_name):
                raise KnowledgeError(f"Value {value!r} is not of type {type_name} in {atom.predicate}")

    def validate_rule(self, rule: Rule, candidate_rules: Iterable[Rule] | None = None) -> None:
        if not rule.rule_id or not rule.body or not rule.head:
            raise KnowledgeError("A rule needs an id, a non-empty body, and a non-empty head")
        if rule.temporary:
            if rule.ttl is None or not 1 <= rule.ttl <= 3600:
                raise KnowledgeError("A temporary rule requires a TTL in [1,3600]")
            if any(atom.predicate not in TEMPORARY_ALLOWED_HEADS for atom in rule.head):
                raise KnowledgeError("A temporary rule head is outside the restricted policy surface")
        elif rule.ttl is not None:
            raise KnowledgeError("A permanent rule may not carry a TTL")
        body_variables = {arg for atom in rule.body for arg in atom.args if arg.startswith("?")}
        head_variables = {arg for atom in rule.head for arg in atom.args if arg.startswith("?")}
        if not head_variables.issubset(body_variables):
            raise KnowledgeError("Rule is not range restricted")
        variable_types: dict[str, str] = {}
        for atom in (*rule.body, *rule.head):
            self.validate_atom(atom, allow_variables=True)
            for value, type_name in zip(atom.args, self.signatures[atom.predicate]):
                if value.startswith("?"):
                    previous = variable_types.setdefault(value, type_name)
                    if previous != type_name:
                        raise KnowledgeError(f"Variable {value} has incompatible types {previous} and {type_name}")
        if any(atom.predicate in FORBIDDEN_HEADS for atom in rule.head):
            raise KnowledgeError("Rule head may weaken safety or issue direct actuator commands")
        for atom in rule.head:
            value = atom.args[-1]
            if atom.predicate == "robot_eligible" and value != "false":
                raise KnowledgeError("A temporary rule may remove eligibility but may not grant it")
            if atom.predicate == "requires_safety_check" and value != "true":
                raise KnowledgeError("A rule may require a safety check but may not disable one")
            if atom.predicate == "route_penalty":
                if value.startswith("?") or not value.lstrip("-").isdigit() or not 0 <= int(value) <= 100:
                    raise KnowledgeError("route_penalty heads require a constant integer in [0,100]")
        rules = list(candidate_rules if candidate_rules is not None else [*self.snapshot.rules.values(), rule])
        if _has_predicate_cycle(rules):
            raise KnowledgeError("Recursive/cyclic predicate dependency is outside the supported subset")

    def proof_dag(self, atom: Atom) -> dict[str, Any]:
        if atom not in self.snapshot.proofs:
            raise KnowledgeError(f"No proof for {atom}")
        seen: set[Atom] = set()

        def visit(current: Atom) -> dict[str, Any]:
            node = self.snapshot.proofs[current]
            if current in seen:
                return {**node.to_dict(), "cycle_reference": True}
            seen.add(current)
            return {**node.to_dict(), "children": [visit(a) for a in node.antecedents]}

        return visit(atom)

    def _infer(self, snapshot: Snapshot) -> None:
        snapshot.closure = set(snapshot.asserted)
        snapshot.proofs = {
            atom: ProofNode(atom=atom, version=snapshot.version, rule_id=None)
            for atom in snapshot.asserted
        }
        changed = True
        ordered_rules = [snapshot.rules[key] for key in sorted(snapshot.rules)]
        while changed:
            changed = False
            facts_by_predicate: dict[str, list[Atom]] = {}
            for fact in sorted(snapshot.closure):
                facts_by_predicate.setdefault(fact.predicate, []).append(fact)
            for rule in ordered_rules:
                for environment, antecedents in _match_rule(rule, facts_by_predicate):
                    for pattern in rule.head:
                        derived = Atom(pattern.predicate, tuple(environment.get(arg, arg) for arg in pattern.args))
                        self.validate_atom(derived)
                        if derived not in snapshot.closure:
                            snapshot.closure.add(derived)
                            snapshot.proofs[derived] = ProofNode(
                                atom=derived, version=snapshot.version,
                                rule_id=rule.rule_id, antecedents=tuple(antecedents),
                            )
                            changed = True


def _match_rule(rule: Rule, facts: dict[str, list[Atom]]) -> list[tuple[dict[str, str], list[Atom]]]:
    matches: list[tuple[dict[str, str], list[Atom]]] = []

    def recurse(index: int, environment: dict[str, str], antecedents: list[Atom]) -> None:
        if index == len(rule.body):
            matches.append((environment, antecedents))
            return
        pattern = rule.body[index]
        for fact in facts.get(pattern.predicate, []):
            extended = _unify(pattern, fact, environment)
            if extended is not None:
                recurse(index + 1, extended, [*antecedents, fact])

    recurse(0, {}, [])
    return matches


def _unify(pattern: Atom, fact: Atom, environment: dict[str, str]) -> dict[str, str] | None:
    if pattern.predicate != fact.predicate or len(pattern.args) != len(fact.args):
        return None
    result = dict(environment)
    for expected, actual in zip(pattern.args, fact.args):
        if expected.startswith("?"):
            if expected in result and result[expected] != actual:
                return None
            result[expected] = actual
        elif expected != actual:
            return None
    return result


def _has_predicate_cycle(rules: Iterable[Rule]) -> bool:
    graph: dict[str, set[str]] = {}
    for rule in rules:
        for body in rule.body:
            for head in rule.head:
                graph.setdefault(body.predicate, set()).add(head.predicate)
    visiting: set[str] = set()
    visited: set[str] = set()

    def dfs(node: str) -> bool:
        if node in visiting:
            return True
        if node in visited:
            return False
        visiting.add(node)
        if any(dfs(neighbor) for neighbor in graph.get(node, set())):
            return True
        visiting.remove(node)
        visited.add(node)
        return False

    return any(dfs(node) for node in list(graph))


def _value_matches(value: str, type_name: str) -> bool:
    if type_name == "int":
        try:
            int(value)
            return True
        except ValueError:
            return False
    if type_name == "float":
        try:
            float(value)
            return True
        except ValueError:
            return False
    if type_name == "bool":
        return value in {"true", "false"}
    if type_name == "robot":
        return value.startswith(("LR", "TR", "UR"))
    if type_name == "cargo":
        return value.startswith("C")
    if type_name == "role":
        return value in {"LR", "TR", "UR"}
    if type_name == "status":
        return value in {"idle", "to_origin", "loading", "in_transit", "unloading", "charging", "unavailable"}
    if type_name == "surface":
        return value in {"normal", "low_friction", "wet", "damaged"}
    return bool(value)


def _functional_conflicts(facts: Iterable[Atom]) -> list[str]:
    values: dict[tuple[str, tuple[str, ...]], set[str]] = {}
    for atom in facts:
        if atom.predicate not in FUNCTIONAL_PREDICATES or not atom.args:
            continue
        values.setdefault((atom.predicate, atom.args[:-1]), set()).add(atom.args[-1])
    return [f"{predicate}{key}={sorted(found)}" for (predicate, key), found in values.items() if len(found) > 1]
