from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from .grounding import (
    DEFAULT_MODEL,
    DEFAULT_THINKING_MODE,
    PROMPT_SCHEMA_VERSION,
    CacheMiss,
    DeepSeekGrounder,
    GroundingError,
    build_record_grounding_context,
    validate_candidate,
)
from .knowledge import KnowledgeError, VersionedKnowledgeBase
from .shield import (
    ALLOWED_PROFILES,
    FACTS_ONLY_PROFILE,
    RESTRICTED_RULE_PROFILE,
    RULE_EVENT_TYPES,
    AuthenticatedWriteShield,
    canonical_operations,
    compile_authenticated_facts,
    compile_expected_operations,
)


# Compatibility alias for the versioned simulator package.
compile_authenticated_payload = compile_authenticated_facts


def evaluate_events(
    events_path: Path,
    source: str,
    cache_dir: Path | None = None,
    model: str = DEFAULT_MODEL,
    split: str | None = None,
    limit: int | None = None,
    profile: str = FACTS_ONLY_PROFILE,
    thinking_mode: str = DEFAULT_THINKING_MODE,
    event_type: str | None = None,
    sealed_manifest_path: Path | None = None,
) -> dict[str, Any]:
    if profile not in ALLOWED_PROFILES:
        raise ValueError(f"Unknown profile {profile!r}")
    records = [json.loads(line) for line in events_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if split:
        records = [record for record in records if record["split"] == split]
    if event_type:
        records = [record for record in records if record["event_type"] == event_type]
    if limit is not None:
        records = records[:limit]
    if profile == RESTRICTED_RULE_PROFILE:
        records = [record for record in records if record["event_type"] in RULE_EVENT_TYPES]

    grounder = None
    if source == "deepseek_cache":
        grounder = DeepSeekGrounder(
            cache_dir or Path("llm_track_v1_4/cache/deepseek_v4"),
            model=model,
            thinking_mode=thinking_mode,
            sealed_manifest_path=sealed_manifest_path,
        )
    shield = AuthenticatedWriteShield()
    counts: Counter[str] = Counter()
    operation_counts: Counter[str] = Counter()
    predicate_counts: Counter[str] = Counter()
    per_event_counts: dict[str, Counter[str]] = defaultdict(Counter)
    errors: list[dict[str, str]] = []
    case_results: list[dict[str, Any]] = []

    for record in records:
        event_counts = per_event_counts[record["event_type"]]
        counts["total"] += 1
        event_counts["total"] += 1
        if profile == RESTRICTED_RULE_PROFILE:
            counts["rule_profile_total"] += 1
            event_counts["rule_profile_total"] += 1
        expected = compile_expected_operations(
            record["event_type"], record["payload"], record["event_id"], profile,
        )
        if profile == FACTS_ONLY_PROFILE and canonical_operations(expected) != canonical_operations(record["gold_operations"]):
            raise AssertionError(f"Gold annotation disagrees with authenticated payload in {record['case_id']}")

        candidate: dict[str, Any] | None = None
        response_status = "dataset_candidate"
        cache_hit = False
        api_latency_ms: float | None = None
        validation_error: str | None = None
        if source == "dataset_candidates":
            raw_candidate = {
                "schema_version": PROMPT_SCHEMA_VERSION,
                "operations": record["candidate_operations"] if profile == FACTS_ONLY_PROFILE else expected,
                "confidence": 1.0,
                "rationale_code": "generated_adversarial_candidate",
            }
            try:
                candidate = validate_candidate(raw_candidate)
            except (GroundingError, KnowledgeError) as exc:
                validation_error = f"{type(exc).__name__}:{exc}"
        elif source == "deepseek_cache":
            context = build_record_grounding_context(record)
            try:
                result = grounder.ground(  # type: ignore[union-attr]
                    record["text"], context, offline=True, inference_profile=profile,
                )
                cache_hit = result.cache_hit
                response_status = result.response_status
                validation_error = result.validation_error
                candidate = result.candidate
                api_latency_ms = result.api_latency_ms
                counts["cache_hits"] += 1
                event_counts["cache_hits"] += 1
            except (GroundingError, CacheMiss) as exc:
                validation_error = f"{type(exc).__name__}:{exc}"
                counts["cache_or_grounding_error"] += 1
                event_counts["cache_or_grounding_error"] += 1
        else:
            raise ValueError("source must be dataset_candidates or deepseek_cache")

        semantic_correct = False
        shield_accept = False
        rule_template_correct = False
        rule_operation_exact = False
        reason_code = "not_schema_valid"
        proposed_operations: list[dict[str, Any]] = []
        if candidate is not None:
            counts["schema_valid"] += 1
            event_counts["schema_valid"] += 1
            proposed_operations = candidate["operations"]
            try:
                kb = VersionedKnowledgeBase()
                tx = kb.commit("evaluation", 0, proposed_operations, "candidate", candidate["confidence"])
                if tx.committed and not tx.quarantined_rules:
                    counts["logic_valid"] += 1
                    event_counts["logic_valid"] += 1
            except Exception as exc:
                validation_error = f"{type(exc).__name__}:{exc}"
            semantic_correct = canonical_operations(proposed_operations) == canonical_operations(expected)
            if profile == RESTRICTED_RULE_PROFILE:
                predicted_rules = [item for item in proposed_operations if item.get("op") == "insert_rule"]
                expected_rule = next(item for item in expected if item.get("op") == "insert_rule")
                if len(predicted_rules) == 1:
                    rule_template_correct = _rule_template_token(predicted_rules[0]) == _rule_template_token(expected_rule)
                    rule_operation_exact = _canonical_item(predicted_rules[0]) == _canonical_item(expected_rule)
                    counts["rule_template_correct"] += int(rule_template_correct)
                    counts["rule_operation_exact"] += int(rule_operation_exact)
                    event_counts["rule_template_correct"] += int(rule_template_correct)
                    event_counts["rule_operation_exact"] += int(rule_operation_exact)
            decision = shield.assess(
                candidate,
                event_type=record["event_type"],
                payload=record["payload"],
                event_id=record["event_id"],
                profile=profile,
            )
            shield_accept = decision.accepted
            reason_code = decision.reason_code
            counts["shield_accepted"] += int(shield_accept)
            event_counts["shield_accepted"] += int(shield_accept)
            if semantic_correct:
                counts["semantic_exact"] += 1
                event_counts["semantic_exact"] += 1
                counts["correct_rejected"] += int(not shield_accept)
                event_counts["correct_rejected"] += int(not shield_accept)
            else:
                counts["unsafe_proposed"] += 1
                event_counts["unsafe_proposed"] += 1
                counts["unsafe_accepted"] += int(shield_accept)
                event_counts["unsafe_accepted"] += int(shield_accept)
            _update_micro_counts(operation_counts, predicate_counts, proposed_operations, expected)

        if validation_error:
            errors.append({"case_id": record["case_id"], "error": validation_error})
        if response_status == "invalid":
            counts["invalid_response"] += 1
            event_counts["invalid_response"] += 1
        counts["shield_rejected"] += int(not shield_accept)
        event_counts["shield_rejected"] += int(not shield_accept)
        case_results.append({
            "case_id": record["case_id"],
            "scenario_id": record["scenario_id"],
            "map_family": record.get("map_family"),
            "event_type": record["event_type"],
            "profile": profile,
            "dataset_candidate_label": "valid" if record.get("valid") else "harmful",
            "cache_hit": cache_hit,
            "api_latency_ms": api_latency_ms,
            "response_status": response_status,
            "response_invalid": response_status == "invalid",
            "schema_valid": candidate is not None,
            "semantic_exact": semantic_correct,
            "rule_template_correct": rule_template_correct if profile == RESTRICTED_RULE_PROFILE else None,
            "rule_operation_exact": rule_operation_exact if profile == RESTRICTED_RULE_PROFILE else None,
            "shield_accept": shield_accept,
            "shield_reason": reason_code,
            "validation_error": validation_error,
        })

    return {
        "protocol_version": "grounding-evaluation-2.0",
        "provenance": "measured_deepseek_cache" if source == "deepseek_cache" else "simulated_generated_candidates",
        "source": source,
        "model": model if source == "deepseek_cache" else None,
        "thinking_mode": thinking_mode if source == "deepseek_cache" else None,
        "prompt_schema_version": PROMPT_SCHEMA_VERSION,
        "profile": profile,
        "split": split,
        "event_type_filter": event_type,
        "event_file": str(events_path),
        "event_file_sha256": hashlib.sha256(events_path.read_bytes()).hexdigest(),
        "case_ids_sha256": hashlib.sha256(
            "\n".join(sorted(record["case_id"] for record in records)).encode("utf-8")
        ).hexdigest(),
        "counts": dict(counts),
        "syntactic_validity": _ratio(counts["schema_valid"], counts["total"]),
        "logical_consistency": _ratio(counts["logic_valid"], counts["total"]),
        "semantic_exact_match": _ratio(counts["semantic_exact"], counts["total"]),
        "operation_micro_precision": _ratio(operation_counts["tp"], operation_counts["predicted"]),
        "operation_micro_recall": _ratio(operation_counts["tp"], operation_counts["gold"]),
        "operation_micro_f1": _f1(operation_counts["tp"], operation_counts["predicted"], operation_counts["gold"]),
        "predicate_micro_precision": _ratio(predicate_counts["tp"], predicate_counts["predicted"]),
        "predicate_micro_recall": _ratio(predicate_counts["tp"], predicate_counts["gold"]),
        "predicate_micro_f1": _f1(predicate_counts["tp"], predicate_counts["predicted"], predicate_counts["gold"]),
        "invalid_response_rate": _ratio(counts["invalid_response"], counts["total"]),
        "proposal_error_rate": _ratio(counts["total"] - counts["semantic_exact"], counts["total"]),
        "shield_rejection_rate": _ratio(counts["shield_rejected"], counts["total"]),
        "accepted_availability_rate": _ratio(counts["shield_accepted"], counts["total"]),
        "rule_template_selection_accuracy": _ratio(counts["rule_template_correct"], counts["rule_profile_total"]),
        "rule_operation_exact_match": _ratio(counts["rule_operation_exact"], counts["rule_profile_total"]),
        "software_invariants": {
            "post_shield_incorrect_commit_count": counts["unsafe_accepted"],
            "correct_proposal_rejected_count": counts["correct_rejected"],
            "interpretation": "deterministic contract checks; not empirical neural-safety metrics",
        },
        "per_event_type": {
            key: {
                "total": value["total"],
                "syntactic_validity": _ratio(value["schema_valid"], value["total"]),
                "semantic_exact_match": _ratio(value["semantic_exact"], value["total"]),
                "shield_accept_rate": _ratio(value["shield_accepted"], value["total"]),
                "invalid_response_rate": _ratio(value["invalid_response"], value["total"]),
                "proposal_error_rate": _ratio(value["total"] - value["semantic_exact"], value["total"]),
                "shield_rejection_rate": _ratio(value["shield_rejected"], value["total"]),
                "accepted_availability_rate": _ratio(value["shield_accepted"], value["total"]),
                "rule_template_selection_accuracy": _ratio(value["rule_template_correct"], value["rule_profile_total"]),
                "rule_operation_exact_match": _ratio(value["rule_operation_exact"], value["rule_profile_total"]),
            }
            for key, value in sorted(per_event_counts.items())
        },
        "errors": errors[:100],
        "case_results": case_results,
    }


def _update_micro_counts(
    operation_counts: Counter[str],
    predicate_counts: Counter[str],
    predicted: list[dict[str, Any]],
    gold: list[dict[str, Any]],
) -> None:
    predicted_operations = Counter(_canonical_item(item) for item in predicted)
    gold_operations = Counter(_canonical_item(item) for item in gold)
    operation_counts["tp"] += sum((predicted_operations & gold_operations).values())
    operation_counts["predicted"] += sum(predicted_operations.values())
    operation_counts["gold"] += sum(gold_operations.values())
    predicted_predicates = Counter(_predicate_token(item) for item in predicted)
    gold_predicates = Counter(_predicate_token(item) for item in gold)
    predicate_counts["tp"] += sum((predicted_predicates & gold_predicates).values())
    predicate_counts["predicted"] += sum(predicted_predicates.values())
    predicate_counts["gold"] += sum(gold_predicates.values())


def _canonical_item(item: dict[str, Any]) -> str:
    return json.dumps(item, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _predicate_token(operation: dict[str, Any]) -> str:
    if operation.get("op") == "insert_rule":
        rule = operation.get("rule", {})
        heads = ",".join(sorted(atom.get("predicate", "") for atom in rule.get("head", [])))
        return f"insert_rule:{heads}"
    atom = operation.get("atom", {})
    return f"{operation.get('op')}:{atom.get('predicate', '')}"


def _rule_template_token(operation: dict[str, Any]) -> str:
    rule = operation.get("rule", {})
    payload = {
        "body_predicates": [atom.get("predicate") for atom in rule.get("body", [])],
        "head_predicates": [atom.get("predicate") for atom in rule.get("head", [])],
        "temporary": rule.get("temporary"),
    }
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def _ratio(numerator: int, denominator: int) -> float | None:
    return numerator / denominator if denominator else None


def _f1(true_positive: int, predicted: int, gold: int) -> float | None:
    precision = _ratio(true_positive, predicted)
    recall = _ratio(true_positive, gold)
    if precision is None or recall is None or precision + recall == 0:
        return None
    return 2 * precision * recall / (precision + recall)


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate DeepSeek grounding and the authenticated write shield")
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--source", choices=["dataset_candidates", "deepseek_cache"], required=True)
    parser.add_argument("--cache", type=Path, default=Path("llm_track_v1_4/cache/deepseek_v4"))
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--thinking-mode", choices=["enabled", "disabled"], default=DEFAULT_THINKING_MODE)
    parser.add_argument("--profile", choices=sorted(ALLOWED_PROFILES), default=FACTS_ONLY_PROFILE)
    parser.add_argument("--split", choices=["development", "validation", "test"])
    parser.add_argument("--event-type")
    parser.add_argument("--sealed-manifest", type=Path)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = evaluate_events(
        args.events, args.source, args.cache, args.model, args.split, args.limit,
        args.profile, args.thinking_mode, args.event_type, args.sealed_manifest,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "status": "ok",
        "output": str(args.output),
        "events": result["counts"].get("total", 0),
        "semantic_exact_match": result["semantic_exact_match"],
        "invalid_response_rate": result["invalid_response_rate"],
        "accepted_availability_rate": result["accepted_availability_rate"],
    }, indent=2))


if __name__ == "__main__":
    main()
