from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any


FACTS_ONLY_PROFILE = "facts_only"
RESTRICTED_RULE_PROFILE = "restricted_rule"
RULE_EVENT_TYPES = {"moving_congestion", "robot_unavailable", "low_friction", "access_restriction"}
ALLOWED_PROFILES = {FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE}


@dataclass(frozen=True)
class ShieldDecision:
    accepted: bool
    reason_code: str
    expected_operations: tuple[dict[str, Any], ...]


def compile_authenticated_facts(event_type: str, payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Compile the trusted structured sensor/WMS payload without using model output."""
    if event_type == "blocked_cell":
        x, y = payload["point"]
        return [{"op": "insert_fact", "atom": {"predicate": "blocked_cell", "args": [str(x), str(y), "true"]}}]
    if event_type == "moving_congestion":
        x, y = payload["point"]
        return [{
            "op": "supersede_fact",
            "key": [str(x), str(y)],
            "atom": {"predicate": "congestion", "args": [str(x), str(y), str(payload["penalty"])]},
        }]
    if event_type == "robot_unavailable":
        robot_id = str(payload["robot_id"])
        return [{
            "op": "supersede_fact",
            "key": [robot_id],
            "atom": {"predicate": "robot_status", "args": [robot_id, "unavailable"]},
        }]
    if event_type == "low_friction":
        x, y = payload["point"]
        return [{
            "op": "insert_fact",
            "atom": {"predicate": "surface_condition", "args": [str(x), str(y), "low_friction"]},
        }]
    if event_type == "access_restriction":
        x, y = payload["point"]
        return [{
            "op": "insert_fact",
            "atom": {"predicate": "access_restricted", "args": [str(x), str(y), str(payload["role"])]},
        }]
    if event_type == "service_time":
        cargo_id = str(payload["cargo_id"])
        return [{
            "op": "supersede_fact",
            "key": [cargo_id],
            "atom": {"predicate": "service_time", "args": [cargo_id, str(payload["service_time"])]},
        }]
    if event_type == "cargo_cancelled":
        cargo_id = str(payload["cargo_id"])
        return [{
            "op": "insert_fact",
            "atom": {"predicate": "cargo_cancelled", "args": [cargo_id, "true"]},
        }]
    raise ValueError(f"Unknown event type {event_type!r}")


def compile_expected_operations(
    event_type: str,
    payload: dict[str, Any],
    event_id: str,
    profile: str,
) -> list[dict[str, Any]]:
    if profile not in ALLOWED_PROFILES:
        raise ValueError(f"Unknown grounding profile {profile!r}")
    operations = compile_authenticated_facts(event_type, payload)
    if profile == RESTRICTED_RULE_PROFILE:
        if event_type not in RULE_EVENT_TYPES:
            raise ValueError(f"The restricted-rule profile is not defined for {event_type!r}")
        if event_type == "low_friction":
            body = [{"predicate": "surface_condition", "args": ["?x", "?y", "low_friction"]}]
            head = [{"predicate": "route_penalty", "args": ["?x", "?y", "9"]}]
        elif event_type == "moving_congestion":
            body = [{"predicate": "congestion", "args": ["?x", "?y", "?level"]}]
            head = [{"predicate": "route_penalty", "args": ["?x", "?y", str(payload["penalty"])]}]
        elif event_type == "robot_unavailable":
            body = [
                {"predicate": "robot_status", "args": ["?robot", "unavailable"]},
                {"predicate": "cargo_known", "args": ["?cargo", "true"]},
            ]
            head = [{"predicate": "robot_eligible", "args": ["?robot", "?cargo", "false"]}]
        else:
            body = [{"predicate": "access_restricted", "args": ["?x", "?y", str(payload["role"])]}]
            head = [{"predicate": "requires_safety_check", "args": ["?x", "?y", "true"]}]
        operations.append({
            "op": "insert_rule",
            "rule": {
                "rule_id": f"temporary_{event_type}_policy_{event_id}",
                "body": body,
                "head": head,
                "temporary": True,
                "ttl": int(payload["ttl"]),
            },
        })
    return operations


class AuthenticatedWriteShield:
    """Fail-closed transaction contract bound to authenticated event fields.

    The model may propose a transaction, but it cannot change the trusted event
    identity, coordinates, entity identifiers, values, rule scope, TTL, or
    route-penalty policy.  The shield therefore measures interface safety; it
    is not treated as an independent semantic oracle.
    """

    def assess(
        self,
        candidate: dict[str, Any],
        *,
        event_type: str,
        payload: dict[str, Any],
        event_id: str,
        profile: str,
    ) -> ShieldDecision:
        try:
            expected = compile_expected_operations(event_type, payload, event_id, profile)
        except (KeyError, TypeError, ValueError) as exc:
            return ShieldDecision(False, f"invalid_authenticated_payload:{type(exc).__name__}", ())
        proposed = candidate.get("operations")
        if not isinstance(proposed, list):
            return ShieldDecision(False, "missing_operations", tuple(expected))
        if canonical_operations(proposed) != canonical_operations(expected):
            return ShieldDecision(False, "authenticated_contract_mismatch", tuple(expected))
        return ShieldDecision(True, "accepted", tuple(expected))


def canonical_operations(operations: list[dict[str, Any]] | tuple[dict[str, Any], ...]) -> str:
    canonical_items = sorted(
        json.dumps(item, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        for item in operations
    )
    return json.dumps(canonical_items, ensure_ascii=False, separators=(",", ":"))
