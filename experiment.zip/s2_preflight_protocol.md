# S2 Preflight Protocol

## Purpose and evidence boundary

This is a simulated engineering-only preflight of the S2 scale. It tests whether the Pilot v2.2 implementation, audit contract, and one-second decision budget remain viable at the intended Main scale. It is not confirmatory evidence and cannot support article performance claims.

## Frozen task matrix

- scale: S2;
- layouts: seed 2301 (validation) and seed 2302 (development);
- traces: one per layout;
- loads: 0.35, 0.60, 0.80, and 0.95;
- disturbances: low, medium, and high;
- methods: greedy, static CP-SAT, static Mivar-inspired CP-SAT, dynamic-fact CP-SAT, and dynamic-rule CP-SAT;
- horizon: 2,400 ticks;
- total: 2 layouts x 1 trace x 4 loads x 3 disturbances x 5 methods = 120 tasks.

The Main test seeds and DeepSeek caches remain unopened.

## Gates

All Pilot v2.2 audit equality, hash, schema, safety, structural-feasibility, terminal-pending, method-attribution, proof, timeout, and latency thresholds remain unchanged. The only preflight-specific threshold is at least 1,000 nonempty Stage-A calls per non-greedy method and at least 1,000 raw Stage-B attempts per method. Preflight p95/p99 values are descriptive engineering tails. Main retains the stronger frozen requirement of at least 2,000 independent decision samples per reported scale/method cell.

## Decision rule

Passing author-agent-reviewer review authorizes freezing the confirmatory estimands, non-inferiority margins, independent layout-seed unit, multiplicity correction, and immutable Main configuration. It does not itself authorize opening Main results until that statistical protocol is written and reviewed.
