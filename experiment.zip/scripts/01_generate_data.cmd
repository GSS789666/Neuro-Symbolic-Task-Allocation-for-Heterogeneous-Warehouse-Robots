@echo off
setlocal
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo Run scripts\00_setup.cmd first.
  exit /b 1
)
set "PYTHONPATH=%CD%"
".venv\Scripts\python.exe" -m mrta.scenario --output data\generated --scales S0 S1 S2 --seed-start 1001 --seed-count 120 --horizon 1200
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m mrta.validation data --data data\generated --minimum-harmful 500 --minimum-valid 500 --output data\generated\validation_report.json
if errorlevel 1 exit /b 1
endlocal
