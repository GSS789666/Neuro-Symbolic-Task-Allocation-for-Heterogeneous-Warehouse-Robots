@echo off
setlocal
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo Run scripts\00_setup.cmd first.
  exit /b 1
)
set "PYTHONPATH=%CD%"
".venv\Scripts\python.exe" -m pytest -q
if errorlevel 1 exit /b 1
if not exist "data\generated_v2\manifest.json" call scripts\01_generate_data_v2.cmd
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m mrta.validation data --data data\generated_v2 --minimum-harmful 500 --minimum-valid 500 --output data\generated_v2\validation_report.json
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m mrta.semantic --events data\generated_v2\events.jsonl --source dataset_candidates --split validation --output runs\development_v2_semantic_shield.json
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m mrta.experiment --config configs\dev_v2.json --output runs
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m mrta.validation run --run runs\development_v2_smoke --output runs\development_v2_smoke\validation_report.json
endlocal
