@echo off
setlocal
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo Run scripts\00_setup.cmd first.
  exit /b 1
)
if "%DEEPSEEK_API_KEY%"=="" (
  echo Set DEEPSEEK_API_KEY in this CMD window before running this script.
  exit /b 1
)
set "PYTHONPATH=%CD%"
if "%DEEPSEEK_MODEL%"=="" set "DEEPSEEK_MODEL=deepseek-chat"
".venv\Scripts\python.exe" -m mrta.grounding --events data\generated\events.jsonl --cache data\deepseek_cache --model "%DEEPSEEK_MODEL%" %*
endlocal

