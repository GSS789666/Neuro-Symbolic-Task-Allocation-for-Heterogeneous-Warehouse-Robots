@echo off
setlocal
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo Run scripts\00_setup.cmd first.
  exit /b 1
)
set "PYTHONPATH=%CD%"
if "%DEEPSEEK_MODEL%"=="" set "DEEPSEEK_MODEL=deepseek-chat"
".venv\Scripts\python.exe" -m mrta.semantic --events data\generated\events.jsonl --source deepseek_cache --cache data\deepseek_cache --model "%DEEPSEEK_MODEL%" --split validation --output runs\deepseek_validation_metrics.json
endlocal

