@echo off
setlocal
cd /d "%~dp0.."
set "PYTHONPATH=%CD%"
".venv\Scripts\python.exe" -m mrta.export_events --config configs\end_to_end.json --output data\e2e_events.jsonl
endlocal

