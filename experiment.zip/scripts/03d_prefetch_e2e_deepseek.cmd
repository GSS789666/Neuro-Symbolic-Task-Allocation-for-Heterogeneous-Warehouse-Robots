@echo off
setlocal
cd /d "%~dp0.."
if "%DEEPSEEK_API_KEY%"=="" (
  echo Set DEEPSEEK_API_KEY in this CMD window before running this script.
  exit /b 1
)
set "PYTHONPATH=%CD%"
if "%DEEPSEEK_MODEL%"=="" set "DEEPSEEK_MODEL=deepseek-chat"
".venv\Scripts\python.exe" -m mrta.grounding --events data\e2e_events.jsonl --cache data\e2e_deepseek_cache --model "%DEEPSEEK_MODEL%" %*
endlocal

