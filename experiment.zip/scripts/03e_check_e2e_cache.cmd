@echo off
setlocal
cd /d "%~dp0.."
set "PYTHONPATH=%CD%"
if "%DEEPSEEK_MODEL%"=="" set "DEEPSEEK_MODEL=deepseek-chat"
".venv\Scripts\python.exe" -m mrta.cache_audit --events data\e2e_events.jsonl --cache data\e2e_deepseek_cache --model "%DEEPSEEK_MODEL%"
endlocal

