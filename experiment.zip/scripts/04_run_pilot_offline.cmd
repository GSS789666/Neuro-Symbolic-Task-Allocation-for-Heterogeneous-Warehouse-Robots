@echo off
setlocal
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo Run scripts\00_setup.cmd first.
  exit /b 1
)
set "PYTHONPATH=%CD%"
".venv\Scripts\python.exe" -m mrta.experiment --config configs\pilot.json --output runs
endlocal

