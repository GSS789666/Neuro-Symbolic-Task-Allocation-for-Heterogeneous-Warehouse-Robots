@echo off
setlocal
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo Run scripts\00_setup.cmd first.
  exit /b 1
)
set "PYTHONPATH=%CD%"
echo [1/3] Running the Pilot v2.2 regression and audit-integrity tests...
".venv\Scripts\python.exe" -m pytest -q
if errorlevel 1 exit /b 1
echo [2/3] Running 1,200 resumable offline Pilot v2.2 tasks...
".venv\Scripts\python.exe" -m mrta.experiment --config configs\pilot_v2_2.json --output runs
if errorlevel 1 exit /b 1
echo [3/3] Applying strict audit, terminal, attribution, and one-second latency gates...
".venv\Scripts\python.exe" -m mrta.validation run --run runs\pilot_v2_2_development_validation --strict-engineering --minimum-tail-sample 1500 --output runs\pilot_v2_2_development_validation\validation_report.json
if errorlevel 1 exit /b 1
echo Pilot v2.2 completed and passed every automatic engineering and audit-integrity gate.
endlocal
