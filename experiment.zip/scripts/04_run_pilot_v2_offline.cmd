@echo off
setlocal
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo Run scripts\00_setup.cmd first.
  exit /b 1
)
set "PYTHONPATH=%CD%"
".venv\Scripts\python.exe" -m mrta.experiment --config configs\pilot_v2.json --output runs
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m mrta.validation run --run runs\pilot_v2_development_validation --require-tail-sample --output runs\pilot_v2_development_validation\validation_report.json
if errorlevel 1 exit /b 1
echo Pilot v2 completed and passed automatic validation.
endlocal
