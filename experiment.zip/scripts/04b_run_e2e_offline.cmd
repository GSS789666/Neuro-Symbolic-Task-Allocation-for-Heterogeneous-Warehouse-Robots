@echo off
setlocal
cd /d "%~dp0.."
set "PYTHONPATH=%CD%"
if "%DEEPSEEK_MODEL%"=="" set "DEEPSEEK_MODEL=deepseek-chat"
call scripts\03e_check_e2e_cache.cmd
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m mrta.experiment --config configs\end_to_end.json --output runs
endlocal
