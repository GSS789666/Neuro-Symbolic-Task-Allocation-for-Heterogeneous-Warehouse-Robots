@echo off
setlocal
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo Run scripts\00_setup.cmd first.
  exit /b 1
)
set "PYTHONPATH=%CD%"
echo [1/3] Running regression and audit-integrity tests...
".venv\Scripts\python.exe" -m pytest -q
if errorlevel 1 exit /b 1
echo [2/3] Running 120 resumable offline S2 preflight tasks...
".venv\Scripts\python.exe" -m mrta.experiment --config configs\s2_preflight.json --output runs
if errorlevel 1 exit /b 1
echo [3/3] Applying strict preflight integrity and engineering gates...
".venv\Scripts\python.exe" -m mrta.validation run --run runs\s2_preflight_development_validation --strict-engineering --minimum-tail-sample 1000 --output runs\s2_preflight_development_validation\validation_report.json
if errorlevel 1 exit /b 1
echo S2 preflight completed and passed every automatic integrity and engineering gate.
endlocal
