@echo off
setlocal
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo Run scripts\00_setup.cmd first.
  exit /b 1
)
set "PYTHONPATH=%CD%"
echo [1/5] Running the frozen regression suite...
".venv\Scripts\python.exe" -m pytest -q
if errorlevel 1 exit /b 1
echo [2/5] Creating or verifying the immutable pre-Main freeze...
".venv\Scripts\python.exe" -m mrta.confirmatory freeze --config configs\main.json --protocol confirmatory_protocol.json --output main_freeze_manifest.json
if errorlevel 1 exit /b 1
echo [3/5] Running 1,800 resumable held-out Main tasks...
".venv\Scripts\python.exe" -m mrta.experiment --config configs\main.json --output runs
if errorlevel 1 exit /b 1
echo [4/5] Applying frozen integrity and engineering gates...
".venv\Scripts\python.exe" -m mrta.validation run --run runs\main_confirmatory_v1 --strict-engineering --minimum-tail-sample 2000 --output runs\main_confirmatory_v1\validation_report.json
if errorlevel 1 exit /b 1
echo [5/5] Running the frozen layout-seed confirmatory analysis...
".venv\Scripts\python.exe" -m mrta.confirmatory analyze --run runs\main_confirmatory_v1 --freeze main_freeze_manifest.json --protocol confirmatory_protocol.json --output runs\main_confirmatory_v1\confirmatory_analysis.json
if errorlevel 1 exit /b 1
echo Main completed, passed engineering gates, and produced the prespecified confirmatory analysis.
endlocal
