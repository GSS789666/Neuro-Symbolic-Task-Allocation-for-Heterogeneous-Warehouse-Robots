@echo off
setlocal
cd /d "%~dp0.."
if "%~1"=="" (
  echo Usage: scripts\06_check_results.cmd runs\pilot_development_validation
  exit /b 2
)
set "PYTHONPATH=%CD%"
".venv\Scripts\python.exe" -m mrta.validation run --run "%~1" --output "%~1\validation_report.json"
endlocal

