@echo off
setlocal
cd /d "%~dp0.."
set "PYTHONPATH=%CD%"
".venv\Scripts\python.exe" -m mrta.validation run --run runs\pilot_v2_2_development_validation --strict-engineering --minimum-tail-sample 1500 --output runs\pilot_v2_2_development_validation\validation_report.json
endlocal
