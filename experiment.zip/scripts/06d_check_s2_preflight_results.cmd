@echo off
setlocal
cd /d "%~dp0.."
set "PYTHONPATH=%CD%"
".venv\Scripts\python.exe" -m mrta.validation run --run runs\s2_preflight_development_validation --strict-engineering --minimum-tail-sample 1000 --output runs\s2_preflight_development_validation\validation_report.json
endlocal
