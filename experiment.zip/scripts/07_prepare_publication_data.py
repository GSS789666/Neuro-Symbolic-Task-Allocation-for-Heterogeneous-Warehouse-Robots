from __future__ import annotations

import csv
import gzip
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
RUN_DIR = ROOT / "runs" / "main_confirmatory_v1"
ANALYSIS_DIR = ROOT / "analysis"


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise RuntimeError(f"Refusing to write an empty table: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def verify_frozen_inputs() -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    freeze = read_json(ROOT / "main_freeze_manifest.json")
    manifest = read_json(RUN_DIR / "run_manifest.json")
    protocol = read_json(ROOT / "confirmatory_protocol.json")
    checks = {
        "freeze binding": file_sha256(ROOT / "main_freeze_manifest.json")
        == manifest["freeze_manifest_sha256"],
        "result binding": file_sha256(RUN_DIR / "episode_results.jsonl")
        == manifest["results_sha256"],
        "configuration binding": file_sha256(ROOT / "configs" / "main.json")
        == freeze["config_sha256"]
        == manifest["config_sha256"],
        "protocol binding": file_sha256(ROOT / "confirmatory_protocol.json")
        == freeze["protocol_sha256"],
        "source binding": freeze["source_sha256"] == manifest["source_sha256"],
    }
    for filename, expected in freeze["source_inventory"].items():
        checks[f"source:{filename}"] = file_sha256(ROOT / "mrta" / filename) == expected
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise RuntimeError(f"Frozen input verification failed: {failed}")
    return freeze, manifest, protocol


def aggregate_layout_metrics(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[int, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[(int(row["task"]["seed"]), row["task"]["method"])].append(row)
    output: list[dict[str, Any]] = []
    for (seed, method), group in sorted(grouped.items()):
        if len(group) != 24:
            raise RuntimeError(f"Expected 24 cells for {(seed, method)}, found {len(group)}")
        completed = sum(int(row["result"]["cargo_completed"]) for row in group)
        late = 0
        distance = 0.0
        for row in group:
            result = row["result"]
            count = int(result["cargo_completed"])
            reconstructed = float(result["deadline_miss_rate"]) * count
            rounded = round(reconstructed)
            if not math.isclose(reconstructed, rounded, abs_tol=1e-7):
                raise RuntimeError(f"Cannot reconstruct late-cargo count for {(seed, method)}")
            late += int(rounded)
            distance += float(result["travel_distance_per_cargo"]) * count
        total_ticks = sum(int(row["result"]["horizon"]) for row in group)
        output.append(
            {
                "layout_seed": seed,
                "method": method,
                "repeated_cells": len(group),
                "cargo_completed": completed,
                "deadline_miss_rate": late / completed,
                "low_reserve_assignments_per_completed_cargo": sum(
                    int(row["result"]["low_reserve_tr_assignments"]) for row in group
                )
                / completed,
                "moving_congestion_ticks_per_completed_cargo": sum(
                    int(row["result"]["moving_congestion_exposure_ticks"]) for row in group
                )
                / completed,
                "low_friction_ticks_per_completed_cargo": sum(
                    int(row["result"]["low_friction_exposure_ticks"]) for row in group
                )
                / completed,
                "travel_distance_per_cargo": distance / completed,
                "throughput_per_100_ticks": 100.0 * completed / total_ticks,
                "energy_proxy_per_completed_cargo": sum(
                    float(row["result"]["energy_proxy"]) for row in group
                )
                / completed,
            }
        )
    if len(output) != 75:
        raise RuntimeError(f"Expected 75 layout/method rows, found {len(output)}")
    return output


def prepare_primary_effects(
    layout_rows: list[dict[str, Any]], protocol: dict[str, Any]
) -> list[dict[str, Any]]:
    indexed = {(row["layout_seed"], row["method"]): row for row in layout_rows}
    seeds = sorted({int(row["layout_seed"]) for row in layout_rows})
    output: list[dict[str, Any]] = []
    for hypothesis in protocol["primary_hypotheses"]:
        metric = hypothesis["metric"]
        for seed in seeds:
            intervention = float(indexed[(seed, hypothesis["intervention"])][metric])
            baseline = float(indexed[(seed, hypothesis["baseline"])][metric])
            difference = intervention - baseline
            relative_reduction = (baseline - intervention) / baseline if baseline else None
            output.append(
                {
                    "hypothesis_id": hypothesis["id"],
                    "layout_seed": seed,
                    "metric": metric,
                    "intervention_method": hypothesis["intervention"],
                    "baseline_method": hypothesis["baseline"],
                    "intervention_value": intervention,
                    "baseline_value": baseline,
                    "intervention_minus_baseline": difference,
                    "relative_reduction": relative_reduction,
                    "favourable": difference < 0,
                }
            )
    if len(output) != 60:
        raise RuntimeError(f"Expected 60 primary-effect rows, found {len(output)}")
    return output


def prepare_latency_attempts(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    task_info = {
        row["task"]["task_id"]: {
            "layout_seed": row["task"]["seed"],
            "method": row["task"]["method"],
            "load_level": row["task"]["load_level"],
            "disturbance_level": row["task"]["disturbance_level"],
        }
        for row in rows
    }
    output: list[dict[str, Any]] = []
    for task_id, task in sorted(task_info.items()):
        audit_path = RUN_DIR / "audits" / f"{task_id}.jsonl.gz"
        with gzip.open(audit_path, "rt", encoding="utf-8") as stream:
            for record in map(json.loads, stream):
                if record.get("kind") != "stage_b_attempt":
                    continue
                output.append(
                    {
                        "task_id": task_id,
                        **task,
                        "latency_ms": float(record["latency_ms"]),
                        "timeout": bool(record["timeout"]),
                        "fallback": bool(record["fallback"]),
                        "success": bool(record["success"]),
                        "status": record["status"],
                    }
                )
    if len(output) != 160_219:
        raise RuntimeError(f"Expected 160219 Stage-B attempts, found {len(output)}")
    return output


def main() -> None:
    freeze, manifest, protocol = verify_frozen_inputs()
    rows = [
        json.loads(line)
        for line in (RUN_DIR / "episode_results.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if len(rows) != 1_800:
        raise RuntimeError(f"Expected 1800 episode rows, found {len(rows)}")
    layout_rows = aggregate_layout_metrics(rows)
    primary_rows = prepare_primary_effects(layout_rows, protocol)
    latency_rows = prepare_latency_attempts(rows)
    write_csv(ANALYSIS_DIR / "main_layout_metrics.csv", layout_rows)
    write_csv(ANALYSIS_DIR / "main_primary_effects.csv", primary_rows)
    write_csv(ANALYSIS_DIR / "main_stage_b_latency.csv", latency_rows)
    provenance = {
        "evidence_mode": freeze["evidence_mode"],
        "protocol_id": freeze["protocol_id"],
        "independent_unit": freeze["independent_unit"],
        "n_layout_seeds": len(freeze["layout_seeds"]),
        "task_count": freeze["task_count"],
        "results_sha256": manifest["results_sha256"],
        "freeze_manifest_sha256": file_sha256(ROOT / "main_freeze_manifest.json"),
        "generated_tables": {
            path.name: file_sha256(path)
            for path in sorted(ANALYSIS_DIR.glob("main_*.csv"))
        },
    }
    (ANALYSIS_DIR / "publication_data_provenance.json").write_text(
        json.dumps(provenance, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(provenance, indent=2))


if __name__ == "__main__":
    main()
