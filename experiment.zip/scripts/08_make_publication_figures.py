from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.ticker import PercentFormatter


ROOT = Path(__file__).resolve().parents[1]
FIGURE_SKILL = Path(r"C:\Users\hitey\.codex\skills\scipilot-figure-skill\scripts")
sys.path.insert(0, str(FIGURE_SKILL))

from export_figure import export_figure  # noqa: E402
from layout_tools import add_panel_labels, finalize_figure  # noqa: E402
from setup_style import setup_style  # noqa: E402
from visual_qa import audit_layout, print_report, render_preview  # noqa: E402


FIGURES = ROOT / "figures"
PREVIEWS = FIGURES / "_previews"
ANALYSIS = ROOT / "analysis"
RUN_DIR = ROOT / "runs" / "main_confirmatory_v1"

METHOD_LABELS = {
    "greedy": "Greedy",
    "static_cp_sat": "Static\nCP-SAT",
    "static_mivar_cp_sat": "Static Mivar-inspired\n+ CP-SAT",
    "dynamic_facts_cp_sat": "Dynamic facts\n+ CP-SAT",
    "dynamic_rules_cp_sat": "Dynamic rules\n+ CP-SAT",
}
METHOD_COLORS = {
    "greedy": "#666666",
    "static_cp_sat": "#E69F00",
    "static_mivar_cp_sat": "#56B4E9",
    "dynamic_facts_cp_sat": "#009E73",
    "dynamic_rules_cp_sat": "#CC79A7",
}
METHOD_MARKERS = {
    "greedy": "o",
    "static_cp_sat": "s",
    "static_mivar_cp_sat": "D",
    "dynamic_facts_cp_sat": "^",
    "dynamic_rules_cp_sat": "P",
}

HYPOTHESIS_TITLES = {
    "H1_deadline_full_vs_greedy": "H1  Deadline misses",
    "H2_low_reserve_mivar_vs_cp": "H2  Low-reserve assignments",
    "H3_moving_congestion_facts_vs_mivar": "H3  Moving-congestion exposure",
    "H4_low_friction_rules_vs_facts": "H4  Low-friction exposure",
}
METRIC_LABELS = {
    "deadline_miss_rate": "Deadline miss rate",
    "low_reserve_assignments_per_completed_cargo": "Assignments per completed cargo",
    "moving_congestion_ticks_per_completed_cargo": "Exposure ticks per completed cargo",
    "low_friction_ticks_per_completed_cargo": "Exposure ticks per completed cargo",
}


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def configure_style() -> None:
    setup_style(journal="nature", lang="en", use_sciplots=False)
    plt.rcParams.update(
        {
            "savefig.dpi": 600,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "axes.grid": False,
            "legend.frameon": False,
        }
    )


def finish(fig, name: str, size: tuple[float, float], mode: str) -> None:
    finalize_figure(fig)
    issues = audit_layout(fig)
    verdict = print_report(issues)
    if verdict == "FAIL":
        raise RuntimeError(f"Programmatic visual QA failed for {name}")
    PREVIEWS.mkdir(parents=True, exist_ok=True)
    preview = PREVIEWS / f"{name}_preview.png"
    render_preview(fig, str(preview), dpi=180)
    if mode == "export":
        export_figure(
            fig,
            str(FIGURES / name),
            formats=("pdf", "svg", "png"),
            dpi=600,
            size_inches=size,
            grayscale_preview=True,
            tight=False,
        )
    plt.close(fig)


def figure_primary(
    effects: pd.DataFrame, confirmatory: dict, mode: str
) -> None:
    order = [item["id"] for item in confirmatory["primary_hypotheses"]]
    results = {item["id"]: item for item in confirmatory["primary_hypotheses"]}
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.4), constrained_layout=True)
    for ax, hypothesis_id in zip(axes.flat, order):
        group = effects[effects["hypothesis_id"] == hypothesis_id].sort_values("layout_seed")
        result = results[hypothesis_id]
        baseline = result["baseline"]
        intervention = result["intervention"]
        baseline_values = group["baseline_value"].to_numpy(float)
        intervention_values = group["intervention_value"].to_numpy(float)
        for baseline_value, intervention_value in zip(baseline_values, intervention_values):
            ax.plot(
                [0, 1],
                [baseline_value, intervention_value],
                color="#B8B8B8",
                linewidth=0.65,
                alpha=0.72,
                zorder=1,
            )
        ax.scatter(
            np.zeros(len(group)),
            baseline_values,
            s=19,
            marker=METHOD_MARKERS[baseline],
            facecolor="white",
            edgecolor=METHOD_COLORS[baseline],
            linewidth=0.8,
            zorder=2,
        )
        ax.scatter(
            np.ones(len(group)),
            intervention_values,
            s=21,
            marker=METHOD_MARKERS[intervention],
            facecolor=METHOD_COLORS[intervention],
            edgecolor="black",
            linewidth=0.35,
            zorder=3,
        )
        y_max = max(float(baseline_values.max()), float(intervention_values.max()))
        ax.set_ylim(0, y_max * 1.28)
        ax.set_xlim(-0.38, 1.38)
        ax.set_xticks([0, 1], [METHOD_LABELS[baseline], METHOD_LABELS[intervention]])
        ax.set_ylabel(METRIC_LABELS[result["metric"]])
        if result["metric"] == "deadline_miss_rate":
            ax.yaxis.set_major_formatter(PercentFormatter(xmax=1.0, decimals=0))
        ci_low, ci_high = result["bootstrap_95_ci"]
        annotation = (
            rf"$\Delta$ = {result['mean_difference']:.3f} "
            rf"[{ci_low:.3f}, {ci_high:.3f}]" "\n"
            rf"15/15 layouts; Holm $p$ = {result['holm_adjusted_p']:.2g}"
        )
        ax.text(
            0.5,
            0.98,
            annotation,
            transform=ax.transAxes,
            ha="center",
            va="top",
            fontsize=6.2,
        )
        ax.set_title(HYPOTHESIS_TITLES[hypothesis_id], pad=4)
        sns.despine(ax=ax)
    finalize_figure(fig)
    add_panel_labels(fig, axes=axes.flat, style="nature", x_offset_pt=-23, y_offset_pt=1)
    finish(fig, "Figure_2_confirmatory_primary", (7.2, 5.4), mode)


def figure_noninferiority(
    layout: pd.DataFrame, confirmatory: dict, mode: str
) -> None:
    indexed = layout.set_index(["layout_seed", "method"])
    seeds = sorted(layout["layout_seed"].unique())
    guardrails = confirmatory["noninferiority"]["guardrails"]
    baseline = confirmatory["noninferiority"]["baseline"]
    intervention = confirmatory["noninferiority"]["intervention"]
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.55), constrained_layout=True)
    titles = {"NI_deadline": "Deadline", "NI_distance": "Travel distance", "NI_energy": "Energy proxy"}
    for index, (ax, guardrail) in enumerate(zip(axes, guardrails)):
        metric = guardrail["metric"]
        harms = []
        for seed in seeds:
            int_value = float(indexed.loc[(seed, intervention), metric])
            base_value = float(indexed.loc[(seed, baseline), metric])
            if guardrail["harm"] == "absolute_intervention_minus_baseline":
                harms.append(100.0 * (int_value - base_value))
            else:
                harms.append(100.0 * (int_value / base_value - 1.0))
        mean = 100.0 * float(guardrail["mean_harm"])
        upper = 100.0 * float(guardrail["one_sided_95_upper_bound"])
        margin = 100.0 * float(guardrail["margin"])
        jitter = np.linspace(-0.105, 0.105, len(harms))
        ax.scatter(
            harms,
            jitter,
            s=18,
            facecolor="#56B4E9",
            edgecolor="black",
            linewidth=0.35,
            alpha=0.82,
            zorder=3,
        )
        ax.errorbar(
            mean,
            0.19,
            xerr=np.array([[0.0], [upper - mean]]),
            fmt="D",
            markersize=4.7,
            color="#000000",
            ecolor="#000000",
            elinewidth=1.0,
            capsize=3,
            zorder=4,
        )
        ax.axvline(0, color="#888888", linewidth=0.7)
        ax.axvline(margin, color="#D55E00", linestyle="--", linewidth=1.0)
        lower_limit = min(min(harms), 0.0) - 0.35
        upper_limit = max(max(harms), margin, upper) + 0.55
        ax.set_xlim(lower_limit, upper_limit)
        ax.set_ylim(-0.19, 0.31)
        ax.set_yticks([])
        unit = "percentage points" if guardrail["id"] == "NI_deadline" else "% relative harm"
        ax.set_xlabel(unit)
        ax.set_title(titles[guardrail["id"]])
        ax.text(
            0.02,
            0.98,
            f"Upper 95% bound {upper:.2f} < margin {margin:.2f}",
            transform=ax.transAxes,
            ha="left",
            va="top",
            fontsize=6.0,
            bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.88, "pad": 0.5},
        )
        sns.despine(ax=ax, left=True)
    finalize_figure(fig)
    add_panel_labels(fig, axes=axes, style="nature", x_offset_pt=-19, y_offset_pt=1)
    finish(fig, "Figure_3_noninferiority_guardrails", (7.2, 2.55), mode)


def figure_generalization(effects: pd.DataFrame, mode: str) -> None:
    hypotheses = [
        "H1_deadline_full_vs_greedy",
        "H2_low_reserve_mivar_vs_cp",
        "H3_moving_congestion_facts_vs_mivar",
        "H4_low_friction_rules_vs_facts",
    ]
    labels = [
        "H1 Deadline\nrules vs greedy",
        "H2 Low reserve\nMivar-inspired vs CP-SAT",
        "H3 Congestion\nfacts vs static rules",
        "H4 Low friction\nrules vs facts",
    ]
    matrix = (
        effects.pivot(index="hypothesis_id", columns="layout_seed", values="relative_reduction")
        .loc[hypotheses]
        .mul(100.0)
    )
    fig, ax = plt.subplots(figsize=(7.2, 2.6), constrained_layout=True)
    heatmap = sns.heatmap(
        matrix,
        ax=ax,
        cmap="viridis",
        vmin=0,
        vmax=100,
        annot=True,
        fmt=".0f",
        annot_kws={"fontsize": 5.5},
        linewidths=0.45,
        linecolor="white",
        cbar_kws={"label": "Relative reduction (%)", "pad": 0.015, "shrink": 0.86},
    )
    ax.set_yticklabels(labels, rotation=0)
    ax.set_xticklabels([str(int(value)) for value in matrix.columns], rotation=0)
    ax.set_xlabel("Held-out layout seed")
    ax.set_ylabel("")
    ax.set_title("Improvement is retained across every independent test layout")
    colorbar = heatmap.collections[0].colorbar
    colorbar.ax.tick_params(labelsize=6)
    # Matplotlib rasterizes dense colorbars by default in SVG.  This small
    # colorbar remains light enough to keep as true vector geometry.
    if colorbar.solids is not None:
        colorbar.solids.set_rasterized(False)
    finish(fig, "Figure_4_layout_generalization", (7.2, 2.6), mode)


def figure_latency(latency: pd.DataFrame, validation: dict, mode: str) -> None:
    methods = [
        "greedy",
        "static_cp_sat",
        "static_mivar_cp_sat",
        "dynamic_facts_cp_sat",
        "dynamic_rules_cp_sat",
    ]
    linestyles = ["-", "--", "-.", ":", (0, (5, 1))]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.05), constrained_layout=True)
    ax = axes[0]
    probabilities = np.linspace(0.001, 1.0, 1400)
    for method, linestyle in zip(methods, linestyles):
        values = latency.loc[latency["method"] == method, "latency_ms"].to_numpy(float)
        quantiles = np.quantile(values, probabilities)
        ax.plot(
            quantiles,
            probabilities,
            color=METHOD_COLORS[method],
            linestyle=linestyle,
            linewidth=1.05,
            label=METHOD_LABELS[method].replace("\n", " "),
        )
    ax.axvline(1000, color="#D55E00", linestyle="--", linewidth=0.9, label="1 s budget")
    ax.set_xscale("log")
    ax.set_xlim(0.3, 1250)
    ax.set_ylim(0, 1.01)
    ax.set_xlabel("Stage-B solver latency (ms, log scale)")
    ax.set_ylabel("Empirical cumulative probability")
    ax.legend(loc="lower right", fontsize=5.7, ncol=1)
    sns.despine(ax=ax)

    ax = axes[1]
    tail = validation["stage_b_tail_by_scale_method"]
    y_positions = np.arange(len(methods))[::-1]
    timeout_counts = latency.groupby("method")["timeout"].sum().to_dict()
    for y, method in zip(y_positions, methods):
        metrics = tail[f"S2:{method}"]
        p95 = float(metrics["p95_ms"])
        p99 = float(metrics["p99_ms"])
        maximum = float(metrics["max_ms"])
        ax.plot([p95, p99], [y, y], color=METHOD_COLORS[method], linewidth=1.4)
        ax.plot([p99, maximum], [y, y], color=METHOD_COLORS[method], linewidth=0.8, linestyle=":")
        ax.scatter(p95, y, marker="o", s=20, color=METHOD_COLORS[method], edgecolor="black", linewidth=0.3)
        ax.scatter(p99, y, marker="s", s=20, color=METHOD_COLORS[method], edgecolor="black", linewidth=0.3)
        ax.scatter(maximum, y, marker="^", s=22, color=METHOD_COLORS[method], edgecolor="black", linewidth=0.3)
        count = int(timeout_counts.get(method, 0))
        ax.text(1025, y, f"{count} timeout" if count == 1 else f"{count} timeouts", va="center", ha="left", fontsize=5.7)
    ax.axvline(1000, color="#D55E00", linestyle="--", linewidth=0.9)
    ax.set_xlim(0, 1240)
    ax.set_yticks(y_positions, [METHOD_LABELS[method].replace("\n", " ") for method in methods])
    ax.set_xlabel("Latency (ms)")
    ax.set_title("Tail latency (circle=p95, square=p99, triangle=maximum)", fontsize=6.7)
    sns.despine(ax=ax)
    finalize_figure(fig)
    add_panel_labels(fig, axes=axes, style="nature", x_offset_pt=-22, y_offset_pt=1)
    finish(fig, "Figure_5_stage_b_latency", (7.2, 3.05), mode)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("preview", "export"), default="preview")
    args = parser.parse_args()
    configure_style()
    effects = pd.read_csv(ANALYSIS / "main_primary_effects.csv")
    layout = pd.read_csv(ANALYSIS / "main_layout_metrics.csv")
    latency = pd.read_csv(ANALYSIS / "main_stage_b_latency.csv")
    confirmatory = read_json(RUN_DIR / "confirmatory_analysis.json")
    validation = read_json(RUN_DIR / "validation_report.json")
    figure_primary(effects, confirmatory, args.mode)
    figure_noninferiority(layout, confirmatory, args.mode)
    figure_generalization(effects, args.mode)
    figure_latency(latency, validation, args.mode)
    print(f"Completed figure mode: {args.mode}")


if __name__ == "__main__":
    main()
