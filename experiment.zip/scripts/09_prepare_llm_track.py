from __future__ import annotations

import hashlib
import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from mrta.experiment import _source_digest as main_source_digest
from mrta_llm_v1.experiment import _source_digest as llm_source_digest
from mrta_llm_v1.grounding import DEFAULT_MAX_TOKENS, DEFAULT_MODEL, DEFAULT_THINKING_MODE, PROMPT_SCHEMA_VERSION
from mrta_llm_v1.shield import FACTS_ONLY_PROFILE, LOW_FRICTION_RULE_PROFILE

TRACK = ROOT / "llm_track_v1"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def select_validation_pilot(records: list[dict[str, Any]], per_family: int = 3) -> list[dict[str, Any]]:
    groups: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        if record["split"] == "validation":
            groups[(record["event_type"], record["template_family"])].append(record)
    selected: list[dict[str, Any]] = []
    for key, items in sorted(groups.items()):
        ordered = sorted(items, key=lambda item: item["case_id"])
        if len(ordered) < per_family:
            raise RuntimeError(f"Insufficient validation cases for {key}: {len(ordered)}")
        selected.extend(ordered[:per_family])
    selected.sort(key=lambda item: item["case_id"])
    event_types = {record["event_type"] for record in selected}
    if len(event_types) != 7 or len(selected) != 84:
        raise RuntimeError(f"Unexpected pilot composition: {len(selected)} cases, {len(event_types)} event types")
    return selected


def write_jsonl_if_unchanged(path: Path, records: list[dict[str, Any]]) -> None:
    content = "".join(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n" for record in records)
    if path.exists() and path.read_text(encoding="utf-8") != content:
        raise RuntimeError(f"Refusing to overwrite a different pilot selection: {path}")
    path.write_text(content, encoding="utf-8", newline="\n")


def main() -> None:
    TRACK.mkdir(parents=True, exist_ok=True)
    (TRACK / "protocol").mkdir(exist_ok=True)
    generated_events = ROOT / "data" / "generated_v2" / "events.jsonl"
    e2e_events = TRACK / "e2e_events_test_v1.jsonl"
    e2e_manifest = TRACK / "e2e_events_test_v1.manifest.json"
    e2e_config = TRACK / "configs" / "end_to_end_test_v1.json"
    for required in (generated_events, e2e_events, e2e_manifest, e2e_config, ROOT / "main_freeze_manifest.json"):
        if not required.exists():
            raise FileNotFoundError(required)

    main_freeze = json.loads((ROOT / "main_freeze_manifest.json").read_text(encoding="utf-8"))
    if main_source_digest() != main_freeze["source_sha256"]:
        raise RuntimeError("Frozen Main source has changed; LLM Track preparation is blocked")

    all_records = load_jsonl(generated_events)
    pilot_records = select_validation_pilot(all_records)
    pilot_path = TRACK / "validation_pilot_events_v1.jsonl"
    write_jsonl_if_unchanged(pilot_path, pilot_records)
    test_records = [record for record in all_records if record["split"] == "test"]
    e2e_records = load_jsonl(e2e_events)
    test_low_friction = sum(record["event_type"] == "low_friction" for record in test_records)
    e2e_low_friction = sum(record["event_type"] == "low_friction" for record in e2e_records)
    pilot_low_friction = sum(record["event_type"] == "low_friction" for record in pilot_records)

    draft_protocol = {
        "protocol_id": "deepseek-grounding-e2e-1.0-draft",
        "status": "validation_pilot_only_not_frozen_for_test",
        "model": DEFAULT_MODEL,
        "model_release_label": "DeepSeek-V4-Flash-0731",
        "thinking_mode": DEFAULT_THINKING_MODE,
        "max_tokens": DEFAULT_MAX_TOKENS,
        "prompt_schema_version": PROMPT_SCHEMA_VERSION,
        "profiles": [FACTS_ONLY_PROFILE, LOW_FRICTION_RULE_PROFILE],
        "validation_pilot": {
            "events": len(pilot_records),
            "fact_requests": len(pilot_records),
            "rule_requests": pilot_low_friction,
            "selection": "three lexicographically first cases per event-type by template-family cell",
            "allowed_use": "prompt and parser engineering only; no article inference",
        },
        "test_track_g": {
            "events": len(test_records),
            "map_families": len({record["map_family"] for record in test_records}),
            "fact_requests": len(test_records),
            "rule_requests": test_low_friction,
            "primary_metrics": [
                "syntactic_validity",
                "semantic_exact_match",
                "operation_micro_f1",
                "unsafe_false_accept_rate",
                "correct_false_reject_rate",
            ],
            "publication_gates": {
                "cache_completeness": 1.0,
                "fact_syntactic_validity_min": 0.98,
                "fact_semantic_exact_min": 0.95,
                "rule_semantic_exact_min": 0.90,
                "unsafe_false_accept_rate_max": 0.0,
                "correct_false_reject_rate_max": 0.0,
            },
            "uncertainty": "descriptive 95% cluster bootstrap intervals over map_family; cases are not treated as independent replicates",
        },
        "test_track_e": {
            "config": str(e2e_config.relative_to(ROOT)).replace("\\", "/"),
            "layout_seeds": sorted({int(record["scenario_id"].split("-")[1]) for record in e2e_records}),
            "independent_unit": "layout_seed",
            "events": len(e2e_records),
            "fact_requests": len(e2e_records),
            "rule_requests": e2e_low_friction,
            "tasks": 60,
            "primary_noninferiority": {
                "comparison": "deepseek_rules_cp_sat versus dynamic_rules_cp_sat",
                "deadline_absolute_harm_margin": 0.02,
                "distance_relative_harm_margin": 0.03,
                "energy_relative_harm_margin": 0.03,
                "decision": "one-sided 95% layout-cluster bootstrap upper bound below every margin; intersection-union test",
            },
            "secondary_noninferiority": "deepseek_facts_cp_sat versus dynamic_facts_cp_sat at the same margins",
            "mechanism_contrast": "deepseek_rules_cp_sat versus deepseek_facts_cp_sat for lower low-friction exposure; exact one-sided layout sign test with ties counted as no improvement",
            "engineering_gates": {
                "hard_violations": 0,
                "terminal_pending_cargo": 0,
                "cache_completeness": 1.0,
                "stage_b_max_ms": 1050.0,
            },
        },
        "evidence_boundary": [
            "simulated warehouse only",
            "Mivar-inspired production-rule engine, not Razumator compatibility",
            "DeepSeek output is advisory and fail-closed; deterministic solver and router retain final authority",
            "online API latency is descriptive and is not substituted for the one-second deterministic solver budget",
        ],
    }
    draft_path = TRACK / "protocol" / "draft_protocol_before_validation_pilot.json"
    draft_path.write_text(json.dumps(draft_protocol, indent=2, sort_keys=True), encoding="utf-8")

    manifest = {
        "status": "prepared_before_validation_api_pilot",
        "prepared_utc": datetime.now(timezone.utc).isoformat(),
        "main_source_sha256": main_source_digest(),
        "main_source_matches_freeze": True,
        "llm_source_sha256": llm_source_digest(),
        "llm_source_inventory": {
            path.name: sha256(path) for path in sorted((ROOT / "mrta_llm_v1").glob("*.py"))
        },
        "files": {
            "generated_test_events": {"path": str(generated_events.relative_to(ROOT)).replace("\\", "/"), "sha256": sha256(generated_events)},
            "validation_pilot_events": {"path": str(pilot_path.relative_to(ROOT)).replace("\\", "/"), "sha256": sha256(pilot_path)},
            "e2e_events": {"path": str(e2e_events.relative_to(ROOT)).replace("\\", "/"), "sha256": sha256(e2e_events)},
            "e2e_config": {"path": str(e2e_config.relative_to(ROOT)).replace("\\", "/"), "sha256": sha256(e2e_config)},
            "draft_protocol": {"path": str(draft_path.relative_to(ROOT)).replace("\\", "/"), "sha256": sha256(draft_path)},
        },
        "request_budget": {
            "validation_pilot": len(pilot_records) + pilot_low_friction,
            "track_g_test": len(test_records) + test_low_friction,
            "track_e_test": len(e2e_records) + e2e_low_friction,
            "total_after_pilot": len(test_records) + test_low_friction + len(e2e_records) + e2e_low_friction,
        },
        "counts": {
            "validation_pilot_by_event_type": dict(Counter(record["event_type"] for record in pilot_records)),
            "track_g_test_events": len(test_records),
            "track_g_test_low_friction": test_low_friction,
            "track_e_events": len(e2e_records),
            "track_e_low_friction": e2e_low_friction,
        },
    }
    manifest_path = TRACK / "protocol" / "validation_pilot_freeze_manifest.json"
    if manifest_path.exists():
        prior = json.loads(manifest_path.read_text(encoding="utf-8"))
        prior_without_time = {key: value for key, value in prior.items() if key != "prepared_utc"}
        current_without_time = {key: value for key, value in manifest.items() if key != "prepared_utc"}
        if prior_without_time != current_without_time:
            raise RuntimeError("Validation-pilot freeze manifest already exists with different content")
        manifest = prior
    else:
        manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "status": "ready_for_validation_api_pilot",
        "pilot_requests": manifest["request_budget"]["validation_pilot"],
        "test_requests_after_pilot": manifest["request_budget"]["total_after_pilot"],
        "llm_source_sha256": manifest["llm_source_sha256"],
        "manifest": str(manifest_path),
    }, indent=2))


if __name__ == "__main__":
    main()
