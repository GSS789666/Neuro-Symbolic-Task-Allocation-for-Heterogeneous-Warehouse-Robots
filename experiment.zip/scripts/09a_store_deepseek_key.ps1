$ErrorActionPreference = "Stop"
$experimentRoot = Split-Path -Parent $PSScriptRoot
$secretDirectory = Join-Path $experimentRoot "llm_track_v1\.secrets"
$secretPath = Join-Path $secretDirectory "deepseek_api_key.dpapi"
[System.IO.Directory]::CreateDirectory($secretDirectory) | Out-Null

$secureKey = Read-Host "Enter the DeepSeek API key (input is hidden and is not written as plaintext)" -AsSecureString
if ($secureKey.Length -eq 0) {
    throw "The API key is empty."
}
$encrypted = $secureKey | ConvertFrom-SecureString
[System.IO.File]::WriteAllText($secretPath, $encrypted, [System.Text.UTF8Encoding]::new($false))
Write-Host "DeepSeek key stored with Windows DPAPI for the current Windows account."
Write-Host "Path: $secretPath"
