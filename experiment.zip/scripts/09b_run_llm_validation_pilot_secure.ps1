$ErrorActionPreference = "Stop"
$experimentRoot = Split-Path -Parent $PSScriptRoot
$secretPath = Join-Path $experimentRoot "llm_track_v1\.secrets\deepseek_api_key.dpapi"
$pythonPath = Join-Path $experimentRoot ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $secretPath)) {
    throw "Encrypted DeepSeek key not found. Run scripts\09a_store_deepseek_key.ps1 first."
}
if (-not (Test-Path -LiteralPath $pythonPath)) {
    throw "Python environment not found at $pythonPath"
}

$secureKey = Get-Content -LiteralPath $secretPath -Raw | ConvertTo-SecureString
$keyPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
try {
    $env:DEEPSEEK_API_KEY = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($keyPointer)
    $env:PYTHONPATH = $experimentRoot
    Set-Location -LiteralPath $experimentRoot
    & $pythonPath -m mrta_llm_v1.grounding `
        --events llm_track_v1\validation_pilot_events_v1.jsonl `
        --cache llm_track_v1\cache\validation_pilot `
        --model deepseek-v4-flash `
        --thinking-mode disabled `
        --profiles facts_only low_friction_rule `
        --workers 8
    if ($LASTEXITCODE -ne 0) {
        throw "Validation-pilot prefetch failed with exit code $LASTEXITCODE"
    }
}
finally {
    Remove-Item Env:DEEPSEEK_API_KEY -ErrorAction SilentlyContinue
    if ($keyPointer -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($keyPointer)
    }
}
