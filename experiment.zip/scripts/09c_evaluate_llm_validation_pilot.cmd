@echo off
setlocal
cd /d "%~dp0.."
set "PYTHONPATH=%CD%"
set "DEEPSEEK_MODEL=deepseek-v4-flash"

".venv\Scripts\python.exe" -m mrta_llm_v1.cache_audit --events llm_track_v1\validation_pilot_events_v1.jsonl --cache llm_track_v1\cache\validation_pilot --model "%DEEPSEEK_MODEL%" --thinking-mode disabled --profiles facts_only low_friction_rule
if errorlevel 1 exit /b 1

".venv\Scripts\python.exe" -m mrta_llm_v1.semantic --events llm_track_v1\validation_pilot_events_v1.jsonl --source deepseek_cache --cache llm_track_v1\cache\validation_pilot --model "%DEEPSEEK_MODEL%" --thinking-mode disabled --profile facts_only --output llm_track_v1\runs\validation_pilot_facts_metrics.json
if errorlevel 1 exit /b 1

".venv\Scripts\python.exe" -m mrta_llm_v1.semantic --events llm_track_v1\validation_pilot_events_v1.jsonl --source deepseek_cache --cache llm_track_v1\cache\validation_pilot --model "%DEEPSEEK_MODEL%" --thinking-mode disabled --profile low_friction_rule --event-type low_friction --output llm_track_v1\runs\validation_pilot_rules_metrics.json
if errorlevel 1 exit /b 1

".venv\Scripts\python.exe" scripts\10_analyze_llm_validation_pilot.py
endlocal
