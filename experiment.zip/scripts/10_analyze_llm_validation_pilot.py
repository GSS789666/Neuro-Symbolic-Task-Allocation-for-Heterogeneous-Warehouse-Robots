from __future__ import annotations

import json
import math
import statistics
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from mrta_llm_v1.cache_audit import audit_cache
from mrta_llm_v1.experiment import _source_digest
from mrta_llm_v1.grounding import DEFAULT_MODEL, DEFAULT_THINKING_MODE
from mrta_llm_v1.shield import FACTS_ONLY_PROFILE, LOW_FRICTION_RULE_PROFILE


TRACK = ROOT / "llm_track_v1"


def percentile(values: list[float], probability: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = (len(ordered) - 1) * probability
    low = math.floor(index)
    high = math.ceil(index)
    if low == high:
        return ordered[low]
    return ordered[low] * (high - index) + ordered[high] * (index - low)


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    manifest = read_json(TRACK / "protocol" / "validation_pilot_freeze_manifest.json")
    if _source_digest() != manifest["llm_source_sha256"]:
        raise RuntimeError("LLM source changed after the validation-pilot freeze")
    facts = read_json(TRACK / "runs" / "validation_pilot_facts_metrics.json")
    rules = read_json(TRACK / "runs" / "validation_pilot_rules_metrics.json")
    events_path = TRACK / "validation_pilot_events_v1.jsonl"
    cache_dir = TRACK / "cache" / "validation_pilot"
    cache = audit_cache(
        events_path, cache_dir, DEFAULT_MODEL,
        [FACTS_ONLY_PROFILE, LOW_FRICTION_RULE_PROFILE], DEFAULT_THINKING_MODE,
    )
    gates = {
        "cache_complete": cache["status"] == "pass" and cache["complete_cache_entries"] == cache["required_cache_entries"],
        "facts_syntactic_at_least_0_95": (facts["syntactic_validity"] or 0.0) >= 0.95,
        "facts_semantic_exact_at_least_0_90": (facts["semantic_exact_match"] or 0.0) >= 0.90,
        "rules_syntactic_at_least_0_90": (rules["syntactic_validity"] or 0.0) >= 0.90,
        "rules_semantic_exact_at_least_0_80": (rules["semantic_exact_match"] or 0.0) >= 0.80,
        "facts_unsafe_false_accept_zero": facts["unsafe_false_accept_rate"] in (None, 0.0),
        "rules_unsafe_false_accept_zero": rules["unsafe_false_accept_rate"] in (None, 0.0),
        "facts_correct_false_reject_zero": facts["correct_false_reject_rate"] in (None, 0.0),
        "rules_correct_false_reject_zero": rules["correct_false_reject_rate"] in (None, 0.0),
    }
    case_results = [*facts["case_results"], *rules["case_results"]]
    latencies = [float(item["api_latency_ms"]) for item in case_results if item.get("api_latency_ms") is not None]
    usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    response_records = 0
    for path in cache_dir.glob("*.json"):
        record = read_json(path)
        if record.get("response_status") not in {"valid", "invalid"}:
            continue
        response_records += 1
        for key in usage:
            usage[key] += int((record.get("usage") or {}).get(key, 0) or 0)
    workers = 8
    remaining_requests = int(manifest["request_budget"]["total_after_pilot"])
    p95_ms = percentile(latencies, 0.95)
    conservative_seconds = (
        (p95_ms / 1000.0) * remaining_requests / workers * 1.5
        if p95_ms is not None else None
    )
    result = {
        "status": "pass" if all(gates.values()) else "fail",
        "gates": gates,
        "facts": {
            "n": facts["counts"]["total"],
            "syntactic_validity": facts["syntactic_validity"],
            "semantic_exact_match": facts["semantic_exact_match"],
            "operation_micro_f1": facts["operation_micro_f1"],
            "unsafe_false_accept_rate": facts["unsafe_false_accept_rate"],
        },
        "rules": {
            "n": rules["counts"]["total"],
            "syntactic_validity": rules["syntactic_validity"],
            "semantic_exact_match": rules["semantic_exact_match"],
            "operation_micro_f1": rules["operation_micro_f1"],
            "unsafe_false_accept_rate": rules["unsafe_false_accept_rate"],
        },
        "api": {
            "response_records": response_records,
            "latency_n": len(latencies),
            "latency_median_ms": statistics.median(latencies) if latencies else None,
            "latency_p95_ms": p95_ms,
            "latency_max_ms": max(latencies) if latencies else None,
            "usage": usage,
            "workers_for_projection": workers,
            "remaining_requests": remaining_requests,
            "conservative_projected_wall_time_s": conservative_seconds,
            "projected_over_three_hours": conservative_seconds is None or conservative_seconds > 3 * 3600,
        },
        "cache_audit": cache,
        "source_sha256": _source_digest(),
        "decision": (
            "Freeze the test protocol without prompt changes."
            if all(gates.values())
            else "Do not open test caches; revise only against the validation pilot in a new source version."
        ),
    }
    output = TRACK / "runs" / "validation_pilot_analysis.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "facts_semantic_exact": result["facts"]["semantic_exact_match"],
        "rules_semantic_exact": result["rules"]["semantic_exact_match"],
        "projected_wall_time_s": conservative_seconds,
        "projected_over_three_hours": result["api"]["projected_over_three_hours"],
        "output": str(output),
    }, indent=2))
    raise SystemExit(0 if result["status"] == "pass" else 1)


if __name__ == "__main__":
    main()
