from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
source = ROOT / "data" / "generated_v2" / "events.jsonl"
output = ROOT / "llm_track_v1" / "track_g_test_events_v1.jsonl"
records = [
    json.loads(line) for line in source.read_text(encoding="utf-8").splitlines()
    if line.strip()
]
selected = [record for record in records if record["split"] == "test"]
content = "".join(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n" for record in selected)
if output.exists() and output.read_text(encoding="utf-8") != content:
    raise RuntimeError(f"Refusing to overwrite a different Track-G test export: {output}")
output.write_text(content, encoding="utf-8", newline="\n")
manifest = {
    "status": "exported_without_model_results",
    "source_path": str(source.relative_to(ROOT)).replace("\\", "/"),
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "output_path": str(output.relative_to(ROOT)).replace("\\", "/"),
    "output_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
    "event_count": len(selected),
    "map_family_count": len({record["map_family"] for record in selected}),
    "event_type_counts": dict(Counter(record["event_type"] for record in selected)),
    "low_friction_count": sum(record["event_type"] == "low_friction" for record in selected),
}
manifest_path = output.with_suffix(".manifest.json")
manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
print(json.dumps(manifest, indent=2))
