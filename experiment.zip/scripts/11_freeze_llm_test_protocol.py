from __future__ import annotations

import hashlib
import json
import sys
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from mrta_llm_v1.experiment import _source_digest, _source_inventory, build_tasks


TRACK = ROOT / "llm_track_v1"


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    pilot_freeze_path = TRACK / "protocol" / "validation_pilot_freeze_manifest.json"
    pilot_analysis_path = TRACK / "runs" / "validation_pilot_analysis.json"
    if not pilot_analysis_path.exists():
        raise RuntimeError("Validation pilot has not been evaluated")
    pilot_freeze = read_json(pilot_freeze_path)
    pilot_analysis = read_json(pilot_analysis_path)
    if pilot_analysis.get("status") != "pass":
        raise RuntimeError("Validation pilot did not pass; test results must remain unopened")
    if _source_digest() != pilot_freeze["llm_source_sha256"]:
        raise RuntimeError("Source changed after validation-pilot freeze; create a new version instead")

    config_path = TRACK / "configs" / "end_to_end_test_v1_frozen.json"
    events_g_path = TRACK / "track_g_test_events_v1.jsonl"
    events_e_path = TRACK / "e2e_events_test_v1_frozen.jsonl"
    config = read_json(config_path)
    tasks = build_tasks(config)
    task_payload = [asdict(task) for task in sorted(tasks, key=lambda item: item.task_id)]
    task_digest = hashlib.sha256(
        json.dumps(task_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()

    result_paths = [
        TRACK / "runs" / "track_g_facts_metrics.json",
        TRACK / "runs" / "track_g_rules_metrics.json",
        TRACK / "runs" / config["run_name"],
        TRACK / "runs" / "llm_tracks_final_analysis.json",
    ]
    cache_paths = [TRACK / "cache" / "track_g_test", TRACK / "cache" / "e2e_test"]
    if any(path.exists() for path in result_paths):
        raise RuntimeError("A test result path already exists; refusing a post-hoc freeze")
    if any(path.exists() and any(path.glob("*.json")) for path in cache_paths):
        raise RuntimeError("A test API cache already contains responses; refusing a post-hoc freeze")

    draft = read_json(TRACK / "protocol" / "draft_protocol_before_validation_pilot.json")
    protocol = {
        **draft,
        "protocol_id": "deepseek-grounding-e2e-1.0",
        "status": "frozen_before_test",
        "frozen_utc": datetime.now(timezone.utc).isoformat(),
        "validation_pilot_analysis_sha256": sha256(pilot_analysis_path),
        "test_track_g": {
            **draft["test_track_g"],
            "event_file": str(events_g_path.relative_to(ROOT)).replace("\\", "/"),
            "event_file_sha256": sha256(events_g_path),
        },
        "test_track_e": {
            **draft["test_track_e"],
            "config": str(config_path.relative_to(ROOT)).replace("\\", "/"),
            "config_sha256": sha256(config_path),
            "event_file": str(events_e_path.relative_to(ROOT)).replace("\\", "/"),
            "event_file_sha256": sha256(events_e_path),
        },
        "analysis": {
            "script": "scripts/13_analyze_llm_tracks.py",
            "script_sha256": sha256(ROOT / "scripts" / "13_analyze_llm_tracks.py"),
            "bootstrap_replicates": 20_000,
            "bootstrap_seed": 20260826,
        },
    }
    protocol_path = TRACK / "protocol" / "test_protocol.json"
    if protocol_path.exists():
        raise RuntimeError(f"Test protocol already exists: {protocol_path}")
    protocol_path.write_text(json.dumps(protocol, indent=2, sort_keys=True), encoding="utf-8")

    freeze = {
        "status": "frozen_before_main",
        "main_results_opened": False,
        "protocol_id": protocol["protocol_id"],
        "protocol_path": str(protocol_path.resolve()),
        "protocol_sha256": sha256(protocol_path),
        "run_name": config["run_name"],
        "config_path": str(config_path.resolve()),
        "config_sha256": sha256(config_path),
        "source_sha256": _source_digest(),
        "source_inventory": _source_inventory(),
        "task_count": len(tasks),
        "task_ids": [task.task_id for task in sorted(tasks, key=lambda item: item.task_id)],
        "task_ids_sha256": task_digest,
        "audit_schema": config["audit_schema"],
        "independent_unit": "layout_seed",
        "layout_seeds": sorted({task.seed for task in tasks}),
        "track_g_events_path": str(events_g_path.resolve()),
        "track_g_events_sha256": sha256(events_g_path),
        "track_e_events_path": str(events_e_path.resolve()),
        "track_e_events_sha256": sha256(events_e_path),
        "validation_pilot_freeze_sha256": sha256(pilot_freeze_path),
        "validation_pilot_analysis_sha256": sha256(pilot_analysis_path),
        "analysis_script_sha256": sha256(ROOT / "scripts" / "13_analyze_llm_tracks.py"),
        "evidence_boundary": protocol["evidence_boundary"],
    }
    freeze_path = TRACK / "protocol" / "test_freeze_manifest.json"
    if freeze_path.exists():
        raise RuntimeError(f"Test freeze already exists: {freeze_path}")
    freeze_path.write_text(json.dumps(freeze, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "status": "frozen_before_test",
        "protocol": str(protocol_path),
        "freeze_manifest": str(freeze_path),
        "task_count": len(tasks),
        "track_g_event_count": protocol["test_track_g"]["events"],
        "track_e_event_count": protocol["test_track_e"]["events"],
        "source_sha256": freeze["source_sha256"],
    }, indent=2))


if __name__ == "__main__":
    main()
