from __future__ import annotations

import gzip
import hashlib
import json
import math
import random
import statistics
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from mrta_llm_v1.cache_audit import audit_cache
from mrta_llm_v1.experiment import _source_digest
from mrta_llm_v1.grounding import DEFAULT_MODEL, DEFAULT_THINKING_MODE
from mrta_llm_v1.shield import FACTS_ONLY_PROFILE, LOW_FRICTION_RULE_PROFILE


TRACK = ROOT / "llm_track_v1"
BOOTSTRAP_REPLICATES = 20_000
BOOTSTRAP_SEED = 20260826


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def quantile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    low = math.floor(position)
    high = math.ceil(position)
    if low == high:
        return ordered[low]
    return ordered[low] * (high - position) + ordered[high] * (position - low)


def cluster_summary(case_results: list[dict[str, Any]], field: str) -> dict[str, Any]:
    by_family: dict[str, list[float]] = defaultdict(list)
    for item in case_results:
        family = item.get("map_family")
        if not family:
            raise RuntimeError(f"Missing map_family in {item['case_id']}")
        by_family[family].append(float(bool(item[field])))
    family_rates = {key: statistics.fmean(values) for key, values in sorted(by_family.items())}
    rates = list(family_rates.values())
    rng = random.Random(BOOTSTRAP_SEED)
    bootstrap = [
        statistics.fmean(rates[rng.randrange(len(rates))] for _ in rates)
        for _ in range(BOOTSTRAP_REPLICATES)
    ]
    return {
        "cluster_count": len(rates),
        "cluster_equal_weight_mean": statistics.fmean(rates),
        "cluster_bootstrap_95_ci": [quantile(bootstrap, 0.025), quantile(bootstrap, 0.975)],
        "family_rates": family_rates,
    }


def audit_e2e_artifacts(run_dir: Path, freeze: dict[str, Any]) -> dict[str, Any]:
    manifest = read_json(run_dir / "run_manifest.json")
    rows = [json.loads(line) for line in (run_dir / "episode_results.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    failures: list[str] = []
    max_stage_b_ms = 0.0
    audit_attempts = 0
    for row in rows:
        task = row["task"]
        task_id = task["task_id"]
        episode_path = run_dir / "episodes" / f"{task_id}.json"
        audit_path = run_dir / "audits" / f"{task_id}.jsonl.gz"
        if not episode_path.exists() or not audit_path.exists():
            failures.append(f"missing_artifact:{task_id}")
            continue
        episode = read_json(episode_path)
        if episode != row:
            failures.append(f"aggregate_episode_mismatch:{task_id}")
        canonical_hash = hashlib.sha256(
            json.dumps(episode, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        with gzip.open(audit_path, "rt", encoding="utf-8") as stream:
            audit = [json.loads(line) for line in stream if line.strip()]
        summaries = [item for item in audit if item.get("kind") == "episode_summary"]
        completions = [item for item in audit if item.get("kind") == "audit_complete"]
        if len(summaries) != 1 or summaries[0].get("result") != episode["result"]:
            failures.append(f"episode_summary_mismatch:{task_id}")
        if len(completions) != 1:
            failures.append(f"audit_complete_count:{task_id}")
        else:
            completion = completions[0]
            if completion.get("payload_sha256") != canonical_hash:
                failures.append(f"payload_hash_mismatch:{task_id}")
            if completion.get("source_sha256") != freeze["source_sha256"]:
                failures.append(f"source_hash_mismatch:{task_id}")
            if completion.get("audit_schema") != freeze["audit_schema"]:
                failures.append(f"audit_schema_mismatch:{task_id}")
        for item in audit:
            if item.get("kind") == "stage_b_attempt":
                audit_attempts += 1
                max_stage_b_ms = max(max_stage_b_ms, float(item["latency_ms"]))
    expected_task_ids = set(freeze["task_ids"])
    observed_task_ids = {row["task"]["task_id"] for row in rows}
    if observed_task_ids != expected_task_ids:
        failures.append("task_identity_set_mismatch")
    checks = {
        "manifest_complete": manifest.get("status") == "complete",
        "manifest_source_match": manifest.get("source_sha256") == freeze["source_sha256"],
        "manifest_config_match": manifest.get("config_sha256") == freeze["config_sha256"],
        "manifest_freeze_match": manifest.get("freeze_manifest_sha256") == sha256(TRACK / "protocol" / "test_freeze_manifest.json"),
        "row_count_match": len(rows) == freeze["task_count"],
        "zero_artifact_failures": not failures,
    }
    return {
        "status": "pass" if all(checks.values()) else "fail",
        "checks": checks,
        "failure_count": len(failures),
        "failure_examples": failures[:50],
        "row_count": len(rows),
        "audit_stage_b_attempts": audit_attempts,
        "max_stage_b_latency_ms": max_stage_b_ms,
        "rows": rows,
    }


def metric(row: dict[str, Any], name: str) -> float:
    result = row["result"]
    completed = max(1, int(result["cargo_completed"]))
    if name == "deadline":
        return float(result["deadline_miss_rate"])
    if name == "distance":
        return float(result["travel_distance_per_cargo"])
    if name == "energy":
        return float(result["energy_proxy"]) / completed
    if name == "low_friction":
        return float(result["low_friction_exposure_ticks"]) / completed
    raise ValueError(name)


def by_seed_method(rows: list[dict[str, Any]]) -> dict[int, dict[str, dict[str, Any]]]:
    grouped: dict[int, dict[str, dict[str, Any]]] = defaultdict(dict)
    for row in rows:
        seed = int(row["task"]["seed"])
        method_name = str(row["task"]["method"])
        if method_name in grouped[seed]:
            raise RuntimeError(f"Duplicate seed-method cell: {seed}, {method_name}")
        grouped[seed][method_name] = row
    return dict(grouped)


def paired_values(
    grouped: dict[int, dict[str, dict[str, Any]]],
    intervention: str,
    baseline: str,
    transform: Callable[[dict[str, Any], dict[str, Any]], float],
) -> list[tuple[int, float]]:
    return [
        (seed, transform(methods[intervention], methods[baseline]))
        for seed, methods in sorted(grouped.items())
    ]


def one_sided_bootstrap_upper(values: list[float]) -> float:
    rng = random.Random(BOOTSTRAP_SEED)
    means = [
        statistics.fmean(values[rng.randrange(len(values))] for _ in values)
        for _ in range(BOOTSTRAP_REPLICATES)
    ]
    return quantile(means, 0.95)


def noninferiority(
    grouped: dict[int, dict[str, dict[str, Any]]],
    intervention: str,
    baseline: str,
) -> dict[str, Any]:
    definitions = {
        "deadline": (0.02, lambda a, b: metric(a, "deadline") - metric(b, "deadline")),
        "distance": (0.03, lambda a, b: metric(a, "distance") / metric(b, "distance") - 1.0),
        "energy": (0.03, lambda a, b: metric(a, "energy") / metric(b, "energy") - 1.0),
    }
    components: dict[str, Any] = {}
    for name, (margin, transform) in definitions.items():
        pairs = paired_values(grouped, intervention, baseline, transform)
        values = [value for _, value in pairs]
        upper = one_sided_bootstrap_upper(values)
        components[name] = {
            "margin": margin,
            "mean_harm": statistics.fmean(values),
            "one_sided_95_upper": upper,
            "pass": upper < margin,
            "by_seed": {str(seed): value for seed, value in pairs},
        }
    return {
        "intervention": intervention,
        "baseline": baseline,
        "components": components,
        "intersection_union_pass": all(item["pass"] for item in components.values()),
    }


def exact_sign_test(grouped: dict[int, dict[str, dict[str, Any]]]) -> dict[str, Any]:
    pairs = paired_values(
        grouped,
        "deepseek_rules_cp_sat",
        "deepseek_facts_cp_sat",
        lambda a, b: metric(a, "low_friction") - metric(b, "low_friction"),
    )
    wins = sum(value < 0 for _, value in pairs)
    ties = sum(value == 0 for _, value in pairs)
    losses = sum(value > 0 for _, value in pairs)
    n = len(pairs)
    p_value = sum(math.comb(n, k) for k in range(wins, n + 1)) / (2**n)
    return {
        "wins": wins,
        "ties": ties,
        "losses": losses,
        "exact_one_sided_p": p_value,
        "mean_difference": statistics.fmean(value for _, value in pairs),
        "supported": p_value < 0.05 and wins > n / 2,
        "by_seed": {str(seed): value for seed, value in pairs},
    }


def cache_usage(*directories: Path) -> dict[str, Any]:
    usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    latencies: list[float] = []
    records = 0
    invalid = 0
    for directory in directories:
        for path in directory.glob("*.json"):
            record = read_json(path)
            if record.get("response_status") not in {"valid", "invalid"}:
                continue
            records += 1
            invalid += int(record["response_status"] == "invalid")
            if record.get("api_latency_ms") is not None:
                latencies.append(float(record["api_latency_ms"]))
            for key in usage:
                usage[key] += int((record.get("usage") or {}).get(key, 0) or 0)
    return {
        "response_records": records,
        "invalid_response_records": invalid,
        "usage": usage,
        "latency_n": len(latencies),
        "latency_median_ms": statistics.median(latencies) if latencies else None,
        "latency_p95_ms": quantile(latencies, 0.95) if latencies else None,
        "latency_p99_ms": quantile(latencies, 0.99) if latencies else None,
        "latency_max_ms": max(latencies) if latencies else None,
    }


def main() -> None:
    freeze = read_json(TRACK / "protocol" / "test_freeze_manifest.json")
    if freeze["status"] != "frozen_before_main" or freeze["main_results_opened"] is not False:
        raise RuntimeError("Invalid test freeze status")
    if _source_digest() != freeze["source_sha256"]:
        raise RuntimeError("LLM source differs from the frozen test source")
    facts = read_json(TRACK / "runs" / "track_g_facts_metrics.json")
    rules = read_json(TRACK / "runs" / "track_g_rules_metrics.json")
    facts_cluster = cluster_summary(facts["case_results"], "semantic_exact")
    rules_cluster = cluster_summary(rules["case_results"], "semantic_exact")
    g_cache = audit_cache(
        TRACK / "track_g_test_events_v1.jsonl",
        TRACK / "cache" / "track_g_test",
        DEFAULT_MODEL,
        [FACTS_ONLY_PROFILE, LOW_FRICTION_RULE_PROFILE],
        DEFAULT_THINKING_MODE,
    )
    e_cache = audit_cache(
        TRACK / "e2e_events_test_v1_frozen.jsonl",
        TRACK / "cache" / "e2e_test",
        DEFAULT_MODEL,
        [FACTS_ONLY_PROFILE, LOW_FRICTION_RULE_PROFILE],
        DEFAULT_THINKING_MODE,
    )
    run_dir = TRACK / "runs" / "deepseek_e2e_test_v1"
    artifact_audit = audit_e2e_artifacts(run_dir, freeze)
    rows = artifact_audit.pop("rows")
    grouped = by_seed_method(rows)
    expected_methods = {
        "dynamic_facts_cp_sat", "dynamic_rules_cp_sat",
        "deepseek_facts_cp_sat", "deepseek_rules_cp_sat",
    }
    cell_complete = len(grouped) == 15 and all(set(methods) == expected_methods for methods in grouped.values())
    hard_violations = sum(int(row["result"]["hard_violations"]) for row in rows)
    pending = sum(int(row["result"]["cargo_pending"]) for row in rows)
    primary_ni = noninferiority(grouped, "deepseek_rules_cp_sat", "dynamic_rules_cp_sat")
    secondary_ni = noninferiority(grouped, "deepseek_facts_cp_sat", "dynamic_facts_cp_sat")
    mechanism = exact_sign_test(grouped)
    g_gates = {
        "cache_complete": g_cache["status"] == "pass",
        "fact_syntactic_validity": (facts["syntactic_validity"] or 0.0) >= 0.98,
        "fact_semantic_exact": (facts["semantic_exact_match"] or 0.0) >= 0.95,
        "rule_semantic_exact": (rules["semantic_exact_match"] or 0.0) >= 0.90,
        "unsafe_false_accept_zero": facts["counts"].get("unsafe_accepted", 0) == 0 and rules["counts"].get("unsafe_accepted", 0) == 0,
        "correct_false_reject_zero": facts["counts"].get("correct_rejected", 0) == 0 and rules["counts"].get("correct_rejected", 0) == 0,
    }
    e_gates = {
        "cache_complete": e_cache["status"] == "pass",
        "artifact_audit": artifact_audit["status"] == "pass",
        "matched_cells": cell_complete,
        "hard_violations_zero": hard_violations == 0,
        "terminal_pending_zero": pending == 0,
        "stage_b_max_within_1050_ms": artifact_audit["max_stage_b_latency_ms"] <= 1050.0,
        "primary_noninferiority": primary_ni["intersection_union_pass"],
    }
    result = {
        "status": "pass" if all(g_gates.values()) and all(e_gates.values()) else "fail",
        "protocol_id": freeze["protocol_id"],
        "track_g": {
            "gates": g_gates,
            "facts": {key: facts[key] for key in (
                "syntactic_validity", "logical_consistency", "semantic_exact_match",
                "operation_micro_precision", "operation_micro_recall", "operation_micro_f1",
                "unsafe_false_accept_rate", "correct_false_reject_rate", "per_event_type",
            )},
            "facts_counts": facts["counts"],
            "facts_cluster": facts_cluster,
            "rules": {key: rules[key] for key in (
                "syntactic_validity", "logical_consistency", "semantic_exact_match",
                "operation_micro_precision", "operation_micro_recall", "operation_micro_f1",
                "unsafe_false_accept_rate", "correct_false_reject_rate", "per_event_type",
            )},
            "rules_counts": rules["counts"],
            "rules_cluster": rules_cluster,
            "cache_audit": g_cache,
        },
        "track_e": {
            "gates": e_gates,
            "artifact_audit": artifact_audit,
            "hard_violations": hard_violations,
            "terminal_pending_cargo": pending,
            "primary_noninferiority": primary_ni,
            "secondary_noninferiority": secondary_ni,
            "deepseek_rule_mechanism": mechanism,
            "cache_audit": e_cache,
            "grounding_totals": {
                method: {
                    "attempts": sum(int(row["result"]["grounding_attempts"]) for row in rows if row["task"]["method"] == method),
                    "accepted": sum(int(row["result"]["grounding_shield_accepted"]) for row in rows if row["task"]["method"] == method),
                    "rejected": sum(int(row["result"]["grounding_rejected"]) for row in rows if row["task"]["method"] == method),
                    "rules_accepted": sum(int(row["result"]["grounding_rule_accepted"]) for row in rows if row["task"]["method"] == method),
                }
                for method in ("deepseek_facts_cp_sat", "deepseek_rules_cp_sat")
            },
        },
        "api_measurements": cache_usage(
            TRACK / "cache" / "validation_pilot",
            TRACK / "cache" / "track_g_test",
            TRACK / "cache" / "e2e_test",
        ),
        "evidence_boundary": freeze["evidence_boundary"],
    }
    output = TRACK / "runs" / "llm_tracks_final_analysis.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "track_g_gates": g_gates,
        "track_e_gates": e_gates,
        "output": str(output),
    }, indent=2))
    raise SystemExit(0 if result["status"] == "pass" else 1)


if __name__ == "__main__":
    main()
