from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from mrta_llm_v11.cache_seal import sha256, verify_existing_cache_against_plan
from mrta_llm_v11.experiment import _source_digest, _source_inventory, build_tasks
from mrta_llm_v11.grounding import DEFAULT_MODEL, DEFAULT_THINKING_MODE, PROMPT_SCHEMA_VERSION


TRACK = ROOT / "llm_track_v1_1"


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def task_digest(config_path: Path) -> tuple[int, str]:
    tasks = build_tasks(read_json(config_path))
    payload = [asdict(task) for task in sorted(tasks, key=lambda item: item.task_id)]
    digest = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return len(tasks), digest


def validation_gate() -> dict[str, Any]:
    freeze = read_json(TRACK / "protocol" / "validation_pilot_freeze_manifest.json")
    events = ROOT / freeze["files"]["validation_pilot_events"]["path"]
    plan = ROOT / freeze["files"]["validation_request_plan"]["path"]
    cache = TRACK / "cache" / "validation_pilot"
    checks = {
        "status": freeze.get("status") == "prepared_before_validation_api_pilot",
        "source_sha256": _source_digest() == freeze["llm_source_sha256"],
        "source_inventory": _source_inventory() == freeze["llm_source_inventory"],
        "event_sha256": sha256(events) == freeze["files"]["validation_pilot_events"]["sha256"],
        "request_plan_sha256": sha256(plan) == freeze["files"]["validation_request_plan"]["sha256"],
        "gate_script_sha256": sha256(Path(__file__)) == freeze["files"]["prefetch_identity_gate"]["sha256"],
        "model": freeze["model_contract"]["model"] == DEFAULT_MODEL,
        "thinking_mode": freeze["model_contract"]["thinking_mode"] == DEFAULT_THINKING_MODE,
        "prompt_schema_version": freeze["model_contract"]["prompt_schema_version"] == PROMPT_SCHEMA_VERSION,
    }
    if not all(checks.values()):
        raise RuntimeError(f"Validation prefetch identity gate failed: {[key for key, value in checks.items() if not value]}")
    cache_check = verify_existing_cache_against_plan(plan, events, cache)
    return {"status": "pass", "scope": "validation", "checks": checks, "existing_cache": cache_check}


def heldout_gate() -> dict[str, Any]:
    freeze_path = TRACK / "protocol" / "test_freeze_manifest.json"
    protocol_path = TRACK / "protocol" / "test_protocol.json"
    freeze = read_json(freeze_path)
    protocol = read_json(protocol_path)
    config = Path(freeze["config_path"])
    g_events = Path(freeze["track_g_events_path"])
    e_events = Path(freeze["track_e_events_path"])
    g_plan = Path(freeze["track_g_request_plan_path"])
    e_plan = Path(freeze["track_e_request_plan_path"])
    count, digest = task_digest(config)
    checks = {
        "status": freeze.get("status") == "frozen_before_main" and freeze.get("main_results_opened") is False,
        "source_sha256": _source_digest() == freeze["source_sha256"],
        "source_inventory": _source_inventory() == freeze["source_inventory"],
        "protocol_sha256": sha256(protocol_path) == freeze["protocol_sha256"],
        "config_sha256": sha256(config) == freeze["config_sha256"],
        "track_g_event_sha256": sha256(g_events) == freeze["track_g_events_sha256"],
        "track_e_event_sha256": sha256(e_events) == freeze["track_e_events_sha256"],
        "track_g_plan_sha256": sha256(g_plan) == freeze["track_g_request_plan_sha256"],
        "track_e_plan_sha256": sha256(e_plan) == freeze["track_e_request_plan_sha256"],
        "task_count": count == freeze["task_count"],
        "task_digest": digest == freeze["task_ids_sha256"],
        "analysis_script_sha256": sha256(ROOT / "scripts" / "24_analyze_llm_tracks_v11.py") == freeze["analysis_script_sha256"],
        "analysis_common_sha256": sha256(ROOT / "scripts" / "llm_v11_common.py") == freeze["analysis_common_sha256"],
        "gate_script_sha256": sha256(Path(__file__)) == freeze["prefetch_identity_gate_sha256"],
        "model": freeze["model"] == DEFAULT_MODEL == protocol["model"],
        "thinking_mode": freeze["thinking_mode"] == DEFAULT_THINKING_MODE == protocol["thinking_mode"],
        "prompt_schema_version": freeze["prompt_schema_version"] == PROMPT_SCHEMA_VERSION == protocol["prompt_schema_version"],
    }
    if not all(checks.values()):
        raise RuntimeError(f"Held-out prefetch identity gate failed before API: {[key for key, value in checks.items() if not value]}")
    if (TRACK / "runs" / freeze["run_name"]).exists():
        raise RuntimeError("Held-out simulation result directory already exists; refusing to issue additional API requests")
    g_cache = verify_existing_cache_against_plan(g_plan, g_events, TRACK / "cache" / "track_g_test")
    e_cache = verify_existing_cache_against_plan(e_plan, e_events, TRACK / "cache" / "e2e_test")
    return {
        "status": "pass",
        "scope": "heldout",
        "checks": checks,
        "track_g_existing_cache": g_cache,
        "track_e_existing_cache": e_cache,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify every frozen identity before the first DeepSeek request")
    parser.add_argument("--scope", choices=["validation", "heldout"], required=True)
    args = parser.parse_args()
    result = validation_gate() if args.scope == "validation" else heldout_gate()
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
