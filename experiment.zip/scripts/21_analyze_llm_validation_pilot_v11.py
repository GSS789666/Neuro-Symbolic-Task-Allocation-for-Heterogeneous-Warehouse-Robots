from __future__ import annotations

import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from llm_v11_common import cache_usage, equal_family_summary, read_json, read_jsonl, sha256, verify_metric_binding
from mrta_llm_v11.cache_audit import audit_cache
from mrta_llm_v11.cache_seal import verify_cache_seal
from mrta_llm_v11.experiment import _source_digest
from mrta_llm_v11.grounding import DEFAULT_MODEL, DEFAULT_THINKING_MODE, PROMPT_SCHEMA_VERSION
from mrta_llm_v11.semantic import evaluate_events
from mrta_llm_v11.shield import FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE, RULE_EVENT_TYPES


TRACK = ROOT / "llm_track_v1_1"


def main() -> None:
    freeze_path = TRACK / "protocol" / "validation_pilot_freeze_manifest.json"
    freeze = read_json(freeze_path)
    draft = read_json(TRACK / "protocol" / "draft_protocol_before_validation_pilot.json")
    events_path = TRACK / "validation_pilot_events_v1_1.jsonl"
    cache_dir = TRACK / "cache" / "validation_pilot"
    plan_path = ROOT / draft["validation_pilot"]["request_plan"]
    seal_path = ROOT / draft["validation_pilot"]["postfetch_cache_seal"]
    if _source_digest() != freeze["llm_source_sha256"]:
        raise RuntimeError("LLM source changed after validation-pilot freeze")
    if sha256(events_path) != freeze["files"]["validation_pilot_events"]["sha256"]:
        raise RuntimeError("Validation-pilot event file changed after freeze")

    records = read_jsonl(events_path)
    rule_records = [record for record in records if record["event_type"] in RULE_EVENT_TYPES]
    cache_seal = verify_cache_seal(seal_path, plan_path, events_path, cache_dir)
    cache = audit_cache(
        events_path,
        cache_dir,
        DEFAULT_MODEL,
        [FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE],
        DEFAULT_THINKING_MODE,
        seal_path,
    )
    facts = evaluate_events(
        events_path, "deepseek_cache", cache_dir, DEFAULT_MODEL,
        profile=FACTS_ONLY_PROFILE, thinking_mode=DEFAULT_THINKING_MODE,
        sealed_manifest_path=seal_path,
    )
    rules = evaluate_events(
        events_path, "deepseek_cache", cache_dir, DEFAULT_MODEL,
        profile=RESTRICTED_RULE_PROFILE, thinking_mode=DEFAULT_THINKING_MODE,
        sealed_manifest_path=seal_path,
    )
    verify_metric_binding(
        facts, events_path, FACTS_ONLY_PROFILE, DEFAULT_MODEL, DEFAULT_THINKING_MODE,
        PROMPT_SCHEMA_VERSION, records,
    )
    verify_metric_binding(
        rules, events_path, RESTRICTED_RULE_PROFILE, DEFAULT_MODEL, DEFAULT_THINKING_MODE,
        PROMPT_SCHEMA_VERSION, rule_records,
    )

    facts_summary = {
        field: equal_family_summary(facts["case_results"], field)
        for field in ("schema_valid", "semantic_exact", "shield_accept", "response_invalid")
    }
    rules_summary = {
        field: equal_family_summary(rules["case_results"], field)
        for field in (
            "schema_valid", "semantic_exact", "shield_accept", "response_invalid",
            "rule_template_correct", "rule_operation_exact",
        )
    }
    thresholds = draft["validation_pilot"]["engineering_gates"]
    mean = lambda summary, field: float(summary[field]["cluster_equal_weight_mean"])
    execution_checks = {
        "cache_cryptographic_seal": cache_seal["status"] == "pass",
        "cache_metadata_complete": cache["status"] == "pass"
        and cache["complete_cache_entries"] == cache["required_cache_entries"],
        "facts_bound_to_frozen_cases": facts["case_ids_sha256"] == freeze["case_ids"]["validation_facts"],
        "rules_bound_to_frozen_cases": rules["case_ids_sha256"] == freeze["case_ids"]["validation_rules"],
        "post_shield_incorrect_commit_zero": facts["software_invariants"]["post_shield_incorrect_commit_count"] == 0
        and rules["software_invariants"]["post_shield_incorrect_commit_count"] == 0,
        "correct_proposal_rejected_zero": facts["software_invariants"]["correct_proposal_rejected_count"] == 0
        and rules["software_invariants"]["correct_proposal_rejected_count"] == 0,
    }
    performance_checks = {
        "facts_syntactic": mean(facts_summary, "schema_valid") >= thresholds["facts_syntactic_min"],
        "facts_full_exact": mean(facts_summary, "semantic_exact") >= thresholds["facts_full_exact_min"],
        "facts_accepted_availability": mean(facts_summary, "shield_accept") >= thresholds["facts_accepted_availability_min"],
        "facts_invalid_response": mean(facts_summary, "response_invalid") <= thresholds["facts_invalid_response_max"],
        "rules_syntactic": mean(rules_summary, "schema_valid") >= thresholds["rules_syntactic_min"],
        "rules_template_selection": mean(rules_summary, "rule_template_correct") >= thresholds["rules_template_selection_min"],
        "rules_operation_exact": mean(rules_summary, "rule_operation_exact") >= thresholds["rules_operation_exact_min"],
        "rules_full_exact": mean(rules_summary, "semantic_exact") >= thresholds["rules_full_exact_min"],
        "rules_accepted_availability": mean(rules_summary, "shield_accept") >= thresholds["rules_accepted_availability_min"],
        "rules_invalid_response": mean(rules_summary, "response_invalid") <= thresholds["rules_invalid_response_max"],
    }
    api = cache_usage(cache_dir)
    remaining = int(freeze["request_budget"]["total_test_after_pilot"])
    workers = int(freeze["api_execution"]["workers"])
    p95_ms = api["latency_p95_ms"]
    projected_seconds = (
        float(p95_ms) / 1000.0 * remaining / workers * 1.5
        if p95_ms is not None else None
    )
    execution_valid = all(execution_checks.values())
    prompt_ready = all(performance_checks.values())
    result = {
        "status": "pass" if execution_valid and prompt_ready else "fail",
        "scope": "validation-only prompt and parser engineering; no article hypothesis test",
        "execution_valid": execution_valid,
        "prompt_ready_for_frozen_test": prompt_ready,
        "execution_checks": execution_checks,
        "performance_checks": performance_checks,
        "thresholds": thresholds,
        "facts_equal_map_family_summary": facts_summary,
        "rules_equal_map_family_summary": rules_summary,
        "facts_pooled_descriptive": {key: facts[key] for key in (
            "syntactic_validity", "semantic_exact_match", "invalid_response_rate",
            "accepted_availability_rate", "operation_micro_f1", "per_event_type",
        )},
        "rules_pooled_descriptive": {key: rules[key] for key in (
            "syntactic_validity", "semantic_exact_match", "invalid_response_rate",
            "accepted_availability_rate", "rule_template_selection_accuracy",
            "rule_operation_exact_match", "operation_micro_f1", "per_event_type",
        )},
        "software_invariants": {
            "facts": facts["software_invariants"],
            "rules": rules["software_invariants"],
        },
        "cache_audit": cache,
        "cache_seal_audit": cache_seal,
        "api_measurements": api,
        "wall_time_projection": {
            "remaining_requests": remaining,
            "workers": workers,
            "p95_latency_multiplier": 1.5,
            "projected_seconds": projected_seconds,
            "projected_over_three_hours": projected_seconds is None or projected_seconds > 10_800,
        },
        "source_sha256": _source_digest(),
        "freeze_manifest_sha256": sha256(freeze_path),
        "decision": (
            "Freeze the test protocol without prompt changes."
            if execution_valid and prompt_ready
            else "Do not create or open test caches; revise only from validation evidence in a new version."
        ),
    }
    runs = TRACK / "runs"
    runs.mkdir(parents=True, exist_ok=True)
    (runs / "validation_pilot_facts_metrics.json").write_text(
        json.dumps(facts, indent=2, sort_keys=True), encoding="utf-8",
    )
    (runs / "validation_pilot_rules_metrics.json").write_text(
        json.dumps(rules, indent=2, sort_keys=True), encoding="utf-8",
    )
    output = runs / "validation_pilot_analysis.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "execution_valid": execution_valid,
        "prompt_ready_for_frozen_test": prompt_ready,
        "projected_seconds": projected_seconds,
        "projected_over_three_hours": result["wall_time_projection"]["projected_over_three_hours"],
        "output": str(output),
    }, indent=2))
    raise SystemExit(0 if result["status"] == "pass" else 1)


if __name__ == "__main__":
    main()
