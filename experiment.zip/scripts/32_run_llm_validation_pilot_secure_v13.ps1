$ErrorActionPreference = "Stop"
$experimentRoot = Split-Path -Parent $PSScriptRoot
$secretPath = Join-Path $experimentRoot "llm_track_v1_3\.secrets\deepseek_api_key.dpapi"
$pythonPath = Join-Path $experimentRoot ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $secretPath)) {
    throw "Encrypted DeepSeek key not found. Run scripts\30a_store_deepseek_key_v13.ps1 first."
}
if (-not (Test-Path -LiteralPath $pythonPath)) {
    throw "Python environment not found at $pythonPath"
}

Push-Location -LiteralPath $experimentRoot
try {
    & $pythonPath scripts\29_prefetch_identity_gate_v13.py --scope validation
    if ($LASTEXITCODE -ne 0) {
        throw "Frozen validation identities failed before API; no request was issued."
    }
}
finally {
    Pop-Location
}

$secureKey = Get-Content -LiteralPath $secretPath -Raw | ConvertTo-SecureString
$keyPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
Push-Location -LiteralPath $experimentRoot
try {
    $env:DEEPSEEK_API_KEY = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($keyPointer)
    $env:PYTHONPATH = $experimentRoot
    & $pythonPath -m mrta_llm_v13.grounding `
        --events llm_track_v1_3\validation_pilot_events_v1_1.jsonl `
        --cache llm_track_v1_3\cache\validation_pilot `
        --model deepseek-v4-flash `
        --thinking-mode disabled `
        --profiles facts_only restricted_rule `
        --workers 8
    if ($LASTEXITCODE -ne 0) {
        throw "Validation-pilot prefetch failed with exit code $LASTEXITCODE"
    }

    & $pythonPath -m mrta_llm_v13.cache_seal seal `
        --events llm_track_v1_3\validation_pilot_events_v1_1.jsonl `
        --cache llm_track_v1_3\cache\validation_pilot `
        --plan llm_track_v1_3\protocol\request_plans\validation_pilot_request_plan.json `
        --seal llm_track_v1_3\cache_manifests\validation_pilot_cache_seal.json
    if ($LASTEXITCODE -ne 0) {
        throw "Validation cache could not be cryptographically sealed."
    }
}
finally {
    Remove-Item Env:DEEPSEEK_API_KEY -ErrorAction SilentlyContinue
    if ($keyPointer -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($keyPointer)
    }
    Pop-Location
}

Push-Location -LiteralPath $experimentRoot
try {
    & $pythonPath scripts\31_analyze_llm_validation_pilot_v13.py
    if ($LASTEXITCODE -ne 0) {
        throw "Validation-pilot analysis failed its preregistered engineering gates."
    }
}
finally {
    Pop-Location
}
