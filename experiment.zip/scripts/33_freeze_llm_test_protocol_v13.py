from __future__ import annotations

import hashlib
import json
import sys
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from llm_v11_common import case_ids_sha256, read_json, read_jsonl, sha256
from mrta_llm_v13.cache_seal import build_request_plan, write_request_plan
from mrta_llm_v13.experiment import _source_digest, _source_inventory, build_tasks
from mrta_llm_v13.export_events import export_config_events
from mrta_llm_v13.grounding import DEFAULT_MODEL, DEFAULT_THINKING_MODE, PROMPT_SCHEMA_VERSION
from mrta_llm_v13.shield import RESTRICTED_RULE_PROFILE, RULE_EVENT_TYPES


TRACK = ROOT / "llm_track_v1_3"


def main() -> None:
    pilot_freeze_path = TRACK / "protocol" / "validation_pilot_freeze_manifest.json"
    pilot_analysis_path = TRACK / "runs" / "validation_pilot_analysis.json"
    if not pilot_analysis_path.exists():
        raise RuntimeError("Validation pilot has not been analyzed; held-out caches must remain unopened")
    pilot_freeze = read_json(pilot_freeze_path)
    pilot_analysis = read_json(pilot_analysis_path)
    if pilot_analysis.get("status") != "pass" or not pilot_analysis.get("prompt_ready_for_frozen_test"):
        raise RuntimeError("Validation pilot has not passed; test caches must remain unopened")
    if _source_digest() != pilot_freeze["llm_source_sha256"]:
        raise RuntimeError("Source changed after the validation-pilot freeze; create a new version")
    source_config_path = TRACK / "configs" / "end_to_end_test_v1_1.json"
    frozen_config_path = TRACK / "configs" / "end_to_end_test_v1_1_frozen.json"
    frozen_events_path = TRACK / "e2e_events_test_v1_1_frozen.jsonl"
    config = read_json(source_config_path)
    config["required_freeze_manifest"] = "protocol/test_freeze_manifest.json"
    content = json.dumps(config, indent=2, sort_keys=True)
    if frozen_config_path.exists() and frozen_config_path.read_text(encoding="utf-8") != content:
        raise RuntimeError("A different frozen Track-E config already exists")
    frozen_config_path.write_text(content, encoding="utf-8")
    export_config_events(frozen_config_path, frozen_events_path)
    original_events = TRACK / "e2e_events_test_v1_1.jsonl"
    if sha256(frozen_events_path) != sha256(original_events):
        raise RuntimeError("Adding the freeze binding unexpectedly changed the Track-E event stream")

    profiles = ["facts_only", RESTRICTED_RULE_PROFILE]
    g_plan_path = TRACK / "protocol" / "request_plans" / "track_g_request_plan.json"
    e_plan_path = TRACK / "protocol" / "request_plans" / "track_e_frozen_request_plan.json"
    write_request_plan(
        e_plan_path,
        build_request_plan(
            frozen_events_path, TRACK / "cache" / "e2e_test",
            DEFAULT_MODEL, profiles, DEFAULT_THINKING_MODE,
        ),
    )

    track_g_events = TRACK / "track_g_test_events_v1_1.jsonl"
    g_records = read_jsonl(track_g_events)
    e_records = read_jsonl(frozen_events_path)
    g_rules = [item for item in g_records if item["event_type"] in RULE_EVENT_TYPES]
    e_rules = [item for item in e_records if item["event_type"] in RULE_EVENT_TYPES]
    expected_case_ids = pilot_freeze["case_ids"]
    actual_case_ids = {
        "track_g_facts": case_ids_sha256(g_records),
        "track_g_rules": case_ids_sha256(g_rules),
        "track_e_facts": case_ids_sha256(e_records),
        "track_e_rules": case_ids_sha256(e_rules),
    }
    if any(actual_case_ids[key] != expected_case_ids[key] for key in actual_case_ids):
        raise RuntimeError("Held-out case identities differ from the pre-pilot manifest")

    config = read_json(frozen_config_path)
    tasks = build_tasks(config)
    task_payload = [asdict(task) for task in sorted(tasks, key=lambda item: item.task_id)]
    task_digest = hashlib.sha256(
        json.dumps(task_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    result_paths = [
        TRACK / "runs" / config["run_name"],
        TRACK / "runs" / "llm_tracks_final_analysis.json",
    ]
    cache_paths = [TRACK / "cache" / "track_g_test", TRACK / "cache" / "e2e_test"]
    seal_paths = [
        TRACK / "cache_manifests" / "track_g_cache_seal.json",
        TRACK / "cache_manifests" / "e2e_test_cache_seal.json",
    ]
    if any(path.exists() for path in result_paths):
        raise RuntimeError("A held-out result path already exists; refusing a post-hoc freeze")
    if any(path.exists() and any(path.glob("*.json")) for path in cache_paths):
        raise RuntimeError("A held-out API cache already contains responses; refusing a post-hoc freeze")
    if any(path.exists() for path in seal_paths):
        raise RuntimeError("A held-out cache seal already exists; refusing a post-hoc freeze")

    draft = read_json(TRACK / "protocol" / "draft_protocol_before_validation_pilot.json")
    analysis_files = {
        "final_analyzer": ROOT / "scripts" / "34_analyze_llm_tracks_v13.py",
        "analysis_common": ROOT / "scripts" / "llm_v11_common.py",
        "prefetch_identity_gate": ROOT / "scripts" / "29_prefetch_identity_gate_v13.py",
    }
    for path in analysis_files.values():
        if not path.exists():
            raise FileNotFoundError(path)
    protocol = {
        **draft,
        "protocol_id": "deepseek-grounding-e2e-1.3",
        "status": "frozen_before_held_out_test",
        "frozen_utc": datetime.now(timezone.utc).isoformat(),
        "validation_pilot_analysis_sha256": sha256(pilot_analysis_path),
        "test_track_g": {
            **draft["test_track_g"],
            "event_file": track_g_events.relative_to(ROOT).as_posix(),
            "event_file_sha256": sha256(track_g_events),
            "fact_case_ids_sha256": actual_case_ids["track_g_facts"],
            "rule_case_ids_sha256": actual_case_ids["track_g_rules"],
            "request_plan": g_plan_path.relative_to(ROOT).as_posix(),
            "request_plan_sha256": sha256(g_plan_path),
        },
        "test_track_e": {
            **draft["test_track_e"],
            "config": frozen_config_path.relative_to(ROOT).as_posix(),
            "config_sha256": sha256(frozen_config_path),
            "event_file": frozen_events_path.relative_to(ROOT).as_posix(),
            "event_file_sha256": sha256(frozen_events_path),
            "fact_case_ids_sha256": actual_case_ids["track_e_facts"],
            "rule_case_ids_sha256": actual_case_ids["track_e_rules"],
            "request_plan": e_plan_path.relative_to(ROOT).as_posix(),
            "request_plan_sha256": sha256(e_plan_path),
        },
        "analysis": {
            "final_analyzer": analysis_files["final_analyzer"].relative_to(ROOT).as_posix(),
            "final_analyzer_sha256": sha256(analysis_files["final_analyzer"]),
            "analysis_common": analysis_files["analysis_common"].relative_to(ROOT).as_posix(),
            "analysis_common_sha256": sha256(analysis_files["analysis_common"]),
            "prefetch_identity_gate": analysis_files["prefetch_identity_gate"].relative_to(ROOT).as_posix(),
            "prefetch_identity_gate_sha256": sha256(analysis_files["prefetch_identity_gate"]),
            "bootstrap_replicates": 20_000,
            "bootstrap_seed": 20260826,
        },
        "cache_identity_contract": {
            "model": DEFAULT_MODEL,
            "thinking_mode": DEFAULT_THINKING_MODE,
            "prompt_schema_version": PROMPT_SCHEMA_VERSION,
            "profiles": ["facts_only", RESTRICTED_RULE_PROFILE],
            "event_text_and_full_trusted_context_bound_into_cache_key": True,
        },
    }
    protocol_path = TRACK / "protocol" / "test_protocol.json"
    freeze_path = TRACK / "protocol" / "test_freeze_manifest.json"
    if protocol_path.exists() or freeze_path.exists():
        raise RuntimeError("Held-out protocol is already frozen")
    protocol_path.write_text(json.dumps(protocol, indent=2, sort_keys=True), encoding="utf-8")

    freeze = {
        "status": "frozen_before_main",
        "main_results_opened": False,
        "protocol_id": protocol["protocol_id"],
        "protocol_path": str(protocol_path.resolve()),
        "protocol_sha256": sha256(protocol_path),
        "run_name": config["run_name"],
        "config_path": str(frozen_config_path.resolve()),
        "config_sha256": sha256(frozen_config_path),
        "source_sha256": _source_digest(),
        "source_inventory": _source_inventory(),
        "task_count": len(tasks),
        "task_ids": [task.task_id for task in sorted(tasks, key=lambda item: item.task_id)],
        "task_ids_sha256": task_digest,
        "audit_schema": config["audit_schema"],
        "independent_unit": "layout_seed",
        "layout_seeds": sorted({task.seed for task in tasks}),
        "track_g_events_path": str(track_g_events.resolve()),
        "track_g_events_sha256": sha256(track_g_events),
        "track_g_fact_case_ids_sha256": actual_case_ids["track_g_facts"],
        "track_g_rule_case_ids_sha256": actual_case_ids["track_g_rules"],
        "track_g_request_plan_path": str(g_plan_path.resolve()),
        "track_g_request_plan_sha256": sha256(g_plan_path),
        "track_g_cache_seal_path": str(seal_paths[0].resolve()),
        "track_e_events_path": str(frozen_events_path.resolve()),
        "track_e_events_sha256": sha256(frozen_events_path),
        "track_e_fact_case_ids_sha256": actual_case_ids["track_e_facts"],
        "track_e_rule_case_ids_sha256": actual_case_ids["track_e_rules"],
        "track_e_request_plan_path": str(e_plan_path.resolve()),
        "track_e_request_plan_sha256": sha256(e_plan_path),
        "track_e_cache_seal_path": str(seal_paths[1].resolve()),
        "validation_pilot_freeze_sha256": sha256(pilot_freeze_path),
        "validation_pilot_analysis_sha256": sha256(pilot_analysis_path),
        "analysis_script_sha256": sha256(analysis_files["final_analyzer"]),
        "analysis_common_sha256": sha256(analysis_files["analysis_common"]),
        "prefetch_identity_gate_sha256": sha256(analysis_files["prefetch_identity_gate"]),
        "model": DEFAULT_MODEL,
        "thinking_mode": DEFAULT_THINKING_MODE,
        "prompt_schema_version": PROMPT_SCHEMA_VERSION,
        "evidence_boundary": protocol["evidence_boundary"],
    }
    freeze_path.write_text(json.dumps(freeze, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "status": "frozen_before_held_out_test",
        "protocol": str(protocol_path),
        "freeze_manifest": str(freeze_path),
        "task_count": len(tasks),
        "track_g_event_count": len(g_records),
        "track_e_event_count": len(e_records),
        "source_sha256": freeze["source_sha256"],
    }, indent=2))


if __name__ == "__main__":
    main()
