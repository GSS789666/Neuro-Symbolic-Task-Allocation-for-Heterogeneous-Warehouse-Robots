$ErrorActionPreference = "Stop"
$experimentRoot = Split-Path -Parent $PSScriptRoot
$secretPath = Join-Path $experimentRoot "llm_track_v1_3\.secrets\deepseek_api_key.dpapi"
$freezePath = Join-Path $experimentRoot "llm_track_v1_3\protocol\test_freeze_manifest.json"
$pythonPath = Join-Path $experimentRoot ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $secretPath)) {
    throw "Encrypted DeepSeek key not found. Run scripts\30a_store_deepseek_key_v13.ps1 first."
}
if (-not (Test-Path -LiteralPath $freezePath)) {
    throw "Held-out protocol is not frozen. The validation pilot and reviewer gate must pass first."
}

Push-Location -LiteralPath $experimentRoot
try {
    & $pythonPath scripts\29_prefetch_identity_gate_v13.py --scope heldout
    if ($LASTEXITCODE -ne 0) {
        throw "Frozen held-out identities failed before API; no request was issued."
    }
}
finally {
    Pop-Location
}

$secureKey = Get-Content -LiteralPath $secretPath -Raw | ConvertTo-SecureString
$keyPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
Push-Location -LiteralPath $experimentRoot
try {
    $env:DEEPSEEK_API_KEY = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($keyPointer)
    $env:PYTHONPATH = $experimentRoot
    & $pythonPath -m mrta_llm_v13.grounding `
        --events llm_track_v1_3\track_g_test_events_v1_1.jsonl `
        --cache llm_track_v1_3\cache\track_g_test `
        --model deepseek-v4-flash `
        --thinking-mode disabled `
        --profiles facts_only restricted_rule `
        --workers 8
    if ($LASTEXITCODE -ne 0) { throw "Track-G prefetch failed with exit code $LASTEXITCODE" }

    & $pythonPath -m mrta_llm_v13.grounding `
        --events llm_track_v1_3\e2e_events_test_v1_1_frozen.jsonl `
        --cache llm_track_v1_3\cache\e2e_test `
        --model deepseek-v4-flash `
        --thinking-mode disabled `
        --profiles facts_only restricted_rule `
        --workers 8
    if ($LASTEXITCODE -ne 0) { throw "Track-E prefetch failed with exit code $LASTEXITCODE" }

    & $pythonPath -m mrta_llm_v13.cache_seal seal `
        --events llm_track_v1_3\track_g_test_events_v1_1.jsonl `
        --cache llm_track_v1_3\cache\track_g_test `
        --plan llm_track_v1_3\protocol\request_plans\track_g_request_plan.json `
        --seal llm_track_v1_3\cache_manifests\track_g_cache_seal.json
    if ($LASTEXITCODE -ne 0) { throw "Track-G cache seal failed" }

    & $pythonPath -m mrta_llm_v13.cache_seal seal `
        --events llm_track_v1_3\e2e_events_test_v1_1_frozen.jsonl `
        --cache llm_track_v1_3\cache\e2e_test `
        --plan llm_track_v1_3\protocol\request_plans\track_e_frozen_request_plan.json `
        --seal llm_track_v1_3\cache_manifests\e2e_test_cache_seal.json
    if ($LASTEXITCODE -ne 0) { throw "Track-E cache seal failed" }
}
finally {
    Remove-Item Env:DEEPSEEK_API_KEY -ErrorAction SilentlyContinue
    if ($keyPointer -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($keyPointer)
    }
    Pop-Location
}

Push-Location -LiteralPath $experimentRoot
try {
    & $pythonPath -m mrta_llm_v13.experiment `
        --config llm_track_v1_3\configs\end_to_end_test_v1_1_frozen.json `
        --output llm_track_v1_3\runs
    if ($LASTEXITCODE -ne 0) { throw "Track-E simulation failed with exit code $LASTEXITCODE" }

    & $pythonPath scripts\34_analyze_llm_tracks_v13.py
    if ($LASTEXITCODE -ne 0) { throw "Frozen-track artifact or execution audit failed." }
}
finally {
    Pop-Location
}
