from __future__ import annotations

import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from llm_v11_common import case_ids_sha256, read_json, read_jsonl, sha256
from mrta.experiment import _source_digest as main_source_digest
from mrta_llm_v14.cache_seal import build_request_plan, write_request_plan
from mrta_llm_v14.experiment import _source_digest as llm_source_digest, _source_inventory
from mrta_llm_v14.grounding import DEFAULT_MAX_TOKENS, DEFAULT_MODEL, DEFAULT_THINKING_MODE, PROMPT_SCHEMA_VERSION
from mrta_llm_v14.shield import FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE, RULE_EVENT_TYPES


TRACK = ROOT / "llm_track_v1_4"


def select_validation_pilot(records: list[dict[str, Any]], per_family: int = 3) -> list[dict[str, Any]]:
    groups: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        if record["split"] == "validation":
            groups[(record["event_type"], record["template_family"])].append(record)
    selected: list[dict[str, Any]] = []
    for key, items in sorted(groups.items()):
        ordered = sorted(items, key=lambda item: item["case_id"])
        if len(ordered) < per_family:
            raise RuntimeError(f"Insufficient validation cases for {key}: {len(ordered)}")
        selected.extend(ordered[:per_family])
    selected.sort(key=lambda item: item["case_id"])
    if len(selected) != 84 or len({item["event_type"] for item in selected}) != 7:
        raise RuntimeError("Validation pilot must contain 3 cases from every one of 28 event/paraphrase cells")
    return selected


def write_jsonl_if_same_or_new(path: Path, records: list[dict[str, Any]]) -> None:
    content = "".join(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n" for record in records)
    if path.exists() and path.read_text(encoding="utf-8") != content:
        raise RuntimeError(f"Refusing to overwrite a different frozen selection: {path}")
    path.write_text(content, encoding="utf-8", newline="\n")


def main() -> None:
    for directory in (TRACK, TRACK / "cache", TRACK / "configs", TRACK / "protocol", TRACK / "runs"):
        directory.mkdir(parents=True, exist_ok=True)
    generated_events = ROOT / "data" / "generated_v3" / "events.jsonl"
    validation_report = ROOT / "data" / "generated_v3" / "validation_report.json"
    e2e_events = TRACK / "e2e_events_test_v1_1.jsonl"
    e2e_manifest = e2e_events.with_suffix(".manifest.json")
    e2e_config = TRACK / "configs" / "end_to_end_test_v1_1.json"
    main_freeze_path = ROOT / "main_freeze_manifest.json"
    for required in (generated_events, validation_report, e2e_events, e2e_manifest, e2e_config, main_freeze_path):
        if not required.exists():
            raise FileNotFoundError(required)
    validation = read_json(validation_report)
    if validation.get("status") != "pass":
        raise RuntimeError("Generated-v3 structural validation did not pass")
    main_freeze = read_json(main_freeze_path)
    if main_source_digest() != main_freeze["source_sha256"]:
        raise RuntimeError("Frozen Main source changed; LLM Track v1.1 preparation is blocked")

    all_records = read_jsonl(generated_events)
    pilot_records = select_validation_pilot(all_records)
    test_records = sorted(
        (record for record in all_records if record["split"] == "test"),
        key=lambda item: item["case_id"],
    )
    pilot_path = TRACK / "validation_pilot_events_v1_1.jsonl"
    test_path = TRACK / "track_g_test_events_v1_1.jsonl"
    write_jsonl_if_same_or_new(pilot_path, pilot_records)
    write_jsonl_if_same_or_new(test_path, test_records)
    e2e_records = read_jsonl(e2e_events)
    pilot_rules = [item for item in pilot_records if item["event_type"] in RULE_EVENT_TYPES]
    test_rules = [item for item in test_records if item["event_type"] in RULE_EVENT_TYPES]
    e2e_rules = [item for item in e2e_records if item["event_type"] in RULE_EVENT_TYPES]
    if len({item["map_family"] for item in test_records}) != 12:
        raise RuntimeError("Track G must retain exactly 12 held-out map families")

    request_plan_dir = TRACK / "protocol" / "request_plans"
    request_plan_dir.mkdir(parents=True, exist_ok=True)
    profiles = [FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE]
    plan_paths = {
        "validation": request_plan_dir / "validation_pilot_request_plan.json",
        "track_g": request_plan_dir / "track_g_request_plan.json",
        "track_e": request_plan_dir / "track_e_request_plan.json",
    }
    for key, events, cache in (
        ("validation", pilot_path, TRACK / "cache" / "validation_pilot"),
        ("track_g", test_path, TRACK / "cache" / "track_g_test"),
        ("track_e", e2e_events, TRACK / "cache" / "e2e_test"),
    ):
        write_request_plan(
            plan_paths[key],
            build_request_plan(events, cache, DEFAULT_MODEL, profiles, DEFAULT_THINKING_MODE, DEFAULT_MAX_TOKENS),
        )

    test_manifest = {
        "status": "exported_without_model_results",
        "source_path": generated_events.relative_to(ROOT).as_posix(),
        "source_sha256": sha256(generated_events),
        "output_path": test_path.relative_to(ROOT).as_posix(),
        "output_sha256": sha256(test_path),
        "case_ids_sha256": case_ids_sha256(test_records),
        "event_count": len(test_records),
        "map_family_count": len({item["map_family"] for item in test_records}),
        "event_type_counts": dict(Counter(item["event_type"] for item in test_records)),
        "restricted_rule_count": len(test_rules),
    }
    test_manifest_path = test_path.with_suffix(".manifest.json")
    test_manifest_path.write_text(json.dumps(test_manifest, indent=2, sort_keys=True), encoding="utf-8")

    draft = {
        "protocol_id": "deepseek-grounding-e2e-1.4-draft",
        "status": "validation_pilot_only_not_frozen_for_test",
        "model": DEFAULT_MODEL,
        "model_release_label": "DeepSeek-V4-Flash-0731",
        "thinking_mode": DEFAULT_THINKING_MODE,
        "max_tokens": DEFAULT_MAX_TOKENS,
        "prompt_schema_version": PROMPT_SCHEMA_VERSION,
        "profiles": [FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE],
        "overlap_semantics": "all independently derived route_penalty atoms remain proof-traceable; routing deterministically applies the maximum penalty per cell",
        "validation_pilot": {
            "events": len(pilot_records),
            "fact_requests": len(pilot_records),
            "restricted_rule_requests": len(pilot_rules),
            "selection": "three lexicographically first validation cases in each of 7 event types x 4 preregistered paraphrase families",
            "allowed_use": "prompt/parser engineering and runtime projection only; excluded from article hypothesis tests",
            "request_plan": plan_paths["validation"].relative_to(ROOT).as_posix(),
            "postfetch_cache_seal": "llm_track_v1_4/cache_manifests/validation_pilot_cache_seal.json",
            "engineering_gates": {
                "facts_syntactic_min": 0.95,
                "facts_full_exact_min": 0.90,
                "facts_accepted_availability_min": 0.90,
                "facts_invalid_response_max": 0.05,
                "rules_syntactic_min": 0.95,
                "rules_template_selection_min": 0.85,
                "rules_operation_exact_min": 0.80,
                "rules_full_exact_min": 0.80,
                "rules_accepted_availability_min": 0.80,
                "rules_invalid_response_max": 0.05
            },
        },
        "test_track_g": {
            "estimand": "equal-weight mean of performance rates across the 12 held-out map families",
            "events": len(test_records),
            "map_families": 12,
            "fact_requests": len(test_records),
            "restricted_rule_requests": len(test_rules),
            "pooled_metrics": "descriptive only",
            "uncertainty": "95% nonparametric bootstrap intervals over equal-weight map-family rates; 20000 replicates",
            "publication_gates": {
                "facts_syntactic_min": 0.98,
                "facts_full_exact_min": 0.95,
                "facts_accepted_availability_min": 0.95,
                "facts_invalid_response_max": 0.02,
                "rules_syntactic_min": 0.98,
                "rules_template_selection_min": 0.95,
                "rules_operation_exact_min": 0.90,
                "rules_full_exact_min": 0.90,
                "rules_accepted_availability_min": 0.90,
                "rules_invalid_response_max": 0.02
            },
            "software_invariant": "post-shield incorrect commits and correct-proposal rejections must both equal zero; this is a deterministic interface contract, not a neural safety estimate",
            "request_plan": plan_paths["track_g"].relative_to(ROOT).as_posix(),
            "postfetch_cache_seal": "llm_track_v1_4/cache_manifests/track_g_cache_seal.json",
        },
        "test_track_e": {
            "config": e2e_config.relative_to(ROOT).as_posix(),
            "estimand": "mean held-out-layout harm at load 0.80, high disturbance, one trace per layout, 1200 ticks, scale S2",
            "layout_seeds": [4107, 4108, 4110, 4111, 4112, 4113, 4114, 4127, 4128, 4130, 4131, 4132, 4133, 4134, 4147],
            "independent_unit": "layout_seed",
            "events": len(e2e_records),
            "fact_requests": len(e2e_records),
            "restricted_rule_requests": len(e2e_rules),
            "tasks": 60,
            "request_plan": plan_paths["track_e"].relative_to(ROOT).as_posix(),
            "postfetch_cache_seal": "llm_track_v1_4/cache_manifests/e2e_test_cache_seal.json",
            "primary_noninferiority": {
                "comparison": "deepseek_rules_cp_sat versus dynamic_rules_cp_sat",
                "alpha_one_sided": 0.05,
                "deadline_absolute_harm_margin": 0.02,
                "distance_relative_harm_margin": 0.03,
                "energy_relative_harm_margin": 0.03,
                "decision": "intersection-union pass only when every one-sided 95% layout-bootstrap upper bound is strictly below its margin",
            },
            "secondary_noninferiority": "deepseek_facts_cp_sat versus dynamic_facts_cp_sat at the same margins; labelled secondary",
            "mechanism_contrast": {
                "comparison": "deepseek_rules_cp_sat versus deepseek_facts_cp_sat for lower low-friction exposure per completed cargo",
                "test": "exact one-sided sign test over all 15 layouts; ties count as no improvement",
                "alpha": 0.05,
                "minimum_strict_wins": 12,
                "decision": "supported only if p < 0.05 and strict wins >= 12; 12/15 gives p=0.01758 whereas 11/15 gives p=0.05923",
            },
            "mechanism_claim_boundary": "Track E tests only the incremental low-friction -> route-penalty mechanism. Moving-congestion, robot-unavailability, and access-restriction templates are evaluated as grounding selection/instantiation tasks in Track G and carry no separate Track-E causal mechanism claim.",
            "execution_checks": {
                "hard_violations": 0,
                "terminal_pending_cargo": 0,
                "cache_completeness": 1.0,
                "stage_b_max_ms": 1050.0,
                "authenticated_WMS_fallback": "service-time and cancellation changes apply equally to all controllers even after a rejected LLM proposal",
            },
        },
        "reporting_separation": [
            "execution_validity",
            "Track-G grounding support",
            "primary noninferiority support",
            "restricted-rule mechanism support",
        ],
        "evidence_boundary": [
            "synthetic English event descriptions in a simulated warehouse",
            "Mivar-inspired versioned production-rule engine; no Razumator compatibility claim",
            "DeepSeek output is advisory and fail-closed; the deterministic rule engine, CP-SAT allocator, and router retain final authority",
            "online API latency is descriptive and is not substituted for the one-second deterministic solver budget",
            "Track-E inference is restricted to S2, load 0.80, high disturbance, one trace per held-out layout, and 1200 ticks",
            "no generalization is claimed across loads, disturbance regimes, repeated traces, or physical warehouses",
        ],
    }
    draft_path = TRACK / "protocol" / "draft_protocol_before_validation_pilot.json"
    draft_path.write_text(json.dumps(draft, indent=2, sort_keys=True), encoding="utf-8")

    manifest = {
        "status": "prepared_before_validation_api_pilot",
        "prepared_utc": datetime.now(timezone.utc).isoformat(),
        "main_source_sha256": main_source_digest(),
        "main_source_matches_freeze": True,
        "llm_source_sha256": llm_source_digest(),
        "llm_source_inventory": _source_inventory(),
        "model_contract": {
            "model": DEFAULT_MODEL,
            "thinking_mode": DEFAULT_THINKING_MODE,
            "max_tokens": DEFAULT_MAX_TOKENS,
            "prompt_schema_version": PROMPT_SCHEMA_VERSION,
            "profiles": [FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE],
        },
        "files": {
            "generated_events": {"path": generated_events.relative_to(ROOT).as_posix(), "sha256": sha256(generated_events)},
            "generated_validation": {"path": validation_report.relative_to(ROOT).as_posix(), "sha256": sha256(validation_report)},
            "validation_pilot_events": {"path": pilot_path.relative_to(ROOT).as_posix(), "sha256": sha256(pilot_path)},
            "track_g_test_events": {"path": test_path.relative_to(ROOT).as_posix(), "sha256": sha256(test_path)},
            "e2e_events": {"path": e2e_events.relative_to(ROOT).as_posix(), "sha256": sha256(e2e_events)},
            "e2e_config": {"path": e2e_config.relative_to(ROOT).as_posix(), "sha256": sha256(e2e_config)},
            "draft_protocol": {"path": draft_path.relative_to(ROOT).as_posix(), "sha256": sha256(draft_path)},
            "pilot_analyzer": {"path": "scripts/41_analyze_llm_validation_pilot_v14.py", "sha256": sha256(ROOT / "scripts" / "41_analyze_llm_validation_pilot_v14.py")},
            "analysis_common": {"path": "scripts/llm_v11_common.py", "sha256": sha256(ROOT / "scripts" / "llm_v11_common.py")},
            "prefetch_identity_gate": {"path": "scripts/39_prefetch_identity_gate_v14.py", "sha256": sha256(ROOT / "scripts" / "39_prefetch_identity_gate_v14.py")},
            "validation_request_plan": {"path": plan_paths["validation"].relative_to(ROOT).as_posix(), "sha256": sha256(plan_paths["validation"])},
            "track_g_request_plan": {"path": plan_paths["track_g"].relative_to(ROOT).as_posix(), "sha256": sha256(plan_paths["track_g"])},
            "track_e_request_plan": {"path": plan_paths["track_e"].relative_to(ROOT).as_posix(), "sha256": sha256(plan_paths["track_e"])},
        },
        "case_ids": {
            "validation_facts": case_ids_sha256(pilot_records),
            "validation_rules": case_ids_sha256(pilot_rules),
            "track_g_facts": case_ids_sha256(test_records),
            "track_g_rules": case_ids_sha256(test_rules),
            "track_e_facts": case_ids_sha256(e2e_records),
            "track_e_rules": case_ids_sha256(e2e_rules),
        },
        "request_budget": {
            "validation_pilot": len(pilot_records) + len(pilot_rules),
            "track_g_test": len(test_records) + len(test_rules),
            "track_e_test": len(e2e_records) + len(e2e_rules),
            "total_test_after_pilot": len(test_records) + len(test_rules) + len(e2e_records) + len(e2e_rules),
        },
        "api_execution": {"workers": 8, "resumable_cache": True, "invalid_responses_cached": True},
        "counts": {
            "validation_pilot_by_event_type": dict(Counter(item["event_type"] for item in pilot_records)),
            "validation_pilot_facts": len(pilot_records),
            "validation_pilot_rules": len(pilot_rules),
            "track_g_facts": len(test_records),
            "track_g_rules": len(test_rules),
            "track_e_facts": len(e2e_records),
            "track_e_rules": len(e2e_rules),
        },
    }
    manifest_path = TRACK / "protocol" / "validation_pilot_freeze_manifest.json"
    if manifest_path.exists():
        previous = read_json(manifest_path)
        previous_without_time = {key: value for key, value in previous.items() if key != "prepared_utc"}
        current_without_time = {key: value for key, value in manifest.items() if key != "prepared_utc"}
        if previous_without_time != current_without_time:
            raise RuntimeError("Existing validation-pilot freeze differs; increment the source/protocol version")
        manifest = previous
    else:
        manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "status": "ready_for_independent_pre_api_review",
        "pilot_requests": manifest["request_budget"]["validation_pilot"],
        "test_requests_after_pilot": manifest["request_budget"]["total_test_after_pilot"],
        "track_g_map_families": 12,
        "llm_source_sha256": manifest["llm_source_sha256"],
        "manifest": str(manifest_path),
    }, indent=2))


if __name__ == "__main__":
    main()
