from __future__ import annotations

import gzip
import hashlib
import json
import math
import random
import statistics
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from llm_v11_common import (
    BOOTSTRAP_REPLICATES,
    BOOTSTRAP_SEED,
    cache_usage,
    case_ids_sha256,
    equal_family_summary,
    quantile,
    read_json,
    read_jsonl,
    sha256,
    verify_metric_binding,
)
from mrta_llm_v14.cache_audit import audit_cache
from mrta_llm_v14.cache_seal import verify_cache_seal
from mrta_llm_v14.experiment import _source_digest
from mrta_llm_v14.grounding import DEFAULT_MODEL, DEFAULT_THINKING_MODE, PROMPT_SCHEMA_VERSION
from mrta_llm_v14.semantic import evaluate_events
from mrta_llm_v14.shield import FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE, RULE_EVENT_TYPES


TRACK = ROOT / "llm_track_v1_4"


def audit_frozen_inputs(freeze: dict[str, Any], protocol: dict[str, Any]) -> dict[str, bool]:
    checks = {
        "source_sha256": _source_digest() == freeze["source_sha256"],
        "protocol_sha256": sha256(TRACK / "protocol" / "test_protocol.json") == freeze["protocol_sha256"],
        "analysis_script_sha256": sha256(Path(__file__)) == freeze["analysis_script_sha256"],
        "analysis_common_sha256": sha256(ROOT / "scripts" / "llm_v11_common.py") == freeze["analysis_common_sha256"],
        "config_sha256": sha256(Path(freeze["config_path"])) == freeze["config_sha256"],
        "track_g_event_sha256": sha256(Path(freeze["track_g_events_path"])) == freeze["track_g_events_sha256"],
        "track_e_event_sha256": sha256(Path(freeze["track_e_events_path"])) == freeze["track_e_events_sha256"],
        "track_g_request_plan_sha256": sha256(Path(freeze["track_g_request_plan_path"])) == freeze["track_g_request_plan_sha256"],
        "track_e_request_plan_sha256": sha256(Path(freeze["track_e_request_plan_path"])) == freeze["track_e_request_plan_sha256"],
        "prefetch_identity_gate_sha256": sha256(ROOT / "scripts" / "39_prefetch_identity_gate_v14.py") == freeze["prefetch_identity_gate_sha256"],
        "model": freeze["model"] == DEFAULT_MODEL == protocol["model"],
        "thinking_mode": freeze["thinking_mode"] == DEFAULT_THINKING_MODE == protocol["thinking_mode"],
        "prompt_schema_version": freeze["prompt_schema_version"] == PROMPT_SCHEMA_VERSION == protocol["prompt_schema_version"],
    }
    if not all(checks.values()):
        raise RuntimeError(f"Frozen-input audit failed: {[key for key, value in checks.items() if not value]}")
    return checks


def audit_e2e_artifacts(run_dir: Path, freeze: dict[str, Any]) -> dict[str, Any]:
    manifest = read_json(run_dir / "run_manifest.json")
    rows = read_jsonl(run_dir / "episode_results.jsonl")
    failures: list[str] = []
    max_stage_b_ms = 0.0
    stage_b_attempts = 0
    event_commit_counts: dict[str, int] = defaultdict(int)
    authenticated_fallback_audit_count = 0
    for row in rows:
        task_id = row["task"]["task_id"]
        episode_path = run_dir / "episodes" / f"{task_id}.json"
        audit_path = run_dir / "audits" / f"{task_id}.jsonl.gz"
        if not episode_path.exists() or not audit_path.exists():
            failures.append(f"missing_artifact:{task_id}")
            continue
        episode = read_json(episode_path)
        if episode != row:
            failures.append(f"aggregate_episode_mismatch:{task_id}")
        payload_hash = hashlib.sha256(
            json.dumps(episode, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        with gzip.open(audit_path, "rt", encoding="utf-8") as stream:
            audit = [json.loads(line) for line in stream if line.strip()]
        summaries = [item for item in audit if item.get("kind") == "episode_summary"]
        completions = [item for item in audit if item.get("kind") == "audit_complete"]
        if len(summaries) != 1 or summaries[0].get("result") != episode["result"]:
            failures.append(f"episode_summary_mismatch:{task_id}")
        if len(completions) != 1:
            failures.append(f"audit_complete_count:{task_id}")
        else:
            completion = completions[0]
            if completion.get("payload_sha256") != payload_hash:
                failures.append(f"payload_hash_mismatch:{task_id}")
            if completion.get("source_sha256") != freeze["source_sha256"]:
                failures.append(f"source_hash_mismatch:{task_id}")
            if completion.get("audit_schema") != freeze["audit_schema"]:
                failures.append(f"audit_schema_mismatch:{task_id}")
        for item in audit:
            if item.get("kind") == "stage_b_attempt":
                stage_b_attempts += 1
                max_stage_b_ms = max(max_stage_b_ms, float(item["latency_ms"]))
            elif item.get("kind") == "event_commit":
                event_commit_counts[str(item["event_type"])] += 1
                authenticated_fallback_audit_count += int(bool(item.get("authenticated_fallback")))

    task_payload = [row["task"] for row in sorted(rows, key=lambda item: item["task"]["task_id"])]
    task_digest = hashlib.sha256(
        json.dumps(task_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    observed_task_ids = {row["task"]["task_id"] for row in rows}
    expected_cache_manifest = {
        "path": str(Path(freeze["track_e_cache_seal_path"]).resolve()),
        "sha256": sha256(Path(freeze["track_e_cache_seal_path"])),
    }
    checks = {
        "manifest_complete": manifest.get("status") == "complete",
        "manifest_source_match": manifest.get("source_sha256") == freeze["source_sha256"],
        "manifest_config_match": manifest.get("config_sha256") == freeze["config_sha256"],
        "manifest_freeze_match": manifest.get("freeze_manifest_sha256") == sha256(TRACK / "protocol" / "test_freeze_manifest.json"),
        "manifest_cache_seal_match": manifest.get("cache_manifests") == [expected_cache_manifest],
        "row_count_match": len(rows) == freeze["task_count"],
        "task_identity_set_match": observed_task_ids == set(freeze["task_ids"]),
        "task_payload_digest_match": task_digest == freeze["task_ids_sha256"],
        "zero_artifact_failures": not failures,
        "fallback_counter_matches_audit": authenticated_fallback_audit_count
        == sum(int(row["result"]["grounding_authenticated_fallbacks"]) for row in rows),
    }
    return {
        "status": "pass" if all(checks.values()) else "fail",
        "checks": checks,
        "failure_count": len(failures),
        "failure_examples": failures[:50],
        "row_count": len(rows),
        "audit_stage_b_attempts": stage_b_attempts,
        "max_stage_b_latency_ms": max_stage_b_ms,
        "event_commit_counts": dict(sorted(event_commit_counts.items())),
        "authenticated_fallback_audit_count": authenticated_fallback_audit_count,
        "rows": rows,
    }


def metric(row: dict[str, Any], name: str) -> float:
    result = row["result"]
    completed = max(1, int(result["cargo_completed"]))
    if name == "deadline":
        return float(result["deadline_miss_rate"])
    if name == "distance":
        return float(result["travel_distance_per_cargo"])
    if name == "energy":
        return float(result["energy_proxy"]) / completed
    if name == "low_friction":
        return float(result["low_friction_exposure_ticks"]) / completed
    raise ValueError(name)


def by_seed_method(rows: list[dict[str, Any]]) -> dict[int, dict[str, dict[str, Any]]]:
    grouped: dict[int, dict[str, dict[str, Any]]] = defaultdict(dict)
    for row in rows:
        seed = int(row["task"]["seed"])
        method = str(row["task"]["method"])
        if method in grouped[seed]:
            raise RuntimeError(f"Duplicate seed-method cell: {seed}, {method}")
        grouped[seed][method] = row
    return dict(grouped)


def paired_values(
    grouped: dict[int, dict[str, dict[str, Any]]],
    intervention: str,
    baseline: str,
    transform: Callable[[dict[str, Any], dict[str, Any]], float],
) -> list[tuple[int, float]]:
    return [
        (seed, transform(methods[intervention], methods[baseline]))
        for seed, methods in sorted(grouped.items())
    ]


def one_sided_bootstrap_upper(values: list[float]) -> float:
    rng = random.Random(BOOTSTRAP_SEED)
    means = [
        statistics.fmean(values[rng.randrange(len(values))] for _ in values)
        for _ in range(BOOTSTRAP_REPLICATES)
    ]
    return quantile(means, 0.95)


def noninferiority(
    grouped: dict[int, dict[str, dict[str, Any]]],
    intervention: str,
    baseline: str,
    protocol: dict[str, Any],
) -> dict[str, Any]:
    definitions = {
        "deadline": (
            float(protocol["deadline_absolute_harm_margin"]),
            "absolute difference in deadline-miss rate",
            lambda a, b: metric(a, "deadline") - metric(b, "deadline"),
        ),
        "distance": (
            float(protocol["distance_relative_harm_margin"]),
            "relative difference in travel distance per completed cargo",
            lambda a, b: metric(a, "distance") / metric(b, "distance") - 1.0,
        ),
        "energy": (
            float(protocol["energy_relative_harm_margin"]),
            "relative difference in energy proxy per completed cargo",
            lambda a, b: metric(a, "energy") / metric(b, "energy") - 1.0,
        ),
    }
    components: dict[str, Any] = {}
    for name, (margin, estimand, transform) in definitions.items():
        pairs = paired_values(grouped, intervention, baseline, transform)
        values = [value for _, value in pairs]
        upper = one_sided_bootstrap_upper(values)
        components[name] = {
            "estimand": estimand,
            "margin": margin,
            "mean_harm": statistics.fmean(values),
            "one_sided_95_layout_bootstrap_upper": upper,
            "pass": upper < margin,
            "by_layout_seed": {str(seed): value for seed, value in pairs},
        }
    return {
        "intervention": intervention,
        "baseline": baseline,
        "alpha_one_sided": float(protocol["alpha_one_sided"]),
        "independent_unit": "held-out layout seed",
        "components": components,
        "intersection_union_pass": all(item["pass"] for item in components.values()),
    }


def exact_sign_test(grouped: dict[int, dict[str, dict[str, Any]]], minimum_wins: int) -> dict[str, Any]:
    pairs = paired_values(
        grouped,
        "deepseek_rules_cp_sat",
        "deepseek_facts_cp_sat",
        lambda a, b: metric(a, "low_friction") - metric(b, "low_friction"),
    )
    wins = sum(value < 0 for _, value in pairs)
    ties = sum(value == 0 for _, value in pairs)
    losses = sum(value > 0 for _, value in pairs)
    n = len(pairs)
    p_value = sum(math.comb(n, k) for k in range(wins, n + 1)) / (2**n)
    return {
        "estimand": "layout-level difference in low-friction exposure ticks per completed cargo",
        "wins": wins,
        "ties_counted_as_no_improvement": ties,
        "losses": losses,
        "n_layouts": n,
        "minimum_strict_wins": minimum_wins,
        "exact_one_sided_p": p_value,
        "alpha": 0.05,
        "mean_difference": statistics.fmean(value for _, value in pairs),
        "supported": p_value < 0.05 and wins >= minimum_wins,
        "by_layout_seed": {str(seed): value for seed, value in pairs},
    }


def main() -> None:
    freeze_path = TRACK / "protocol" / "test_freeze_manifest.json"
    protocol_path = TRACK / "protocol" / "test_protocol.json"
    freeze = read_json(freeze_path)
    protocol = read_json(protocol_path)
    if freeze["status"] != "frozen_before_main" or freeze["main_results_opened"] is not False:
        raise RuntimeError("Held-out test was not frozen in an unopened state")
    input_checks = audit_frozen_inputs(freeze, protocol)

    g_events = Path(freeze["track_g_events_path"])
    e_events = Path(freeze["track_e_events_path"])
    g_records = read_jsonl(g_events)
    e_records = read_jsonl(e_events)
    g_rule_records = [item for item in g_records if item["event_type"] in RULE_EVENT_TYPES]
    e_rule_records = [item for item in e_records if item["event_type"] in RULE_EVENT_TYPES]
    identity_checks = {
        "track_g_facts": case_ids_sha256(g_records) == freeze["track_g_fact_case_ids_sha256"],
        "track_g_rules": case_ids_sha256(g_rule_records) == freeze["track_g_rule_case_ids_sha256"],
        "track_e_facts": case_ids_sha256(e_records) == freeze["track_e_fact_case_ids_sha256"],
        "track_e_rules": case_ids_sha256(e_rule_records) == freeze["track_e_rule_case_ids_sha256"],
    }
    if not all(identity_checks.values()):
        raise RuntimeError("Frozen case-identity audit failed")

    g_cache_dir = TRACK / "cache" / "track_g_test"
    e_cache_dir = TRACK / "cache" / "e2e_test"
    g_plan_path = Path(freeze["track_g_request_plan_path"])
    e_plan_path = Path(freeze["track_e_request_plan_path"])
    g_seal_path = Path(freeze["track_g_cache_seal_path"])
    e_seal_path = Path(freeze["track_e_cache_seal_path"])
    profiles = [FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE]
    g_cache_seal = verify_cache_seal(g_seal_path, g_plan_path, g_events, g_cache_dir)
    e_cache_seal = verify_cache_seal(e_seal_path, e_plan_path, e_events, e_cache_dir)
    g_cache = audit_cache(
        g_events, g_cache_dir, DEFAULT_MODEL, profiles, DEFAULT_THINKING_MODE, g_seal_path,
    )
    e_cache = audit_cache(
        e_events, e_cache_dir, DEFAULT_MODEL, profiles, DEFAULT_THINKING_MODE, e_seal_path,
    )
    facts = evaluate_events(
        g_events, "deepseek_cache", g_cache_dir, DEFAULT_MODEL,
        profile=FACTS_ONLY_PROFILE, thinking_mode=DEFAULT_THINKING_MODE,
        sealed_manifest_path=g_seal_path,
    )
    rules = evaluate_events(
        g_events, "deepseek_cache", g_cache_dir, DEFAULT_MODEL,
        profile=RESTRICTED_RULE_PROFILE, thinking_mode=DEFAULT_THINKING_MODE,
        sealed_manifest_path=g_seal_path,
    )
    verify_metric_binding(
        facts, g_events, FACTS_ONLY_PROFILE, DEFAULT_MODEL, DEFAULT_THINKING_MODE,
        PROMPT_SCHEMA_VERSION, g_records,
    )
    verify_metric_binding(
        rules, g_events, RESTRICTED_RULE_PROFILE, DEFAULT_MODEL, DEFAULT_THINKING_MODE,
        PROMPT_SCHEMA_VERSION, g_rule_records,
    )
    facts_summary = {
        field: equal_family_summary(facts["case_results"], field)
        for field in ("schema_valid", "semantic_exact", "shield_accept", "response_invalid")
    }
    rules_summary = {
        field: equal_family_summary(rules["case_results"], field)
        for field in (
            "schema_valid", "semantic_exact", "shield_accept", "response_invalid",
            "rule_template_correct", "rule_operation_exact",
        )
    }
    thresholds = protocol["test_track_g"]["publication_gates"]
    def mean(summary: dict[str, Any], field: str) -> float:
        return float(summary[field]["cluster_equal_weight_mean"])
    software_invariants_hold = (
        facts["software_invariants"]["post_shield_incorrect_commit_count"] == 0
        and rules["software_invariants"]["post_shield_incorrect_commit_count"] == 0
        and facts["software_invariants"]["correct_proposal_rejected_count"] == 0
        and rules["software_invariants"]["correct_proposal_rejected_count"] == 0
    )
    g_execution_checks = {
        "cache_metadata_complete": g_cache["status"] == "pass"
        and g_cache["complete_cache_entries"] == g_cache["required_cache_entries"],
        "cache_cryptographic_seal": g_cache_seal["status"] == "pass",
        "frozen_case_identity": all(identity_checks[key] for key in ("track_g_facts", "track_g_rules")),
        "software_invariants_hold": software_invariants_hold,
    }
    g_performance_checks = {
        "facts_syntactic": mean(facts_summary, "schema_valid") >= thresholds["facts_syntactic_min"],
        "facts_full_exact": mean(facts_summary, "semantic_exact") >= thresholds["facts_full_exact_min"],
        "facts_accepted_availability": mean(facts_summary, "shield_accept") >= thresholds["facts_accepted_availability_min"],
        "facts_invalid_response": mean(facts_summary, "response_invalid") <= thresholds["facts_invalid_response_max"],
        "rules_syntactic": mean(rules_summary, "schema_valid") >= thresholds["rules_syntactic_min"],
        "rules_template_selection": mean(rules_summary, "rule_template_correct") >= thresholds["rules_template_selection_min"],
        "rules_operation_exact": mean(rules_summary, "rule_operation_exact") >= thresholds["rules_operation_exact_min"],
        "rules_full_exact": mean(rules_summary, "semantic_exact") >= thresholds["rules_full_exact_min"],
        "rules_accepted_availability": mean(rules_summary, "shield_accept") >= thresholds["rules_accepted_availability_min"],
        "rules_invalid_response": mean(rules_summary, "response_invalid") <= thresholds["rules_invalid_response_max"],
    }

    run_dir = TRACK / "runs" / freeze["run_name"]
    artifact_audit = audit_e2e_artifacts(run_dir, freeze)
    rows = artifact_audit.pop("rows")
    grouped = by_seed_method(rows)
    expected_methods = {
        "dynamic_facts_cp_sat", "dynamic_rules_cp_sat",
        "deepseek_facts_cp_sat", "deepseek_rules_cp_sat",
    }
    cell_complete = len(grouped) == 15 and all(set(methods) == expected_methods for methods in grouped.values())
    hard_violations = sum(int(row["result"]["hard_violations"]) for row in rows)
    pending = sum(int(row["result"]["cargo_pending"]) for row in rows)
    primary_protocol = protocol["test_track_e"]["primary_noninferiority"]
    primary_ni = noninferiority(grouped, "deepseek_rules_cp_sat", "dynamic_rules_cp_sat", primary_protocol)
    secondary_ni = noninferiority(grouped, "deepseek_facts_cp_sat", "dynamic_facts_cp_sat", primary_protocol)
    mechanism = exact_sign_test(
        grouped,
        int(protocol["test_track_e"]["mechanism_contrast"]["minimum_strict_wins"]),
    )
    e_execution_checks = {
        "cache_metadata_complete": e_cache["status"] == "pass"
        and e_cache["complete_cache_entries"] == e_cache["required_cache_entries"],
        "cache_cryptographic_seal": e_cache_seal["status"] == "pass",
        "frozen_case_identity": all(identity_checks[key] for key in ("track_e_facts", "track_e_rules")),
        "artifact_audit": artifact_audit["status"] == "pass",
        "matched_15_layout_x_4_method_cells": cell_complete,
        "hard_violations_zero": hard_violations == 0,
        "terminal_pending_cargo_zero": pending == 0,
        "stage_b_max_within_1050_ms": artifact_audit["max_stage_b_latency_ms"] <= 1050.0,
    }
    execution_valid = all(input_checks.values()) and all(identity_checks.values()) \
        and all(g_execution_checks.values()) and all(e_execution_checks.values())
    grounding_supported = all(g_performance_checks.values())
    primary_supported = bool(primary_ni["intersection_union_pass"])
    mechanism_supported = bool(mechanism["supported"])
    publication_supported = execution_valid and grounding_supported and primary_supported and mechanism_supported

    result = {
        "status": "analysis_complete" if execution_valid else "execution_invalid",
        "protocol_id": freeze["protocol_id"],
        "execution_valid": execution_valid,
        "track_g_grounding_supported": grounding_supported,
        "primary_noninferiority_supported": primary_supported,
        "restricted_rule_mechanism_supported": mechanism_supported,
        "publication_evidence_status": "supported_under_preregistered_scope" if publication_supported else "not_supported_under_all_preregistered_gates",
        "frozen_input_checks": input_checks,
        "case_identity_checks": identity_checks,
        "track_g": {
            "execution_checks": g_execution_checks,
            "performance_checks": g_performance_checks,
            "thresholds": thresholds,
            "estimand": protocol["test_track_g"]["estimand"],
            "facts_equal_map_family_summary": facts_summary,
            "rules_equal_map_family_summary": rules_summary,
            "facts_pooled_descriptive": {key: facts[key] for key in (
                "syntactic_validity", "semantic_exact_match", "invalid_response_rate",
                "accepted_availability_rate", "operation_micro_f1", "per_event_type",
            )},
            "rules_pooled_descriptive": {key: rules[key] for key in (
                "syntactic_validity", "semantic_exact_match", "invalid_response_rate",
                "accepted_availability_rate", "rule_template_selection_accuracy",
                "rule_operation_exact_match", "operation_micro_f1", "per_event_type",
            )},
            "software_invariants": {
                "interpretation": "deterministic software contract, not an empirical neural-safety estimate",
                "facts": facts["software_invariants"],
                "rules": rules["software_invariants"],
            },
            "cache_audit": g_cache,
            "cache_seal_audit": g_cache_seal,
        },
        "track_e": {
            "execution_checks": e_execution_checks,
            "estimand": protocol["test_track_e"]["estimand"],
            "artifact_audit": artifact_audit,
            "hard_violations": hard_violations,
            "terminal_pending_cargo": pending,
            "primary_noninferiority": primary_ni,
            "secondary_noninferiority": secondary_ni,
            "restricted_rule_mechanism": mechanism,
            "cache_audit": e_cache,
            "cache_seal_audit": e_cache_seal,
            "mechanism_claim_boundary": protocol["test_track_e"]["mechanism_claim_boundary"],
            "grounding_totals": {
                method: {
                    "attempts": sum(int(row["result"]["grounding_attempts"]) for row in rows if row["task"]["method"] == method),
                    "accepted": sum(int(row["result"]["grounding_shield_accepted"]) for row in rows if row["task"]["method"] == method),
                    "rejected": sum(int(row["result"]["grounding_rejected"]) for row in rows if row["task"]["method"] == method),
                    "rules_accepted": sum(int(row["result"]["grounding_rule_accepted"]) for row in rows if row["task"]["method"] == method),
                    "authenticated_wms_fallbacks": sum(int(row["result"]["grounding_authenticated_fallbacks"]) for row in rows if row["task"]["method"] == method),
                }
                for method in ("deepseek_facts_cp_sat", "deepseek_rules_cp_sat")
            },
        },
        "api_measurements": cache_usage(
            TRACK / "cache" / "validation_pilot",
            g_cache_dir,
            e_cache_dir,
        ),
        "reporting_separation": {
            "execution_validity": execution_valid,
            "grounding_benchmark_support": grounding_supported,
            "noninferiority_support": primary_supported,
            "mechanism_support": mechanism_supported,
        },
        "evidence_boundary": freeze["evidence_boundary"],
    }
    runs = TRACK / "runs"
    (runs / "track_g_facts_metrics_recomputed.json").write_text(
        json.dumps(facts, indent=2, sort_keys=True), encoding="utf-8",
    )
    (runs / "track_g_rules_metrics_recomputed.json").write_text(
        json.dumps(rules, indent=2, sort_keys=True), encoding="utf-8",
    )
    output = runs / "llm_tracks_final_analysis.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "execution_valid": execution_valid,
        "track_g_grounding_supported": grounding_supported,
        "primary_noninferiority_supported": primary_supported,
        "restricted_rule_mechanism_supported": mechanism_supported,
        "publication_evidence_status": result["publication_evidence_status"],
        "output": str(output),
    }, indent=2))
    raise SystemExit(0 if execution_valid else 1)


if __name__ == "__main__":
    main()
