from __future__ import annotations

import json
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from mrta_llm_v14.shield import FACTS_ONLY_PROFILE, RESTRICTED_RULE_PROFILE, compile_expected_operations


TRACK = ROOT / "llm_track_v1_4"


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def mismatch_code(expected: list[dict[str, Any]], proposed: list[dict[str, Any]] | None) -> str:
    if proposed is None:
        return "invalid_response"
    if canonical(expected) == canonical(proposed) or canonical(expected) == canonical(list(reversed(proposed))):
        return "exact"
    expected_ops = [item.get("op") for item in expected]
    proposed_ops = [item.get("op") for item in proposed]
    if sorted(expected_ops) != sorted(proposed_ops):
        return f"operation_type:{proposed_ops}!=expected:{expected_ops}"
    for gold in expected:
        matching = [item for item in proposed if item.get("op") == gold.get("op")]
        if not matching:
            continue
        item = matching[0]
        if gold.get("op") == "insert_rule":
            rule = item.get("rule", {})
            gold_rule = gold["rule"]
            for field in ("rule_id", "ttl", "temporary", "body", "head"):
                if canonical(rule.get(field)) != canonical(gold_rule.get(field)):
                    return f"rule_{field}_mismatch"
        else:
            if canonical(item.get("key")) != canonical(gold.get("key")):
                return "supersede_key_mismatch"
            atom = item.get("atom", {})
            gold_atom = gold["atom"]
            if atom.get("predicate") != gold_atom.get("predicate"):
                return "fact_predicate_mismatch"
            if canonical(atom.get("args")) != canonical(gold_atom.get("args")):
                return "fact_args_mismatch"
    return "other_structural_mismatch"


def main() -> None:
    events = {
        record["case_id"]: record
        for record in (
            json.loads(line)
            for line in (TRACK / "validation_pilot_events_v1_1.jsonl").read_text(encoding="utf-8").splitlines()
            if line.strip()
        )
    }
    plan = json.loads(
        (TRACK / "protocol" / "request_plans" / "validation_pilot_request_plan.json").read_text(encoding="utf-8")
    )
    counts: dict[str, Counter[str]] = defaultdict(Counter)
    examples: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for entry in plan["entries"]:
        event = events[entry["case_id"]]
        profile = entry["profile"]
        cache = json.loads(
            (TRACK / "cache" / "validation_pilot" / f"{entry['cache_key']}.json").read_text(encoding="utf-8")
        )
        expected = compile_expected_operations(
            event["event_type"], event["payload"], event["event_id"], profile,
        )
        candidate = cache.get("candidate")
        proposed = candidate.get("operations") if candidate else None
        code = mismatch_code(expected, proposed)
        identity = f"{profile}:{event['event_type']}"
        counts[identity][code] += 1
        if code != "exact" and len(examples[identity]) < 3:
            examples[identity].append({
                "case_id": event["case_id"],
                "text": event["text"],
                "code": code,
                "expected": expected,
                "proposed": proposed,
                "raw_content": cache.get("raw_content"),
            })
    result = {
        "counts": {key: dict(value) for key, value in sorted(counts.items())},
        "examples": dict(sorted(examples.items())),
    }
    output = TRACK / "runs" / "validation_pilot_error_diagnosis.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({"status": "ok", "counts": result["counts"], "output": str(output)}, indent=2))


if __name__ == "__main__":
    main()
