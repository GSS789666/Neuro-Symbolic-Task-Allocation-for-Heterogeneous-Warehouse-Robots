from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from statistics import NormalDist
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
TRACK = ROOT / "llm_track_v1_4"
ANALYSIS_PATH = TRACK / "runs" / "llm_tracks_final_analysis.json"
RUN_DIR = TRACK / "runs" / "deepseek_e2e_test_v1_4"
COMPAT_VALIDATION_PATH = RUN_DIR / "posthoc_compatibility_validation_report.json"
OUTPUT_DIR = TRACK / "publication" / "derived"


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise RuntimeError(f"Refusing to write an empty publication table: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def wilson_interval(successes: int, total: int, alpha: float = 0.05) -> tuple[float, float]:
    if total <= 0:
        raise ValueError("Wilson interval requires a positive denominator")
    z = NormalDist().inv_cdf(1.0 - alpha / 2.0)
    p = successes / total
    denominator = 1.0 + z * z / total
    center = (p + z * z / (2.0 * total)) / denominator
    half_width = z * math.sqrt(p * (1.0 - p) / total + z * z / (4.0 * total * total)) / denominator
    return max(0.0, center - half_width), min(1.0, center + half_width)


def rounded_successes(rate: float, total: int) -> int:
    successes = round(rate * total)
    if not math.isclose(successes / total, rate, rel_tol=0.0, abs_tol=1e-12):
        raise RuntimeError(f"Rate {rate} is not an exact count ratio for n={total}")
    return successes


def export_grounding(analysis: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    profiles = [
        ("facts_only", "Facts only", analysis["track_g"]["facts_pooled_descriptive"]),
        ("restricted_rule", "Restricted rule", analysis["track_g"]["rules_pooled_descriptive"]),
    ]
    for profile, profile_label, payload in profiles:
        for event_type, values in payload["per_event_type"].items():
            total = int(values["total"])
            rate = float(values["semantic_exact_match"])
            successes = rounded_successes(rate, total)
            ci_low, ci_high = wilson_interval(successes, total)
            rows.append(
                {
                    "profile": profile,
                    "profile_label": profile_label,
                    "event_type": event_type,
                    "event_label": event_type.replace("_", " ").title(),
                    "total": total,
                    "semantic_exact_successes": successes,
                    "semantic_exact_rate": rate,
                    "wilson_95_low": ci_low,
                    "wilson_95_high": ci_high,
                    "syntactic_validity": float(values["syntactic_validity"]),
                    "shield_accept_rate": float(values["shield_accept_rate"]),
                    "invalid_response_rate": float(values["invalid_response_rate"]),
                    "proposal_error_rate": float(values["proposal_error_rate"]),
                    "rule_operation_exact_match": values["rule_operation_exact_match"],
                    "rule_template_selection_accuracy": values["rule_template_selection_accuracy"],
                }
            )
    write_csv(OUTPUT_DIR / "track_g_event_profile_metrics.csv", rows)
    return rows


def result_metric(row: dict[str, Any], name: str) -> float:
    result = row["result"]
    completed = max(1, int(result["cargo_completed"]))
    if name == "deadline":
        return float(result["deadline_miss_rate"])
    if name == "distance":
        return float(result["travel_distance_per_cargo"])
    if name == "energy":
        return float(result["energy_proxy"]) / completed
    if name == "low_friction":
        return float(result["low_friction_exposure_ticks"]) / completed
    raise ValueError(name)


def export_track_e(analysis: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    noninferiority_rows: list[dict[str, Any]] = []
    primary = analysis["track_e"]["primary_noninferiority"]
    labels = {
        "deadline": "Deadline-miss rate",
        "distance": "Travel distance",
        "energy": "Energy proxy",
    }
    units = {"deadline": "absolute", "distance": "relative", "energy": "relative"}
    for component, payload in primary["components"].items():
        for seed, harm in payload["by_layout_seed"].items():
            noninferiority_rows.append(
                {
                    "layout_seed": int(seed),
                    "component": component,
                    "component_label": labels[component],
                    "harm_unit": units[component],
                    "harm": float(harm),
                    "margin": float(payload["margin"]),
                    "mean_harm": float(payload["mean_harm"]),
                    "one_sided_95_upper": float(payload["one_sided_95_layout_bootstrap_upper"]),
                    "pass": bool(payload["pass"]),
                }
            )
    write_csv(OUTPUT_DIR / "track_e_noninferiority_layout.csv", noninferiority_rows)

    episode_rows = read_jsonl(RUN_DIR / "episode_results.jsonl")
    grouped: dict[int, dict[str, dict[str, Any]]] = {}
    for row in episode_rows:
        seed = int(row["task"]["seed"])
        method = str(row["task"]["method"])
        grouped.setdefault(seed, {})[method] = row
    mechanism_rows: list[dict[str, Any]] = []
    frozen_differences = analysis["track_e"]["restricted_rule_mechanism"]["by_layout_seed"]
    for seed, methods in sorted(grouped.items()):
        facts = result_metric(methods["deepseek_facts_cp_sat"], "low_friction")
        rules = result_metric(methods["deepseek_rules_cp_sat"], "low_friction")
        difference = rules - facts
        if not math.isclose(difference, float(frozen_differences[str(seed)]), rel_tol=0.0, abs_tol=1e-12):
            raise RuntimeError(f"Mechanism difference drift for layout seed {seed}")
        mechanism_rows.append(
            {
                "layout_seed": seed,
                "facts_only": facts,
                "restricted_rule": rules,
                "difference": difference,
            }
        )
    write_csv(OUTPUT_DIR / "track_e_low_friction_pairs.csv", mechanism_rows)
    return noninferiority_rows, mechanism_rows


def export_execution(analysis: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    validation = read_json(COMPAT_VALIDATION_PATH)
    latency_rows: list[dict[str, Any]] = []
    for key, values in validation["stage_b_tail_by_scale_method"].items():
        scale, method = key.split(":", 1)
        latency_rows.append(
            {
                "scale": scale,
                "method": method,
                "attempts": int(values["attempts"]),
                "p95_ms": float(values["p95_ms"]),
                "p99_ms": float(values["p99_ms"]),
                "max_ms": float(values["max_ms"]),
                "timeout_count": int(values["timeout_count"]),
                "fallback_count": int(values["stage_a_fallback_count"]),
            }
        )
    write_csv(OUTPUT_DIR / "track_e_execution_latency.csv", latency_rows)

    api = analysis["api_measurements"]
    api_rows = [
        {
            "response_records": int(api["response_records"]),
            "invalid_response_records": int(api["invalid_response_records"]),
            "latency_n": int(api["latency_n"]),
            "latency_median_ms": float(api["latency_median_ms"]),
            "latency_p95_ms": float(api["latency_p95_ms"]),
            "latency_p99_ms": float(api["latency_p99_ms"]),
            "latency_max_ms": float(api["latency_max_ms"]),
            "prompt_tokens": int(api["usage"]["prompt_tokens"]),
            "completion_tokens": int(api["usage"]["completion_tokens"]),
            "total_tokens": int(api["usage"]["total_tokens"]),
        }
    ]
    write_csv(OUTPUT_DIR / "deepseek_api_summary.csv", api_rows)
    return latency_rows, api_rows


def main() -> None:
    analysis = read_json(ANALYSIS_PATH)
    if not analysis.get("execution_valid"):
        raise RuntimeError("Publication export requires a valid frozen analysis")
    grounding_rows = export_grounding(analysis)
    noninferiority_rows, mechanism_rows = export_track_e(analysis)
    latency_rows, api_rows = export_execution(analysis)
    manifest = {
        "status": "complete",
        "source_analysis": str(ANALYSIS_PATH.resolve()),
        "source_protocol_id": analysis["protocol_id"],
        "row_counts": {
            "grounding": len(grounding_rows),
            "noninferiority": len(noninferiority_rows),
            "mechanism": len(mechanism_rows),
            "latency": len(latency_rows),
            "api": len(api_rows),
        },
    }
    (OUTPUT_DIR / "publication_data_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
