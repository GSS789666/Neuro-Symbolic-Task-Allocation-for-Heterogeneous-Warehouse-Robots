from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.ticker import PercentFormatter
from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
TRACK = ROOT / "llm_track_v1_4"
DERIVED = TRACK / "publication" / "derived"
WORKSPACE = ROOT.parents[4]
FIGURE_DIR = WORKSPACE / "paper_v1" / "figures"
QA_DIR = TRACK / "publication" / "figure_qa"
SCIPILOT_SCRIPTS = Path.home() / ".codex" / "skills" / "scipilot-figure-skill" / "scripts"
sys.path.insert(0, str(SCIPILOT_SCRIPTS))

from export_figure import export_figure  # noqa: E402
from layout_tools import add_panel_labels, finalize_figure  # noqa: E402
from setup_style import setup_style  # noqa: E402
from visual_qa import audit_layout, render_preview  # noqa: E402


OKABE_BLUE = "#0072B2"
OKABE_SKY = "#56B4E9"
OKABE_ORANGE = "#E69F00"
OKABE_VERMILLION = "#D55E00"
GREY = "#7A7A7A"
LIGHT_GREY = "#D9D9D9"


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def base_style() -> dict[str, Any]:
    info = setup_style(journal="general", lang="en", use_sciplots=True)
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Liberation Sans", "DejaVu Sans"],
            "font.size": 7.5,
            "axes.labelsize": 8,
            "axes.titlesize": 8.5,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "axes.linewidth": 0.65,
            "lines.linewidth": 0.9,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
        }
    )
    return info


def clean_axis(ax: plt.Axes) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis="x", color=LIGHT_GREY, linewidth=0.45, linestyle="--", zorder=0)
    ax.set_axisbelow(True)


def save_with_qa(fig: plt.Figure, stem: str, size: tuple[float, float]) -> dict[str, Any]:
    QA_DIR.mkdir(parents=True, exist_ok=True)
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    finalize_figure(fig)
    preview = QA_DIR / f"{stem}_preview.png"
    render_preview(fig, str(preview), dpi=150)
    issues = audit_layout(fig)
    if any(level == "FAIL" for level, _ in issues):
        raise RuntimeError(f"Figure {stem} failed layout QA: {issues}")
    outputs = export_figure(
        fig,
        str(FIGURE_DIR / stem),
        formats=["pdf", "svg", "png"],
        dpi=600,
        size_inches=size,
        grayscale_preview=False,
        tight=False,
        pad_inches=0.04,
    )
    png_path = FIGURE_DIR / f"{stem}.png"
    grayscale_path = FIGURE_DIR / f"{stem}_grayscale.png"
    with Image.open(png_path) as source:
        source.convert("L").save(grayscale_path, dpi=(600, 600))
    outputs.append(str(grayscale_path))
    return {"preview": str(preview), "issues": issues, "outputs": outputs, "size_inches": size}


def figure_grounding() -> dict[str, Any]:
    data = pd.read_csv(DERIVED / "track_g_event_profile_metrics.csv")
    analysis = read_json(TRACK / "runs" / "llm_tracks_final_analysis.json")
    event_order = [
        "blocked_cell",
        "cargo_cancelled",
        "low_friction",
        "robot_unavailable",
        "service_time",
        "moving_congestion",
        "access_restriction",
    ]
    rule_order = ["low_friction", "robot_unavailable", "access_restriction", "moving_congestion"]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.15), constrained_layout=True)
    specifications = [
        (
            axes[0],
            data[data["profile"] == "facts_only"].copy(),
            event_order,
            OKABE_BLUE,
            0.95,
            analysis["track_g"]["facts_equal_map_family_summary"]["semantic_exact"]["cluster_equal_weight_mean"],
            "Facts-only profile",
        ),
        (
            axes[1],
            data[data["profile"] == "restricted_rule"].copy(),
            rule_order,
            OKABE_ORANGE,
            0.90,
            analysis["track_g"]["rules_equal_map_family_summary"]["semantic_exact"]["cluster_equal_weight_mean"],
            "Restricted-rule profile",
        ),
    ]
    for ax, subset, order, color, threshold, aggregate, title in specifications:
        subset = subset.set_index("event_type").loc[order].reset_index()
        y = np.arange(len(subset))
        rates = subset["semantic_exact_rate"].to_numpy(float)
        lower = rates - subset["wilson_95_low"].to_numpy(float)
        upper = subset["wilson_95_high"].to_numpy(float) - rates
        colors = [OKABE_VERMILLION if event == "moving_congestion" and title.startswith("Restricted") else color for event in order]
        ax.errorbar(
            rates,
            y,
            xerr=np.vstack([lower, upper]),
            fmt="none",
            ecolor=GREY,
            elinewidth=0.8,
            capsize=2.0,
            zorder=2,
        )
        ax.scatter(rates, y, c=colors, s=25, marker="o", edgecolors="black", linewidths=0.35, zorder=3)
        for yi, rate, total, event in zip(y, rates, subset["total"].astype(int), order):
            if event == "moving_congestion" and title.startswith("Restricted"):
                ax.annotate(
                    f"{100 * rate:.1f}% (n={total})",
                    (rate, yi),
                    xytext=(8, -10),
                    textcoords="offset points",
                    va="center",
                    ha="left",
                    fontsize=6.3,
                    bbox={"facecolor": "white", "edgecolor": "none", "pad": 0.5, "alpha": 0.9},
                    zorder=4,
                )
                continue
            label_x = min(1.015, rate + 0.018)
            ha = "right" if rate > 0.985 else "left"
            if ha == "right":
                label_x = rate - 0.015
            ax.text(label_x, yi, f"{100 * rate:.1f}% (n={total})", va="center", ha=ha, fontsize=6.3)
        ax.axvline(threshold, color="black", linewidth=0.75, linestyle=(0, (3, 2)), zorder=1)
        ax.set_xlim(0.0, 1.04)
        ax.set_ylim(len(subset) - 0.45, -0.55)
        ax.set_yticks(y)
        ax.set_yticklabels([label.replace(" ", "\n", 1) if len(label) > 18 else label for label in subset["event_label"]])
        ax.xaxis.set_major_formatter(PercentFormatter(1.0, decimals=0))
        ax.set_xlabel("Semantic-exact and shield-accepted responses")
        ax.set_title(f"{title}\nEqual-map-family aggregate: {100 * aggregate:.2f}%")
        clean_axis(ax)
    add_panel_labels(fig, axes=axes, style="upper", x_offset_pt=-15, y_offset_pt=1)
    report = save_with_qa(fig, "Figure_6_deepseek_grounding_by_event", (7.2, 3.15))
    plt.close(fig)
    return report


def plot_ni_panel(ax: plt.Axes, subset: pd.DataFrame, title: str, xlabel: str) -> None:
    subset = subset.sort_values("layout_seed")
    values = 100.0 * subset["harm"].to_numpy(float)
    seeds = subset["layout_seed"].to_numpy(int)
    jitter = np.linspace(-0.17, 0.17, len(values))
    ax.scatter(values, jitter, s=20, color=OKABE_SKY, edgecolors="black", linewidths=0.3, zorder=3)
    for value, yi, seed in zip(values, jitter, seeds):
        if value > 1.0:
            ax.annotate(str(seed), (value, yi), xytext=(2, 1), textcoords="offset points", fontsize=5.2)
    mean = 100.0 * float(subset["mean_harm"].iloc[0])
    upper = 100.0 * float(subset["one_sided_95_upper"].iloc[0])
    margin = 100.0 * float(subset["margin"].iloc[0])
    ax.plot([mean, upper], [0.34, 0.34], color="black", linewidth=1.0, zorder=3)
    ax.plot([upper, upper], [0.30, 0.38], color="black", linewidth=0.8, zorder=3)
    ax.scatter([mean], [0.34], marker="D", s=27, color=OKABE_VERMILLION, edgecolors="black", linewidths=0.35, zorder=4)
    ax.axvline(0.0, color=GREY, linewidth=0.7, linestyle=":", zorder=1)
    ax.axvline(margin, color="black", linewidth=0.8, linestyle=(0, (3, 2)), zorder=1)
    ax.set_xlim(-8.0, 4.5)
    ax.set_ylim(-0.35, 0.52)
    ax.set_yticks([])
    ax.set_xlabel(xlabel)
    ax.set_title(title)
    ax.text(
        0.02,
        0.96,
        f"mean={mean:.2f}; upper={upper:.2f}; margin={margin:.1f}",
        transform=ax.transAxes,
        va="top",
        ha="left",
        fontsize=6.2,
    )
    clean_axis(ax)


def figure_end_to_end() -> dict[str, Any]:
    ni = pd.read_csv(DERIVED / "track_e_noninferiority_layout.csv")
    mechanism = pd.read_csv(DERIVED / "track_e_low_friction_pairs.csv").sort_values("layout_seed")
    analysis = read_json(TRACK / "runs" / "llm_tracks_final_analysis.json")
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.1), constrained_layout=True)
    plot_ni_panel(
        axes[0, 0],
        ni[ni["component"] == "deadline"],
        "Deadline non-inferiority",
        "Absolute harm (percentage points)",
    )
    plot_ni_panel(
        axes[0, 1],
        ni[ni["component"] == "distance"],
        "Distance non-inferiority",
        "Relative harm (%)",
    )
    plot_ni_panel(
        axes[1, 0],
        ni[ni["component"] == "energy"],
        "Energy non-inferiority",
        "Relative harm (%)",
    )

    ax = axes[1, 1]
    x = np.array([0.0, 1.0])
    for _, row in mechanism.iterrows():
        y = np.array([row["facts_only"], row["restricted_rule"]], dtype=float)
        ax.plot(x, y, color="#B8B8B8", linewidth=0.65, zorder=1)
        ax.scatter(x[0], y[0], s=18, color=OKABE_BLUE, edgecolors="black", linewidths=0.25, zorder=2)
        ax.scatter(x[1], y[1], s=18, color=OKABE_ORANGE, edgecolors="black", linewidths=0.25, zorder=2)
    means = mechanism[["facts_only", "restricted_rule"]].mean().to_numpy(float)
    ax.plot(x, means, color="black", linewidth=1.1, zorder=3)
    ax.scatter(x, means, marker="D", s=31, color=[OKABE_BLUE, OKABE_ORANGE], edgecolors="black", linewidths=0.4, zorder=4)
    mech = analysis["track_e"]["restricted_rule_mechanism"]
    ax.text(
        0.50,
        0.96,
        f"15/15 lower; mean difference={mech['mean_difference']:.3f}\nexact one-sided p={mech['exact_one_sided_p']:.2e}",
        transform=ax.transAxes,
        ha="center",
        va="top",
        fontsize=6.4,
    )
    ax.set_xlim(-0.35, 1.35)
    ax.set_ylim(0.0, max(0.26, mechanism["facts_only"].max() * 1.08))
    ax.set_xticks(x)
    ax.set_xticklabels(["DeepSeek\nfacts", "DeepSeek\nrestricted rules"])
    ax.set_ylabel("Low-friction exposure ticks\nper completed cargo")
    ax.set_title("Restricted-rule mechanism")
    ax.grid(axis="y", color=LIGHT_GREY, linewidth=0.45, linestyle="--", zorder=0)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    add_panel_labels(fig, axes=axes.flatten(), style="upper", x_offset_pt=-15, y_offset_pt=1)
    report = save_with_qa(fig, "Figure_7_deepseek_end_to_end", (7.2, 5.1))
    plt.close(fig)
    return report


def main() -> None:
    base_style()
    reports = {
        "Figure_6_deepseek_grounding_by_event": figure_grounding(),
        "Figure_7_deepseek_end_to_end": figure_end_to_end(),
    }
    QA_DIR.mkdir(parents=True, exist_ok=True)
    (QA_DIR / "figure_generation_report.json").write_text(
        json.dumps(reports, indent=2, sort_keys=True), encoding="utf-8"
    )
    print(json.dumps(reports, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
