from __future__ import annotations

import hashlib
import json
import math
import random
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any


BOOTSTRAP_REPLICATES = 20_000
BOOTSTRAP_SEED = 20260826


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def case_ids_sha256(records: list[dict[str, Any]]) -> str:
    payload = "\n".join(sorted(str(record["case_id"]) for record in records))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def quantile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    low = math.floor(position)
    high = math.ceil(position)
    if low == high:
        return ordered[low]
    return ordered[low] * (high - position) + ordered[high] * (position - low)


def equal_family_summary(
    case_results: list[dict[str, Any]],
    field: str,
    *,
    replicates: int = BOOTSTRAP_REPLICATES,
    seed: int = BOOTSTRAP_SEED,
) -> dict[str, Any]:
    by_family: dict[str, list[float]] = defaultdict(list)
    for item in case_results:
        family = item.get("map_family")
        if not family:
            raise RuntimeError(f"Missing map_family for case {item.get('case_id')}")
        value = item.get(field)
        if value is None:
            raise RuntimeError(f"Missing {field} for case {item.get('case_id')}")
        by_family[str(family)].append(float(bool(value)))
    if not by_family:
        raise RuntimeError(f"No cases available for {field}")
    family_rates = {key: statistics.fmean(values) for key, values in sorted(by_family.items())}
    rates = list(family_rates.values())
    rng = random.Random(seed)
    bootstrap = [
        statistics.fmean(rates[rng.randrange(len(rates))] for _ in rates)
        for _ in range(replicates)
    ]
    return {
        "estimand": "equal-weight mean of map-family rates",
        "cluster_count": len(rates),
        "cluster_equal_weight_mean": statistics.fmean(rates),
        "cluster_bootstrap_95_ci": [quantile(bootstrap, 0.025), quantile(bootstrap, 0.975)],
        "family_rates": family_rates,
    }


def verify_metric_binding(
    result: dict[str, Any],
    events_path: Path,
    profile: str,
    model: str,
    thinking_mode: str,
    prompt_schema_version: str,
    expected_records: list[dict[str, Any]],
) -> None:
    checks = {
        "event_file_sha256": result.get("event_file_sha256") == sha256(events_path),
        "case_ids_sha256": result.get("case_ids_sha256") == case_ids_sha256(expected_records),
        "profile": result.get("profile") == profile,
        "model": result.get("model") == model,
        "thinking_mode": result.get("thinking_mode") == thinking_mode,
        "prompt_schema_version": result.get("prompt_schema_version") == prompt_schema_version,
        "count": int(result.get("counts", {}).get("total", -1)) == len(expected_records),
    }
    failures = [name for name, passed in checks.items() if not passed]
    if failures:
        raise RuntimeError(f"Metric provenance binding failed: {', '.join(failures)}")


def cache_usage(*directories: Path) -> dict[str, Any]:
    usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    latencies: list[float] = []
    records = 0
    invalid = 0
    for directory in directories:
        for path in directory.glob("*.json"):
            record = read_json(path)
            if record.get("response_status") not in {"valid", "invalid"}:
                continue
            records += 1
            invalid += int(record["response_status"] == "invalid")
            if record.get("api_latency_ms") is not None:
                latencies.append(float(record["api_latency_ms"]))
            for key in usage:
                usage[key] += int((record.get("usage") or {}).get(key, 0) or 0)
    return {
        "response_records": records,
        "invalid_response_records": invalid,
        "usage": usage,
        "latency_n": len(latencies),
        "latency_median_ms": statistics.median(latencies) if latencies else None,
        "latency_p95_ms": quantile(latencies, 0.95) if latencies else None,
        "latency_p99_ms": quantile(latencies, 0.99) if latencies else None,
        "latency_max_ms": max(latencies) if latencies else None,
    }
