from __future__ import annotations

import json
import hashlib
from pathlib import Path

import pytest

from mrta.confirmatory import exact_binomial_sign_p, freeze_main, holm_adjust
from mrta.experiment import _required_freeze_binding, build_tasks, run_experiment


def test_main_freeze_uses_fifteen_independent_test_layouts_without_changing_task_budget(
    tmp_path: Path,
) -> None:
    config_path = Path("configs/main.json")
    protocol_path = Path("confirmatory_protocol.json")
    config = json.loads(config_path.read_text(encoding="utf-8"))
    tasks = build_tasks(config)
    assert len(tasks) == 1800
    assert len({task.seed for task in tasks}) == 15
    assert {task.split for task in tasks} == {"test"}
    assert {task.episode_index for task in tasks} == {0, 1}
    assert {task.audit_schema for task in tasks} == {"mrta-audit-2.2"}
    frozen = freeze_main(config_path, protocol_path, tmp_path / "freeze.json")
    assert frozen["task_count"] == 1800
    assert frozen["independent_unit"] == "layout_seed"
    assert frozen["main_results_opened"] is False


def test_exact_one_sided_binomial_sign_test_and_holm_adjustment() -> None:
    assert exact_binomial_sign_p([-1.0, -1.0, -1.0], "lower") == pytest.approx(1 / 8)
    assert exact_binomial_sign_p([1.0, 1.0, 1.0], "higher") == pytest.approx(1 / 8)
    assert exact_binomial_sign_p([-1.0, 0.0, -1.0], "lower") == pytest.approx(0.5)
    tied_case = [-1.0] * 7 + [0.0] * 8
    assert exact_binomial_sign_p(tied_case, "lower") > 0.05
    assert holm_adjust([0.01, 0.04, 0.03, 0.002]) == pytest.approx([0.03, 0.06, 0.06, 0.008])


def test_freeze_manifest_is_immutable(tmp_path: Path) -> None:
    output = tmp_path / "freeze.json"
    first = freeze_main(Path("configs/main.json"), Path("confirmatory_protocol.json"), output)
    second = freeze_main(Path("configs/main.json"), Path("confirmatory_protocol.json"), output)
    assert first == second
    output.write_text("{}\n", encoding="utf-8")
    with pytest.raises(RuntimeError, match="Refusing to overwrite"):
        freeze_main(Path("configs/main.json"), Path("confirmatory_protocol.json"), output)


def test_main_launch_rejects_missing_required_freeze_before_creating_run(tmp_path: Path) -> None:
    config_dir = tmp_path / "configs"
    config_dir.mkdir()
    config = json.loads(Path("configs/main.json").read_text(encoding="utf-8"))
    config["required_freeze_manifest"] = "missing-freeze.json"
    config_path = config_dir / "main.json"
    config_path.write_text(json.dumps(config), encoding="utf-8")
    with pytest.raises(RuntimeError, match="freeze manifest is missing"):
        run_experiment(config_path, tmp_path / "runs")
    assert not (tmp_path / "runs" / config["run_name"]).exists()


def test_freeze_rejects_post_hoc_creation_and_binds_before_launch(tmp_path: Path) -> None:
    config_dir = tmp_path / "configs"
    config_dir.mkdir()
    config = json.loads(Path("configs/main.json").read_text(encoding="utf-8"))
    config_path = config_dir / "main.json"
    config_path.write_text(json.dumps(config, sort_keys=True), encoding="utf-8")
    protocol_path = tmp_path / "confirmatory_protocol.json"
    protocol_path.write_text(Path("confirmatory_protocol.json").read_text(encoding="utf-8"), encoding="utf-8")
    freeze_path = tmp_path / "main_freeze_manifest.json"
    frozen = freeze_main(config_path, protocol_path, freeze_path)
    tasks = build_tasks(config)
    binding = _required_freeze_binding(
        config,
        config_path,
        tasks,
        hashlib.sha256(config_path.read_bytes()).hexdigest(),
    )
    assert binding["freeze_manifest_sha256"] == hashlib.sha256(freeze_path.read_bytes()).hexdigest()
    assert binding["protocol_id"] == frozen["protocol_id"]
    late_project = tmp_path / "late"
    (late_project / "configs").mkdir(parents=True)
    late_config_path = late_project / "configs" / "main.json"
    late_config_path.write_text(json.dumps(config, sort_keys=True), encoding="utf-8")
    late_protocol = late_project / "confirmatory_protocol.json"
    late_protocol.write_text(protocol_path.read_text(encoding="utf-8"), encoding="utf-8")
    (late_project / "runs" / config["run_name"]).mkdir(parents=True)
    with pytest.raises(RuntimeError, match="post-hoc Main freeze"):
        freeze_main(late_config_path, late_protocol, late_project / "main_freeze_manifest.json")
