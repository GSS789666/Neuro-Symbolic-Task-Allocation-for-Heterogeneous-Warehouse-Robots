from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

from mrta.experiment import ExperimentTask, _source_digest, _store_task, execute_task
from mrta.validation import validate_run


def _task() -> ExperimentTask:
    return ExperimentTask(
        task_id="audit-integrity-regression",
        scale="S0",
        seed=2217,
        trace_seed=2217,
        episode_index=0,
        method="static_cp_sat",
        load_level=0.65,
        disturbance_level="medium",
        horizon=180,
        timeout_s=1.0,
        split="validation",
        llm_cache="data/deepseek_cache",
        llm_model="deepseek-chat",
        offline_llm=True,
        audit_schema="mrta-audit-2.2",
        source_sha256=_source_digest(),
    )


def _write_minimal_run(
    run_dir: Path,
    task: ExperimentTask,
    payload: dict,
    audit: list[dict],
) -> None:
    episodes_dir = run_dir / "episodes"
    audits_dir = run_dir / "audits"
    episodes_dir.mkdir(parents=True)
    audits_dir.mkdir(parents=True)
    _store_task(task, payload, audit, episodes_dir, audits_dir)
    results_path = run_dir / "episode_results.jsonl"
    results_path.write_text(json.dumps(payload, sort_keys=True) + "\n", encoding="utf-8")
    manifest = {
        "status": "complete",
        "task_count": 1,
        "audit_schema": task.audit_schema,
        "source_sha256": task.source_sha256,
        "source_inventory": {"regression": task.source_sha256},
        "results_sha256": hashlib.sha256(results_path.read_bytes()).hexdigest(),
        "repository": {"commit": "test-only"},
    }
    (run_dir / "run_manifest.json").write_text(
        json.dumps(manifest, sort_keys=True), encoding="utf-8"
    )


def test_execute_task_uses_one_final_result_for_episode_and_audit() -> None:
    task = _task()
    payload, audit = execute_task(task)
    summaries = [record for record in audit if record.get("kind") == "episode_summary"]
    assert len(summaries) == 1
    assert summaries[0]["result"] == payload["result"]
    assert payload["result"]["load_level"] == task.load_level
    assert payload["result"]["disturbance_level"] == task.disturbance_level
    assert payload["result"]["dataset_split"] == task.split


def test_validator_rejects_episode_summary_result_mismatch(tmp_path: Path) -> None:
    task = _task()
    payload, audit = execute_task(task)
    corrupted = copy.deepcopy(audit)
    summary = next(record for record in corrupted if record.get("kind") == "episode_summary")
    summary["result"]["load_level"] = 0.0
    summary["result"]["disturbance_level"] = "unknown"
    summary["result"]["dataset_split"] = "unknown"
    _write_minimal_run(tmp_path, task, payload, corrupted)
    report = validate_run(tmp_path)
    assert any("Episode summary result mismatch" in failure for failure in report["failures"])
