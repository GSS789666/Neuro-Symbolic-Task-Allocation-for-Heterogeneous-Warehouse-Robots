import json

import pytest

from mrta.grounding import CacheMiss, DeepSeekGrounder, PROMPT_SCHEMA_VERSION, build_grounding_context, validate_candidate
from mrta.knowledge import Atom, VersionedKnowledgeBase
from mrta.scenario import GeneratorConfig, generate_scenario
from mrta.semantic import compile_authenticated_payload
from mrta.simulator import WarehouseSimulator


def test_offline_cache_miss_never_uses_oracle(tmp_path) -> None:
    grounder = DeepSeekGrounder(tmp_path)
    with pytest.raises(CacheMiss):
        grounder.ground("cell is blocked", {"payload": {"point": [1, 2]}}, offline=True)


def test_cached_candidate_is_validated(tmp_path) -> None:
    grounder = DeepSeekGrounder(tmp_path)
    text = "Cargo C00001 is cancelled."
    context = {"payload": {"cargo_id": "C00001"}}
    key = grounder.cache_key(text, context)
    candidate = {
        "schema_version": PROMPT_SCHEMA_VERSION,
        "operations": compile_authenticated_payload("cargo_cancelled", context["payload"]),
        "confidence": 0.9,
        "rationale_code": "cancel_detected",
    }
    (tmp_path / f"{key}.json").write_text(json.dumps({"model": "deepseek-chat", "candidate": candidate}), encoding="utf-8")
    result = grounder.ground(text, context, offline=True)
    assert result.cache_hit
    assert result.candidate == validate_candidate(candidate)


def test_semantic_compiler_is_typed_and_deterministic() -> None:
    first = compile_authenticated_payload("low_friction", {"point": [4, 7], "coefficient": 0.18, "ttl": 10})
    second = compile_authenticated_payload("low_friction", {"point": [4, 7], "coefficient": 0.18, "ttl": 10})
    assert first == second
    assert first[0]["atom"]["predicate"] == "surface_condition"


def test_cached_deepseek_candidate_drives_transaction_and_ttl(tmp_path) -> None:
    state = generate_scenario(GeneratorConfig("S0", 601, trace_seed=8001, horizon=180))
    event = next(item for item in state.events if item.payload.get("ttl", 0) > 0)
    grounder = DeepSeekGrounder(tmp_path)
    context = build_grounding_context(state, event)
    candidate = {
        "schema_version": PROMPT_SCHEMA_VERSION,
        "operations": compile_authenticated_payload(event.event_type, event.payload),
        "confidence": 0.95,
        "rationale_code": "authenticated_match",
    }
    key = grounder.cache_key(event.text, context)
    (tmp_path / f"{key}.json").write_text(
        json.dumps({"model": "deepseek-chat", "candidate": candidate}), encoding="utf-8"
    )
    simulator = WarehouseSimulator(state, "deepseek_facts_cp_sat", grounder=grounder, offline_llm=True)
    simulator._apply_event(event, event.time)
    asserted_atom = Atom.from_dict(candidate["operations"][0]["atom"])
    assert asserted_atom in simulator.kb.snapshot.asserted
    assert simulator.audit[-1]["grounding"]["semantic_shield_accept"] is True
    simulator._expire_temporary_state(event.time + event.payload["ttl"])
    assert asserted_atom not in simulator.kb.snapshot.asserted
