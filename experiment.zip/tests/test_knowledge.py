import pytest

from mrta.knowledge import Atom, KnowledgeError, VersionConflict, VersionedKnowledgeBase


SIGNATURES = {
    "kind": ("entity", "entity"),
    "ready": ("entity", "bool"),
    "eligible": ("entity", "bool"),
    "approved": ("entity", "bool"),
    "motor_command": ("entity", "entity"),
}


def atom(predicate: str, *args: str) -> dict:
    return {"predicate": predicate, "args": list(args)}


def test_forward_chain_proof_retraction_and_rollback() -> None:
    kb = VersionedKnowledgeBase(SIGNATURES)
    operations = [
        {"op": "insert_fact", "atom": atom("kind", "TR001", "transport")},
        {"op": "insert_fact", "atom": atom("ready", "TR001", "true")},
        {"op": "insert_rule", "rule": {
            "rule_id": "r1", "body": [atom("kind", "?r", "transport"), atom("ready", "?r", "true")],
            "head": [atom("eligible", "?r", "true")],
        }},
        {"op": "insert_rule", "rule": {
            "rule_id": "r2", "body": [atom("eligible", "?r", "true")],
            "head": [atom("approved", "?r", "true")],
        }},
    ]
    result = kb.commit("tx1", 0, operations, "test")
    approved = Atom("approved", ("TR001", "true"))
    assert approved in kb.snapshot.closure
    proof = kb.proof_dag(approved)
    assert proof["rule_id"] == "r2"
    original_hash = result.snapshot_hash

    kb.commit("tx2", 1, [{"op": "retract_fact", "atom": atom("ready", "TR001", "true")}], "test")
    assert approved not in kb.snapshot.closure
    rollback = kb.rollback("rollback", 1)
    assert rollback.snapshot_hash == original_hash
    assert approved in kb.snapshot.closure


def test_optimistic_concurrency_and_quarantine() -> None:
    kb = VersionedKnowledgeBase(SIGNATURES)
    kb.commit("tx1", 0, [{"op": "insert_fact", "atom": atom("ready", "TR001", "true")}], "test")
    with pytest.raises(VersionConflict):
        kb.commit("stale", 0, [], "test")
    bad = {"op": "insert_rule", "rule": {
        "rule_id": "unsafe", "body": [atom("ready", "?r", "true")],
        "head": [atom("motor_command", "?r", "go")],
    }}
    result = kb.commit("bad", 1, [bad], "llm")
    assert not result.committed
    assert result.quarantined_rules == ("unsafe",)


def test_range_restriction_and_cycles_are_rejected() -> None:
    kb = VersionedKnowledgeBase(SIGNATURES)
    unsafe_variable = {"op": "insert_rule", "rule": {
        "rule_id": "unbound", "body": [atom("ready", "TR001", "true")],
        "head": [atom("eligible", "?r", "true")],
    }}
    result = kb.commit("q1", 0, [unsafe_variable], "llm")
    assert result.quarantined_rules == ("unbound",)
    first = {"op": "insert_rule", "rule": {
        "rule_id": "forward", "body": [atom("ready", "?r", "true")],
        "head": [atom("eligible", "?r", "true")],
    }}
    kb.commit("r1", 0, [first], "core")
    reverse = {"op": "insert_rule", "rule": {
        "rule_id": "reverse", "body": [atom("eligible", "?r", "true")],
        "head": [atom("ready", "?r", "true")],
    }}
    result = kb.commit("q2", 1, [reverse], "llm")
    assert result.quarantined_rules == ("reverse",)


def test_temporary_rule_cannot_grant_robot_eligibility() -> None:
    kb = VersionedKnowledgeBase()
    unsafe_grant = {"op": "insert_rule", "rule": {
        "rule_id": "grant", "temporary": True, "ttl": 10,
        "body": [{"predicate": "robot_status", "args": ["?r", "idle"]}],
        "head": [{"predicate": "robot_eligible", "args": ["?r", "C00001", "true"]}],
    }}
    result = kb.commit("grant-test", 0, [unsafe_grant], "llm")
    assert not result.committed
    assert result.quarantined_rules == ("grant",)
