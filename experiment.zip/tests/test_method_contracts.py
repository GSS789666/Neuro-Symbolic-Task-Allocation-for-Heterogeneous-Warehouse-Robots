import copy

from mrta.domain import DynamicEvent, RobotRole, TransportMode
from mrta.scenario import GeneratorConfig, generate_scenario
from mrta.simulator import WarehouseSimulator


def _single_cargo_state(seed: int):
    state = generate_scenario(GeneratorConfig("S0", seed, load_level=0.35, disturbance_level="low", horizon=180))
    cargo = next(item for item in state.cargos.values() if item.mode is TransportMode.INDIVIDUAL)
    for item in state.cargos.values():
        item.cancelled = item.cargo_id != cargo.cargo_id
    cargo.release_time = 0
    cargo.deadline = 170
    cargo.service_time = 1
    for robot in state.robots.values():
        if robot.role is RobotRole.UR:
            robot.available_at = 0
    state.events = []
    return state, cargo


def _first(audit, kind):
    return next(item for item in audit if item["kind"] == kind)


def test_static_mivar_policy_changes_stage_a_choice_without_making_task_infeasible() -> None:
    state, cargo = _single_cargo_state(710)
    trs = sorted((robot for robot in state.robots.values() if robot.role is RobotRole.TR), key=lambda robot: robot.robot_id)
    for robot in trs:
        robot.position = (state.width - 1, state.height - 1)
        robot.capacity = 3.0
        robot.battery = 1.0
    trs[0].position = cargo.origin
    trs[0].battery = 0.55
    trs[1].position = (cargo.origin[0] + 4, cargo.origin[1])
    cp_result, cp_audit = WarehouseSimulator(copy.deepcopy(state), "static_cp_sat").run(180)
    mivar_result, mivar_audit = WarehouseSimulator(copy.deepcopy(state), "static_mivar_cp_sat").run(180)
    cp_tr = _first(cp_audit, "stage_a")["trs"]
    mivar_tr = _first(mivar_audit, "stage_a")["trs"]
    assert cp_tr == (trs[0].robot_id,)
    assert mivar_tr != cp_tr
    assert cp_result.low_reserve_tr_assignments == 1
    assert mivar_result.low_reserve_tr_assignments == 0


def test_dynamic_fact_changes_route_cost_while_static_mivar_does_not_ingest_event() -> None:
    state, cargo = _single_cargo_state(711)
    point = (cargo.origin[0] + 5, cargo.origin[1])
    event = DynamicEvent(
        event_id="controlled-congestion", time=0, event_type="moving_congestion",
        text=f"Congestion 7 at {point}.", payload={"point": list(point), "penalty": 7, "ttl": 160},
        gold_operations=[{"op": "supersede_fact", "key": [str(point[0]), str(point[1])],
                          "atom": {"predicate": "congestion", "args": [str(point[0]), str(point[1]), "7"]}}],
        candidate_operations=[], valid=True,
    )
    state.events = [event]
    static_result, static_audit = WarehouseSimulator(copy.deepcopy(state), "static_mivar_cp_sat").run(180)
    dynamic_result, dynamic_audit = WarehouseSimulator(copy.deepcopy(state), "dynamic_facts_cp_sat").run(180)
    static_route = _first(static_audit, "stage_b")["route_path"]
    dynamic_route = _first(dynamic_audit, "stage_b")["route_path"]
    assert point in static_route
    assert point not in dynamic_route
    assert static_result.moving_congestion_exposure_ticks > dynamic_result.moving_congestion_exposure_ticks


def test_dynamic_rule_derivation_changes_low_friction_route_and_is_proven() -> None:
    state, cargo = _single_cargo_state(712)
    point = (cargo.origin[0] + 5, cargo.origin[1])
    event = DynamicEvent(
        event_id="controlled-friction", time=0, event_type="low_friction",
        text=f"Low friction at {point}.", payload={"point": list(point), "coefficient": 0.18, "ttl": 160},
        gold_operations=[{"op": "insert_fact", "atom": {
            "predicate": "surface_condition", "args": [str(point[0]), str(point[1]), "low_friction"]
        }}],
        candidate_operations=[], valid=True,
    )
    state.events = [event]
    facts_result, facts_audit = WarehouseSimulator(copy.deepcopy(state), "dynamic_facts_cp_sat").run(180)
    rules_result, rules_audit = WarehouseSimulator(copy.deepcopy(state), "dynamic_rules_cp_sat").run(180)
    facts_route = _first(facts_audit, "stage_b")["route_path"]
    rules_route = _first(rules_audit, "stage_b")["route_path"]
    assert point in facts_route
    assert point not in rules_route
    assert facts_result.low_friction_exposure_ticks > rules_result.low_friction_exposure_ticks
    assert rules_result.derived_constraint_source_count > facts_result.derived_constraint_source_count
    rule_sources = [item for item in rules_audit if item["kind"] == "constraint_source" and item["source_type"] == "kb_derived"]
    assert any(item["atom"]["predicate"] == "route_penalty" and item["proof_dag"] for item in rule_sources)
