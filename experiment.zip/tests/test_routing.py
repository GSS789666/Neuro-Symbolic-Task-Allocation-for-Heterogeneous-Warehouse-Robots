import pytest

from mrta.routing import GridRouter, ReservationTable, RouteNotFound


def test_router_avoids_temporary_obstacle() -> None:
    router = GridRouter(6, 4)
    reservations = ReservationTable()
    path = router.route("a", (0, 1), (5, 1), 0, reservations, dynamic_blocked={(2, 1)})
    assert (2, 1) not in path
    assert path[0] == (0, 1) and path[-1] == (5, 1)


def test_reservation_prevents_vertex_and_head_on_conflicts() -> None:
    router = GridRouter(5, 3)
    reservations = ReservationTable()
    first = router.route("first", (0, 1), (4, 1), 0, reservations)
    reservations.reserve("first", first, 0)
    second = router.route("second", (4, 1), (0, 1), 0, reservations)
    reservations.reserve("second", second, 0)
    reservations.assert_conflict_free()
    for time, (a, b) in enumerate(zip(first, second)):
        assert a != b
        if time:
            assert not (first[time - 1] == b and second[time - 1] == a)


def test_blocked_goal_fails_loudly() -> None:
    router = GridRouter(3, 3)
    with pytest.raises(RouteNotFound):
        router.route("a", (0, 0), (2, 2), 0, ReservationTable(), dynamic_blocked={(2, 2)})

