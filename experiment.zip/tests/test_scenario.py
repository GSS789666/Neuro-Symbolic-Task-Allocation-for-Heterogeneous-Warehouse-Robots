import json

from mrta.domain import RobotRole, TransportMode
from mrta.scenario import GeneratorConfig, generate_scenario, stable_split


def test_generator_is_reproducible_and_role_safe() -> None:
    config = GeneratorConfig("S0", 101, horizon=300)
    first = generate_scenario(config)
    second = generate_scenario(config)
    assert json.dumps(first.to_dict(), sort_keys=True) == json.dumps(second.to_dict(), sort_keys=True)
    first.assert_role_invariants()
    assert {robot.role for robot in first.robots.values()} == {RobotRole.LR, RobotRole.TR, RobotRole.UR}


def test_all_modes_and_batch_origin_constraint() -> None:
    state = generate_scenario(GeneratorConfig("S2", 303, horizon=600))
    assert {cargo.mode for cargo in state.cargos.values()} == set(TransportMode)
    batches: dict[str, list] = {}
    for cargo in state.cargos.values():
        if cargo.mode is TransportMode.BATCH:
            batches.setdefault(cargo.batch_id, []).append(cargo)
        if cargo.mode is TransportMode.COALITION:
            assert 2 <= cargo.coalition_size <= 4
    assert batches
    for cargos in batches.values():
        assert 2 <= len(cargos) <= 5
        assert len({cargo.origin_id for cargo in cargos}) == 1
        assert len({cargo.release_time for cargo in cargos}) == 1
        assert sum(cargo.weight for cargo in cargos) <= max(
            robot.capacity for robot in state.robots.values() if robot.role is RobotRole.TR
        )
        assert len({cargo.destination_id for cargo in cargos}) >= 1


def test_batch_and_coalition_generation_is_structurally_feasible_across_seeds() -> None:
    for seed in range(320, 340):
        state = generate_scenario(GeneratorConfig("S0", seed, horizon=300))
        trs = [robot for robot in state.robots.values() if robot.role is RobotRole.TR]
        capacities = sorted((robot.capacity for robot in trs), reverse=True)
        batches: dict[str, list] = {}
        for cargo in state.cargos.values():
            if cargo.mode is TransportMode.BATCH:
                batches.setdefault(cargo.batch_id, []).append(cargo)
            elif cargo.mode is TransportMode.COALITION:
                assert sum(capacities[: cargo.coalition_size]) >= cargo.weight
            else:
                assert max(capacities) >= cargo.weight
        for cargos in batches.values():
            assert len({cargo.release_time for cargo in cargos}) == 1
            assert sum(cargo.weight for cargo in cargos) <= max(capacities)


def test_grouped_split_is_stable() -> None:
    group = "S2-map-17"
    assert stable_split(group) == stable_split(group)
    assert stable_split(group) in {"development", "validation", "test"}


def test_layout_seed_and_trace_seed_are_separated() -> None:
    first = generate_scenario(GeneratorConfig("S0", 501, trace_seed=7001, horizon=300))
    second = generate_scenario(GeneratorConfig("S0", 501, trace_seed=7002, horizon=300))
    other_layout = generate_scenario(GeneratorConfig("S0", 502, trace_seed=7001, horizon=300))
    assert first.destinations == second.destinations
    assert [(r.robot_id, r.capacity) for r in first.robots.values()] == [(r.robot_id, r.capacity) for r in second.robots.values()]
    assert [c.release_time for c in first.cargos.values()] != [c.release_time for c in second.cargos.values()]
    assert first.destinations != other_layout.destinations
