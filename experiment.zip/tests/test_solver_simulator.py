import itertools
import time

import pytest

from mrta.domain import RobotRole, TransportMode
from mrta.routing import GridRouter, ReservationTable, RouteDeadlineExceeded
from mrta.scenario import GeneratorConfig, generate_scenario
from mrta.simulator import WarehouseSimulator
from mrta.solver import URReservationTable, bind_stage_b, build_dispatch_candidates, solve_stage_a


def test_cp_sat_selection_matches_bruteforce_on_tiny_candidate_set() -> None:
    state = generate_scenario(GeneratorConfig("S0", 141, horizon=250))
    pending = sorted(state.cargos.values(), key=lambda cargo: cargo.cargo_id)[:4]
    candidates = build_dispatch_candidates(state, pending, now=250, coalition_pool=4, singleton_pool=4)
    result = solve_stage_a(state, pending, now=250, timeout_s=5.0)
    if result.status == "ortools_missing":
        pytest.skip("OR-Tools is installed by 00_setup.cmd")

    def score(subset):
        return sum(100_000 * len(c.cargo_ids) - c.cost for c in subset)

    best = 0
    for size in range(min(len(candidates), 4) + 1):
        for subset in itertools.combinations(candidates, size):
            cargo = [x for c in subset for x in c.cargo_ids]
            trs = [x for c in subset for x in c.tr_ids]
            lrs = [c.lr_id for c in subset]
            if len(cargo) == len(set(cargo)) and len(trs) == len(set(trs)) and len(lrs) == len(set(lrs)):
                best = max(best, score(subset))
    assert score(result.selected) == best


def test_stage_b_rejects_early_ur_binding() -> None:
    state = generate_scenario(GeneratorConfig("S0", 142, horizon=250))
    cargo = next(c for c in state.cargos.values() if c.mode is TransportMode.INDIVIDUAL)
    dispatch = build_dispatch_candidates(state, [cargo], 250)[0]
    with pytest.raises(ValueError, match="only after"):
        bind_stage_b(state, dispatch, 250, GridRouter(state.width, state.height), ReservationTable(), False)


def test_stage_b_wait_uses_current_time_travel_and_future_ur_availability() -> None:
    state = generate_scenario(GeneratorConfig("S0", 144, horizon=300))
    cargo = next(c for c in state.cargos.values() if c.mode is TransportMode.INDIVIDUAL)
    dispatch = build_dispatch_candidates(state, [cargo], 250)[0]
    zone = state.destination_zones[cargo.destination_id]
    for robot in state.robots.values():
        if robot.role is RobotRole.UR and robot.zone_id == zone:
            robot.available_at = 400
    result = bind_stage_b(
        state, dispatch, 250, GridRouter(state.width, state.height),
        ReservationTable(), True, URReservationTable(),
    )
    service = result.service_reservations[0]
    assert service.ur_ready_time >= 400
    assert service.service_start >= service.ur_ready_time
    assert service.service_start > service.tr_arrival_time
    assert result.wait_for_ur == service.service_start - service.tr_arrival_time


def test_stage_b_future_ur_and_dock_reservations_are_conflict_free() -> None:
    state = generate_scenario(GeneratorConfig("S0", 145, horizon=300))
    cargos = [c for c in state.cargos.values() if c.mode is TransportMode.INDIVIDUAL][:2]
    assert len(cargos) == 2
    cargos[1].destination_id = cargos[0].destination_id
    cargos[1].destination = cargos[0].destination
    route_table = ReservationTable()
    ur_table = URReservationTable()
    first = build_dispatch_candidates(state, [cargos[0]], 250)[0]
    second = build_dispatch_candidates(state, [cargos[1]], 250)[0]
    bind_stage_b(state, first, 250, GridRouter(state.width, state.height), route_table, True, ur_table)
    bind_stage_b(state, second, 251, GridRouter(state.width, state.height), route_table, True, ur_table)
    route_table.assert_conflict_free()
    ur_table.assert_conflict_free()


def test_singleton_capacity_filter_precedes_nearest_pool_pruning() -> None:
    state = generate_scenario(GeneratorConfig("S0", 146, horizon=300))
    cargo = next(c for c in state.cargos.values() if c.mode is TransportMode.INDIVIDUAL)
    cargo.release_time = 0
    cargo.weight = 3.0
    trs = sorted((r for r in state.robots.values() if r.role is RobotRole.TR), key=lambda r: r.robot_id)
    for index, robot in enumerate(trs):
        robot.position = cargo.origin if index < 8 else (state.width - 2, state.height - 2)
        robot.capacity = 1.0 if index < 8 else 3.0
    candidates = build_dispatch_candidates(state, [cargo], now=0, singleton_pool=8)
    assert candidates
    assert all(state.robots[candidate.tr_ids[0]].capacity >= cargo.weight for candidate in candidates)
    assert any(candidate.tr_ids[0] in {robot.robot_id for robot in trs[8:]} for candidate in candidates)


def test_batch_capacity_filter_closes_exact_former_top_eight_defect() -> None:
    state = generate_scenario(GeneratorConfig("S0", 149, horizon=300))
    batch = [c for c in state.cargos.values() if c.mode is TransportMode.INDIVIDUAL][:2]
    assert len(batch) == 2
    for cargo in batch:
        cargo.mode = TransportMode.BATCH
        cargo.batch_id = "adversarial-batch"
        cargo.origin_id = batch[0].origin_id
        cargo.origin = batch[0].origin
        cargo.release_time = 0
        cargo.weight = 1.5
    trs = sorted((r for r in state.robots.values() if r.role is RobotRole.TR), key=lambda r: r.robot_id)
    for index, robot in enumerate(trs):
        robot.position = batch[0].origin if index < 8 else (state.width - 2, state.height - 2)
        robot.capacity = 2.0 if index < 8 else 3.0
    candidates = build_dispatch_candidates(state, batch, now=0, singleton_pool=8)
    assert candidates
    assert all(candidate.cargo_ids == tuple(sorted(c.cargo_id for c in batch)) for candidate in candidates)
    assert all(state.robots[candidate.tr_ids[0]].capacity >= 3.0 for candidate in candidates)


def test_coalition_pool_keeps_global_capacity_witness() -> None:
    state = generate_scenario(GeneratorConfig("S0", 147, horizon=300))
    cargo = next(c for c in state.cargos.values() if c.mode is TransportMode.COALITION)
    cargo.release_time = 0
    cargo.coalition_size = 2
    cargo.weight = 6.0
    trs = sorted((r for r in state.robots.values() if r.role is RobotRole.TR), key=lambda r: r.robot_id)
    for index, robot in enumerate(trs):
        robot.position = cargo.origin if index < 8 else (state.width - 2, state.height - 2)
        robot.capacity = 1.0 if index < 8 else 3.0
    candidates = build_dispatch_candidates(state, [cargo], now=0, coalition_pool=8)
    assert candidates
    assert any(sum(state.robots[tr].capacity for tr in candidate.tr_ids) >= 6.0 for candidate in candidates)


def test_coalition_candidate_existence_matches_exact_capacity_oracle() -> None:
    state = generate_scenario(GeneratorConfig("S0", 150, horizon=300))
    cargo = next(iter(state.cargos.values()))
    cargo.mode = TransportMode.COALITION
    cargo.batch_id = None
    cargo.release_time = 0
    trs = sorted((r for r in state.robots.values() if r.role is RobotRole.TR), key=lambda r: r.robot_id)
    near, far = trs[:8], trs[8:12]
    for robot in near:
        robot.position = cargo.origin
        robot.capacity = 0.1
    for robot in far:
        robot.position = (state.width - 2, state.height - 2)
    for capacities in itertools.product((1.0, 2.0, 3.0), repeat=len(far)):
        for robot, capacity in zip(far, capacities):
            robot.capacity = capacity
        all_capacities = [robot.capacity for robot in trs]
        for required in (2, 3, 4):
            cargo.coalition_size = required
            for weight in range(1, 3 * required + 1):
                cargo.weight = float(weight)
                oracle_exists = any(
                    sum(combo) >= cargo.weight
                    for combo in itertools.combinations(all_capacities, required)
                )
                candidates = build_dispatch_candidates(state, [cargo], now=0, coalition_pool=8)
                assert bool(candidates) is oracle_exists, (
                    f"required={required}, weight={weight}, capacities={capacities}"
                )


def test_generated_candidate_groups_smoke_match_structural_existence() -> None:
    for seed in range(150, 155):
        state = generate_scenario(GeneratorConfig("S1", seed, horizon=400))
        batch_groups = {}
        groups = []
        for cargo in state.cargos.values():
            cargo.release_time = 0
            if cargo.mode is TransportMode.BATCH:
                batch_groups.setdefault(cargo.batch_id, []).append(cargo)
            else:
                groups.append([cargo])
        groups.extend(batch_groups.values())
        for group in groups:
            candidates = build_dispatch_candidates(state, group, now=0)
            assert candidates, f"candidate completeness failed for seed={seed}, cargos={[c.cargo_id for c in group]}"


def test_grid_router_honours_expired_wall_deadline() -> None:
    state = generate_scenario(GeneratorConfig("S0", 148, horizon=300))
    router = GridRouter(state.width, state.height)
    with pytest.raises(RouteDeadlineExceeded):
        router.route(
            "deadline-test", (0, 0), (state.width - 1, state.height - 1), 0,
            ReservationTable(), wall_deadline=time.perf_counter() - 1.0,
        )


def test_grid_router_rejects_expired_start_equals_goal_request() -> None:
    router = GridRouter(4, 4)
    with pytest.raises(RouteDeadlineExceeded):
        router.route(
            "expired-short-route", (1, 1), (1, 1), 0,
            ReservationTable(), wall_deadline=time.perf_counter() - 1.0,
        )


def test_grid_router_checks_deadline_during_each_expansion() -> None:
    class SlowExpansionRouter(GridRouter):
        def _neighbors(self, point):
            time.sleep(0.003)
            return super()._neighbors(point)

    router = SlowExpansionRouter(28, 18)
    started = time.perf_counter()
    with pytest.raises(RouteDeadlineExceeded):
        router.route(
            "slow-expansion", (0, 0), (27, 17), 0, ReservationTable(),
            wall_deadline=started + 0.02,
        )
    assert time.perf_counter() - started < 0.08


def test_known_pilot_v2_batch_starvation_case_is_closed() -> None:
    state = generate_scenario(GeneratorConfig(
        "S0", 2102, trace_seed=2102, load_level=0.8,
        disturbance_level="medium", horizon=1200,
    ))
    result, _ = WarehouseSimulator(state, "static_mivar_cp_sat", 1.0).run(1200)
    assert result.structurally_infeasible_cargo_count == 0
    assert result.cargo_pending == 0
    assert result.stage_b_latency_p95_ms is not None and result.stage_b_latency_p95_ms < 800.0
    assert result.timeout_count == 0


def test_s1_high_load_disturbance_regression_stays_within_engineering_budget() -> None:
    for method in ("greedy", "static_cp_sat", "static_mivar_cp_sat", "dynamic_facts_cp_sat", "dynamic_rules_cp_sat"):
        state = generate_scenario(GeneratorConfig(
            "S1", 2207, trace_seed=2207, load_level=0.95,
            disturbance_level="high", horizon=1200,
        ))
        result, _ = WarehouseSimulator(state, method, 1.0).run(1200)
        assert result.cargo_pending == 0
        assert result.hard_violations == 0
        assert result.timeout_count == 0
        assert result.stage_b_latency_p95_ms is not None and result.stage_b_latency_p95_ms <= 800.0


def test_simulator_preserves_two_stage_order_and_roles() -> None:
    state = generate_scenario(GeneratorConfig("S0", 143, load_level=0.35, disturbance_level="low", horizon=220))
    result, audit = WarehouseSimulator(state, "dynamic_facts_cp_sat", 1.0).run(220)
    assert result.hard_violations == 0
    assert result.cargo_completed > 0
    stage_a = {row["mission"]: row["time"] for row in audit if row["kind"] == "stage_a"}
    for row in (item for item in audit if item["kind"] == "stage_b"):
        assert row["time"] >= stage_a[row["mission"]]
    assert all(row.get("ur_selected") is False for row in audit if row["kind"] == "stage_a")
    assert all(robot.role in set(RobotRole) for robot in state.robots.values())
