from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

import pytest

from mrta_llm_v14.cache_seal import build_request_plan, seal_cache, verify_cache_seal, write_request_plan
from mrta_llm_v14.domain import DynamicEvent
from mrta_llm_v14.grounding import (
    CACHE_RECORD_SCHEMA_VERSION,
    DEFAULT_MAX_TOKENS,
    DEFAULT_MODEL,
    DEFAULT_THINKING_MODE,
    PROMPT_SCHEMA_VERSION,
    DeepSeekGrounder,
    GroundingError,
    GroundingResult,
    build_grounding_context,
    validate_candidate,
)
from mrta_llm_v14.knowledge import Atom, VersionedKnowledgeBase
from mrta_llm_v14.scenario import GeneratorConfig, generate_scenario
from mrta_llm_v14.shield import (
    FACTS_ONLY_PROFILE,
    RESTRICTED_RULE_PROFILE,
    RULE_EVENT_TYPES,
    AuthenticatedWriteShield,
    compile_expected_operations,
)
from mrta_llm_v14.simulator import WarehouseSimulator


def _candidate(operations: list[dict]) -> dict:
    return validate_candidate({
        "schema_version": PROMPT_SCHEMA_VERSION,
        "operations": operations,
        "confidence": 0.97,
        "rationale_code": "unit_test",
    })


def _sha(value) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _cache_record(
    grounder: DeepSeekGrounder,
    text: str,
    context: dict,
    profile: str,
    candidate: dict | None,
) -> dict:
    content = json.dumps(candidate, ensure_ascii=False) if candidate is not None else '{"invalid":true}'
    response = {
        "id": "test-response",
        "model": "DeepSeek-V4-Flash-0731",
        "system_fingerprint": "test-fingerprint",
        "choices": [{"message": {"content": content}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
    }
    return {
        "cache_record_schema_version": CACHE_RECORD_SCHEMA_VERSION,
        "cache_key": grounder.cache_key(text, context, profile),
        "model": DEFAULT_MODEL,
        "prompt_schema_version": PROMPT_SCHEMA_VERSION,
        "inference_profile": profile,
        "thinking_mode": DEFAULT_THINKING_MODE,
        "max_tokens": DEFAULT_MAX_TOKENS,
        "request_body_sha256": _sha(grounder._request_body(text, context, profile)),
        "request_utc": "2026-08-26T00:00:00+00:00",
        "api_latency_ms": 12.0,
        "response_status": "valid" if candidate is not None else "invalid",
        "candidate": candidate,
        "raw_content": content,
        "raw_content_sha256": hashlib.sha256(content.encode("utf-8")).hexdigest(),
        "canonical_candidate_sha256": _sha(candidate),
        "raw_response": response,
        "raw_response_sha256": _sha(response),
        "validation_error": None if candidate is not None else "GroundingError:Candidate keys mismatch",
        "usage": response["usage"],
        "response_id": response["id"],
        "response_model": response["model"],
        "system_fingerprint": response["system_fingerprint"],
        "finish_reason": "stop",
    }


def test_cache_identity_binds_profile_thinking_and_prompt(tmp_path: Path) -> None:
    grounder = DeepSeekGrounder(tmp_path, thinking_mode="disabled")
    context = {"event_id": "E1", "authenticated_payload": {"point": [2, 3]}}
    facts_key = grounder.cache_key("blocked", context, FACTS_ONLY_PROFILE)
    rules_key = grounder.cache_key("blocked", context, RESTRICTED_RULE_PROFILE)
    thinking_key = DeepSeekGrounder(tmp_path, thinking_mode="enabled").cache_key(
        "blocked", context, FACTS_ONLY_PROFILE,
    )
    assert len({facts_key, rules_key, thinking_key}) == 3


def test_prompt_hides_authenticated_payload_and_event_type(tmp_path: Path) -> None:
    state = generate_scenario(GeneratorConfig(scale="S0", seed=900, disturbance_level="high"))
    event = next(item for item in state.events if item.event_type == "moving_congestion")
    grounder = DeepSeekGrounder(tmp_path)
    context = build_grounding_context(state, event)
    body = grounder._request_body(event.text, context, RESTRICTED_RULE_PROFILE)
    prompt = json.loads(body["messages"][1]["content"])
    assert "authenticated_payload" not in prompt["context"]
    assert "event_type" not in prompt["context"]
    assert str(event.payload["penalty"]) in prompt["event_text"]
    assert str(event.payload["ttl"]) in prompt["event_text"]


def test_prompt_v13_declares_unambiguous_event_fact_contracts(tmp_path: Path) -> None:
    state = generate_scenario(GeneratorConfig(scale="S0", seed=900, disturbance_level="high"))
    event = next(item for item in state.events if item.event_type == "moving_congestion")
    prompt = json.loads(DeepSeekGrounder(tmp_path)._request_body(
        event.text, build_grounding_context(state, event), FACTS_ONLY_PROFILE,
    )["messages"][1]["content"])
    contracts = prompt["event_fact_contracts"]
    expected = {
        "temporary_obstacle_or_blocked_cell": ("insert_fact", "blocked_cell"),
        "moving_person_or_robot_congestion": ("supersede_fact", "congestion"),
        "robot_unavailable_or_out_of_service": ("supersede_fact", "robot_status"),
        "low_friction_surface": ("insert_fact", "surface_condition"),
        "role_specific_access_restriction": ("insert_fact", "access_restricted"),
        "cargo_service_or_unloading_time_update": ("supersede_fact", "service_time"),
        "cargo_cancelled": ("insert_fact", "cargo_cancelled"),
    }
    assert set(contracts) == set(expected)
    for family, (op, predicate) in expected.items():
        operation = contracts[family]["operation"]
        assert operation["op"] == op
        assert operation["atom"]["predicate"] == predicate
        if op == "supersede_fact":
            assert operation["key"]
    assert "low_friction_cell" not in prompt["context"]["ontology"]
    assert "json_example" not in prompt
    assert len(prompt["profile_correct_example"]["operations"]) == 1
    assert prompt["profile_correct_example"]["operations"][0]["op"] == "supersede_fact"
    roles = prompt["role_token_normalization"]
    assert "transport-role" in roles["TR"]
    assert "never emit words such as transport" in roles["output_rule"]


def test_restricted_rule_prompt_requires_fact_then_one_rule(tmp_path: Path) -> None:
    state = generate_scenario(GeneratorConfig(scale="S0", seed=900, disturbance_level="high"))
    event = next(item for item in state.events if item.event_type == "robot_unavailable")
    prompt = json.loads(DeepSeekGrounder(tmp_path)._request_body(
        event.text, build_grounding_context(state, event), RESTRICTED_RULE_PROFILE,
    )["messages"][1]["content"])
    assert "exactly two operations" in prompt["instruction"]
    operations = prompt["profile_correct_example"]["operations"]
    assert [operation["op"] for operation in operations] == ["insert_fact", "insert_rule"]
    assert operations[0]["atom"]["args"][-1] == "TR"
    assert operations[1]["rule"]["body"][0]["args"][-1] == "TR"
    assert set(prompt["restricted_rule_templates"]) == RULE_EVENT_TYPES
    for template in prompt["restricted_rule_templates"].values():
        assert template["op"] == "insert_rule"
        assert template["rule"]["temporary"] is True
        assert template["rule"]["ttl"] == "<parsed_ttl>"


def test_fact_shield_accepts_gold_and_rejects_schema_valid_mutation() -> None:
    shield = AuthenticatedWriteShield()
    payload = {"point": [4, 7], "penalty": 5, "ttl": 8}
    expected = compile_expected_operations("moving_congestion", payload, "E-1", FACTS_ONLY_PROFILE)
    accepted = shield.assess(
        _candidate(expected), event_type="moving_congestion", payload=payload,
        event_id="E-1", profile=FACTS_ONLY_PROFILE,
    )
    altered = copy.deepcopy(expected)
    altered[0]["atom"]["args"][-1] = "6"
    rejected = shield.assess(
        _candidate(altered), event_type="moving_congestion", payload=payload,
        event_id="E-1", profile=FACTS_ONLY_PROFILE,
    )
    assert accepted.accepted
    assert not rejected.accepted
    assert rejected.reason_code == "authenticated_contract_mismatch"


def test_rule_shield_binds_event_id_ttl_and_policy() -> None:
    shield = AuthenticatedWriteShield()
    payload = {"point": [6, 9], "coefficient": 0.18, "ttl": 17}
    expected = compile_expected_operations("low_friction", payload, "E-77", RESTRICTED_RULE_PROFILE)
    reversed_candidate = _candidate(list(reversed(expected)))
    assert shield.assess(
        reversed_candidate, event_type="low_friction", payload=payload,
        event_id="E-77", profile=RESTRICTED_RULE_PROFILE,
    ).accepted
    for field, value in (("ttl", 18), ("rule_id", "temporary_route_penalty_other")):
        altered = copy.deepcopy(expected)
        altered[1]["rule"][field] = value
        assert not shield.assess(
            _candidate(altered), event_type="low_friction", payload=payload,
            event_id="E-77", profile=RESTRICTED_RULE_PROFILE,
        ).accepted


def test_all_four_restricted_rule_templates_validate() -> None:
    cases = [
        ("low_friction", {"point": [2, 4], "coefficient": 0.18, "ttl": 12}),
        ("moving_congestion", {"point": [3, 5], "penalty": 6, "ttl": 9}),
        ("robot_unavailable", {"robot_id": "TR-1", "ttl": 10}),
        ("access_restriction", {"point": [7, 8], "role": "TR", "ttl": 14}),
    ]
    shield = AuthenticatedWriteShield()
    for index, (event_type, payload) in enumerate(cases):
        event_id = f"E-{index}"
        expected = compile_expected_operations(event_type, payload, event_id, RESTRICTED_RULE_PROFILE)
        candidate = _candidate(expected)
        assert shield.assess(
            candidate, event_type=event_type, payload=payload,
            event_id=event_id, profile=RESTRICTED_RULE_PROFILE,
        ).accepted


def test_overlapping_route_penalties_remain_traceable_and_use_max_semantics() -> None:
    kb = VersionedKnowledgeBase()
    moving = compile_expected_operations(
        "moving_congestion", {"point": [8, 7], "penalty": 4, "ttl": 30},
        "E-moving", RESTRICTED_RULE_PROFILE,
    )
    slippery = compile_expected_operations(
        "low_friction", {"point": [8, 7], "coefficient": 0.18, "ttl": 30},
        "E-slip", RESTRICTED_RULE_PROFILE,
    )
    first = kb.commit("moving", 0, moving, "test")
    second = kb.commit("slippery", first.version, slippery, "test")
    assert second.committed
    penalties = {
        int(atom.args[2])
        for atom in kb.snapshot.closure
        if atom.predicate == "route_penalty" and atom.args[:2] == ("8", "7")
    }
    assert penalties == {4, 9}
    assert max(penalties) == 9
    assert all(
        Atom("route_penalty", ("8", "7", str(value))) in kb.snapshot.proofs
        for value in penalties
    )


def test_invalid_response_is_reproducibly_cached_and_fail_closed(tmp_path: Path) -> None:
    grounder = DeepSeekGrounder(tmp_path)
    text = "A temporary obstacle blocks grid cell (2, 3)."
    context = {"event_id": "E1", "authenticated_payload": {"point": [2, 3]}}
    key = grounder.cache_key(text, context, FACTS_ONLY_PROFILE)
    record = _cache_record(grounder, text, context, FACTS_ONLY_PROFILE, None)
    (tmp_path / f"{key}.json").write_text(json.dumps(record), encoding="utf-8")
    result = grounder.ground(text, context, offline=True, inference_profile=FACTS_ONLY_PROFILE)
    assert result.cache_hit
    assert result.candidate is None
    assert result.response_status == "invalid"


def test_cache_seal_binds_request_raw_response_candidate_and_file(tmp_path: Path) -> None:
    state = generate_scenario(GeneratorConfig(scale="S0", seed=905, disturbance_level="low"))
    event = state.events[0]
    context = build_grounding_context(state, event)
    record = {
        "case_id": f"{state.scenario_id}:{event.event_id}",
        "scenario_id": state.scenario_id,
        "event_id": event.event_id,
        "event_type": event.event_type,
        "time": event.time,
        "text": event.text,
        "payload": event.payload,
        "grounding_context": context,
    }
    events_path = tmp_path / "events.jsonl"
    events_path.write_text(json.dumps(record, sort_keys=True) + "\n", encoding="utf-8")
    cache_dir = tmp_path / "cache"
    plan_path = tmp_path / "request_plan.json"
    seal_path = tmp_path / "cache_seal.json"
    plan = build_request_plan(events_path, cache_dir, profiles=[FACTS_ONLY_PROFILE])
    write_request_plan(plan_path, plan)
    grounder = DeepSeekGrounder(cache_dir)
    candidate = _candidate(compile_expected_operations(
        event.event_type, event.payload, event.event_id, FACTS_ONLY_PROFILE,
    ))
    cache_record = _cache_record(grounder, event.text, context, FACTS_ONLY_PROFILE, candidate)
    cache_path = cache_dir / f"{cache_record['cache_key']}.json"
    cache_path.write_text(json.dumps(cache_record, sort_keys=True), encoding="utf-8")
    seal_cache(plan_path, events_path, cache_dir, seal_path)
    assert verify_cache_seal(seal_path, plan_path, events_path, cache_dir)["status"] == "pass"
    sealed = DeepSeekGrounder(cache_dir, sealed_manifest_path=seal_path)
    assert sealed.ground(event.text, context, offline=True).candidate == candidate

    tampered = json.loads(cache_path.read_text(encoding="utf-8"))
    tampered["candidate"]["confidence"] = 0.11
    cache_path.write_text(json.dumps(tampered, sort_keys=True), encoding="utf-8")
    with pytest.raises(GroundingError):
        sealed.ground(event.text, context, offline=True)


class _FixedGrounder:
    def __init__(self, candidate: dict | None) -> None:
        self.candidate = candidate

    def ground(self, _text: str, _context: dict, offline: bool, inference_profile: str) -> GroundingResult:
        assert offline
        return GroundingResult(
            cache_key="unit", model=DEFAULT_MODEL, inference_profile=inference_profile,
            thinking_mode=DEFAULT_THINKING_MODE, candidate=self.candidate,
            response_status="valid" if self.candidate else "invalid",
            validation_error=None if self.candidate else "invalid", cache_hit=True,
            latency_ms=0.1, api_latency_ms=12.0,
            request_utc="2026-08-26T00:00:00+00:00",
        )


def _low_friction_event(state) -> DynamicEvent:
    return next(event for event in state.events if event.event_type == "low_friction")


def test_deepseek_rule_profile_commits_derived_penalty() -> None:
    state = generate_scenario(GeneratorConfig(scale="S0", seed=901, disturbance_level="high"))
    event = _low_friction_event(state)
    operations = compile_expected_operations(
        event.event_type, event.payload, event.event_id, RESTRICTED_RULE_PROFILE,
    )
    simulator = WarehouseSimulator(
        state, "deepseek_rules_cp_sat", grounder=_FixedGrounder(_candidate(operations)), offline_llm=True,
    )
    simulator._apply_event(event, event.time)
    assert simulator.grounding_shield_accepted == 1
    assert simulator.grounding_rule_accepted == 1
    point = tuple(str(value) for value in event.payload["point"])
    assert any(atom.predicate == "route_penalty" and atom.args[:2] == point for atom in simulator.kb.snapshot.closure)


def test_invalid_soft_event_does_not_write_or_trigger_soft_replan() -> None:
    state = generate_scenario(GeneratorConfig(scale="S0", seed=902, disturbance_level="high"))
    event = _low_friction_event(state)
    simulator = WarehouseSimulator(
        state, "deepseek_facts_cp_sat", grounder=_FixedGrounder(None), offline_llm=True,
    )
    before = simulator.kb.version
    simulator._apply_event(event, event.time)
    assert simulator.kb.version == before
    assert simulator.grounding_rejected == 1
    assert simulator.grounding_shield_accepted == 0


def test_rejected_wms_proposal_uses_authenticated_fallback_and_equal_world_update() -> None:
    base = generate_scenario(GeneratorConfig(scale="S0", seed=904, disturbance_level="high"))
    event = next(item for item in base.events if item.event_type == "service_time")
    oracle = WarehouseSimulator(copy.deepcopy(base), "dynamic_facts_cp_sat")
    rejected = WarehouseSimulator(
        copy.deepcopy(base), "deepseek_facts_cp_sat", grounder=_FixedGrounder(None), offline_llm=True,
    )
    oracle._apply_event(event, event.time)
    rejected._apply_event(event, event.time)
    cargo_id = event.payload["cargo_id"]
    assert oracle.state.cargos[cargo_id].service_time == event.payload["service_time"]
    assert rejected.state.cargos[cargo_id].service_time == event.payload["service_time"]
    assert rejected.grounding_rejected == 1
    assert rejected.grounding_authenticated_fallbacks == 1
    assert any(
        item.get("kind") == "event_commit" and item.get("authenticated_fallback")
        for item in rejected.audit
    )


def test_rejected_cancellation_uses_authenticated_fallback_and_equal_world_update() -> None:
    base = generate_scenario(GeneratorConfig(scale="S0", seed=906, disturbance_level="high"))
    event = next(item for item in base.events if item.event_type == "cargo_cancelled")
    oracle = WarehouseSimulator(copy.deepcopy(base), "dynamic_facts_cp_sat")
    rejected = WarehouseSimulator(
        copy.deepcopy(base), "deepseek_facts_cp_sat", grounder=_FixedGrounder(None), offline_llm=True,
    )
    oracle._apply_event(event, event.time)
    rejected._apply_event(event, event.time)
    cargo_id = event.payload["cargo_id"]
    assert oracle.state.cargos[cargo_id].cancelled
    assert rejected.state.cargos[cargo_id].cancelled
    assert rejected.grounding_rejected == 1
    assert rejected.grounding_authenticated_fallbacks == 1


def test_complete_episode_replays_profile_bound_cache(tmp_path: Path) -> None:
    state = generate_scenario(GeneratorConfig(
        scale="S0", seed=903, load_level=0.60, disturbance_level="medium", horizon=240,
    ))
    grounder = DeepSeekGrounder(tmp_path)
    for event in state.events:
        profile = RESTRICTED_RULE_PROFILE if event.event_type in RULE_EVENT_TYPES else FACTS_ONLY_PROFILE
        context = build_grounding_context(state, event)
        key = grounder.cache_key(event.text, context, profile)
        candidate = _candidate(compile_expected_operations(
            event.event_type, event.payload, event.event_id, profile,
        ))
        record = _cache_record(grounder, event.text, context, profile, candidate)
        (tmp_path / f"{key}.json").write_text(json.dumps(record), encoding="utf-8")
    simulator = WarehouseSimulator(
        state, "deepseek_rules_cp_sat", grounder=grounder, offline_llm=True,
        load_level=0.60, disturbance_level="medium", dataset_split="development",
    )
    result, audit = simulator.run(240)
    assert result.grounding_attempts == len(state.events)
    assert result.grounding_rejected == 0
    assert result.grounding_rule_accepted == sum(event.event_type in RULE_EVENT_TYPES for event in state.events)
    assert result.hard_violations == 0
    assert all(
        item["grounding"]["cache_hit"]
        for item in audit
        if item.get("kind") == "event_commit" and item.get("grounding") is not None
    )
